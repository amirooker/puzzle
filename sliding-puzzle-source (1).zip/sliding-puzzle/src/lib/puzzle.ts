// Sliding puzzle core logic. 0 = empty cell.
export type Board = number[];

export function solved(n: number): Board {
  const b = Array.from({ length: n * n }, (_, i) => i + 1);
  b[n * n - 1] = 0;
  return b;
}

export type ReverseLevel = "easy" | "medium" | "hard" | "pro";

export function sameBoard(a: Board, b: Board): boolean {
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

/** Descending numbered tiles; the blank's corner is parity-adjusted for solvability. */
export function descendingGoal(n: number): Board {
  const blank = n % 2 === 0 ? 0 : n * n - 1;
  let value = n * n - 1;
  return Array.from({ length: n * n }, (_, i) => i === blank ? 0 : value--);
}

function spiralPath(n: number): number[] {
  const path: number[] = [];
  let top = 0, bottom = n - 1, left = 0, right = n - 1;
  while (top <= bottom && left <= right) {
    for (let c = left; c <= right; c++) path.push(top * n + c);
    top++;
    for (let r = top; r <= bottom; r++) path.push(r * n + right);
    right--;
    if (top <= bottom) {
      for (let c = right; c >= left; c--) path.push(bottom * n + c);
      bottom--;
    }
    if (left <= right) {
      for (let r = bottom; r >= top; r--) path.push(r * n + left);
      left++;
    }
  }
  return path;
}

/** Clockwise spiral target. If needed, swaps the first two tiles to keep it reachable. */
export function spiralGoal(n: number): Board {
  const path = spiralPath(n);
  const board = Array<number>(n * n).fill(0);
  path.slice(0, -1).forEach((index, order) => { board[index] = order + 1; });
  if (!isSolvable(board, n)) {
    const first = path[0]!, second = path[1]!;
    [board[first], board[second]] = [board[second]!, board[first]!];
  }
  return board;
}

function randomWalkGoal(n: number, steps: number, rand: () => number): Board {
  let board = solved(n);
  let previousBlank = -1;
  for (let step = 0; step < steps; step++) {
    const blank = board.indexOf(0);
    const row = Math.floor(blank / n), col = blank % n;
    const candidates = [blank - n, blank + n, blank - 1, blank + 1].filter((next) => {
      if (next < 0 || next >= n * n || next === previousBlank) return false;
      if (Math.abs(Math.floor(next / n) - row) + Math.abs((next % n) - col) !== 1) return false;
      return true;
    });
    const next = candidates[Math.floor(rand() * candidates.length)]!;
    previousBlank = blank;
    const moved = board.slice();
    [moved[blank], moved[next]] = [moved[next]!, moved[blank]!];
    board = moved;
  }
  return board;
}

export function reverseGoal(n: number, level: ReverseLevel, rand: () => number = Math.random): Board {
  if (level === "easy") return descendingGoal(n);
  if (level === "medium") return spiralGoal(n);
  if (level === "pro") return randomWalkGoal(n, Math.max(12, n * n), rand);
  let board = shuffle(n, rand);
  while (sameBoard(board, solved(n))) board = shuffle(n, rand);
  return board;
}

export function isSolved(b: Board): boolean {
  for (let i = 0; i < b.length - 1; i++) if (b[i] !== i + 1) return false;
  return b[b.length - 1] === 0;
}

export function isGoal(b: Board, goal: Board): boolean {
  return sameBoard(b, goal);
}

export function isSolvable(b: Board, n: number): boolean {
  let inv = 0;
  const arr = b.filter((x) => x !== 0);
  for (let i = 0; i < arr.length; i++)
    for (let j = i + 1; j < arr.length; j++) if (arr[i]! > arr[j]!) inv++;
  if (n % 2 === 1) return inv % 2 === 0;
  const rowFromBottom = n - Math.floor(b.indexOf(0) / n);
  return (inv + rowFromBottom) % 2 === 1;
}

export function shuffle(n: number, rand: () => number = Math.random): Board {
  let b: Board;
  do {
    b = solved(n);
    for (let i = b.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      [b[i], b[j]] = [b[j]!, b[i]!];
    }
  } while (!isSolvable(b, n) || isSolved(b));
  return b;
}

/** Everyone receives the same solvable daily board for a board size and local date. */
export function dailyShuffle(n: number, date = new Date()): Board {
  const key = `${date.getUTCFullYear()}-${date.getUTCMonth() + 1}-${date.getUTCDate()}-${n}`;
  let seed = 2166136261;
  for (const char of key) seed = Math.imul(seed ^ char.charCodeAt(0), 16777619);
  let value = seed >>> 0;
  const rand = () => {
    value += 0x6d2b79f5;
    let t = value;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return shuffle(n, rand);
}

/** Slide the line between the tapped cell and the empty cell. Returns null if not movable. */
export function slide(b: Board, n: number, idx: number): Board | null {
  const e = b.indexOf(0);
  const er = Math.floor(e / n), ec = e % n, r = Math.floor(idx / n), c = idx % n;
  if (idx === e || (er !== r && ec !== c)) return null;
  const nb = b.slice();
  const step = er === r ? (c > ec ? 1 : -1) : (r > er ? n : -n);
  let cur = e;
  while (cur !== idx) {
    nb[cur] = nb[cur + step]!;
    cur += step;
  }
  nb[idx] = 0;
  return nb;
}

/** Deterministic solvable board for a numeric seed (used so several phones get the same puzzle). */
export function seededShuffle(n: number, seed: number): Board {
  let value = (seed >>> 0) || 1;
  const rand = () => {
    value += 0x6d2b79f5;
    let t = value;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return shuffle(n, rand);
}
