import { useEffect, useMemo, useRef, useState } from "react";
import { Plus, Trash2, Smartphone, Wifi, Users, Timer, Target, Zap, Footprints, Crown, Flag, RefreshCw } from "lucide-react";
import { Header, N, Stat, Confetti } from "@/components/bits";
import { PuzzleBoard } from "@/components/PuzzleBoard";
import { useBackHandler } from "@/lib/back";
import { openLan, myDeviceId, type LanLink, type LanMessage } from "@/lib/lan";
import { seededShuffle, slide, solved, isGoal, type Board } from "@/lib/puzzle";
import { fmtTime } from "@/lib/digits";
import { playVictorySong, playSlide, playWin } from "@/lib/sound";
import { getState, pictureUnlocked, recordLocalDuelMatch } from "@/lib/store";
import { BUILTIN_PICTURES, pictureById } from "@/lib/pictures";

export type Kind = "time" | "speed" | "moves-limit" | "fewest";
export type Settings = { size: number; kind: Kind; limitSec: number; maxMoves: number; samePuzzle: boolean; stopAfter: number; /** Built-in picture id for a competitive picture puzzle; null = number puzzle. */ picture?: string | null };
type Player = { id: string; name: string };
export type Result = { id: string; name: string; time: number; moves: number; failed: boolean };

const KINDS: { id: Kind; title: string; detail: string; icon: typeof Timer }[] = [
  { id: "time", title: "کمترین زمان", detail: "هر کس سریع‌تر حل کند جلوتر است", icon: Timer },
  { id: "speed", title: "سرعتی", detail: "باید زیر زمانی که تعیین می‌کنید حل شود", icon: Zap },
  { id: "moves-limit", title: "حرکت محدود", detail: "حداکثر تعداد حرکت را خودتان تعیین کنید", icon: Target },
  { id: "fewest", title: "کمترین حرکت", detail: "رتبه بر اساس تعداد حرکت است", icon: Footprints },
];
const defaults: Settings = { size: 3, kind: "time", limitSec: 60, maxMoves: 120, samePuzzle: true, stopAfter: 99, picture: null };

export function rank(results: Result[], kind: Kind): Result[] {
  const done = results.filter((r) => !r.failed).sort((a, b) => kind === "fewest" ? a.moves - b.moves || a.time - b.time : a.time - b.time || a.moves - b.moves);
  return [...done, ...results.filter((r) => r.failed)];
}
export const boardFor = (s: Settings, seed: number, index: number) => seededShuffle(s.size, s.samePuzzle ? seed : seed + (index + 1) * 7919);
const sound = () => getState().sound;
const themeNow = () => getState().theme;
const lanStarts = new Set<string>();

/* ---------------- One player's round ---------------- */
function Round({ name, settings, board: start, onDone, stopped, startsAt }: {
  name: string; settings: Settings; board: Board; onDone: (r: { time: number; moves: number; failed: boolean }) => void; stopped?: boolean; startsAt?: number;
}) {
  const n = settings.size;
  const goal = useMemo(() => solved(n), [n]);
  const [count, setCount] = useState(3);
  const [board, setBoard] = useState(start);
  const [moves, setMoves] = useState(0);
  const [cs, setCs] = useState(0);
  const boardRef = useRef(start); const movesRef = useRef(0);
  const t0 = useRef(0); const done = useRef(false);
  const doneRef = useRef(onDone); doneRef.current = onDone;
  const [ended, setEnded] = useState<null | "ok" | "fail">(null);
  const finish = (failed: boolean) => {
    if (done.current) return; done.current = true;
    const time = t0.current ? Math.max(0, Math.floor((performance.now() - t0.current) / 10)) : 0;
    const result = { time: settings.kind === "speed" && failed ? settings.limitSec * 100 : time, moves: movesRef.current, failed };
    setEnded(failed ? "fail" : "ok");
    // Keep the solved board on screen for a moment before the next turn.
    window.setTimeout(() => doneRef.current(result), failed ? 1500 : 3000);
  };
  useEffect(() => {
    const target = startsAt ? startsAt + 2400 : Date.now() + 2400;
    const update = () => {
      const remaining = target - Date.now();
      setCount(Math.max(0, Math.ceil(remaining / 800)));
      if (remaining <= 0 && !t0.current) t0.current = performance.now() + remaining;
    };
    update();
    const id = window.setInterval(update, 50);
    return () => window.clearInterval(id);
  }, [startsAt]);
  useEffect(() => {
    if (count > 0 || done.current) return;
    let raf = 0;
    const loop = () => {
      const now = Math.floor((performance.now() - t0.current) / 10);
      setCs(now);
      if (settings.kind === "speed" && now >= settings.limitSec * 100) { finish(true); return; }
      if (!done.current) raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [count]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (stopped && !done.current) finish(true); }, [stopped]); // eslint-disable-line react-hooks/exhaustive-deps

  const tap = (i: number) => {
    if (count > 0 || done.current) return;
    if (settings.kind === "speed" && performance.now() - t0.current >= settings.limitSec * 1000) { finish(true); return; }
    const current = boardRef.current;
    const next = slide(current, n, i);
    if (!next) return;
    boardRef.current = next; movesRef.current += 1;
    setBoard(next); setMoves(movesRef.current);
    if (sound()) playSlide(themeNow(), current[i]);
    if (navigator.vibrate) navigator.vibrate(8);
    if (isGoal(next, goal)) { if (sound()) setTimeout(() => playWin(themeNow()), 120); finish(false); }
    else if (settings.kind === "moves-limit" && movesRef.current >= settings.maxMoves) finish(true);
  };
  const art = pictureById(settings.picture)?.src;
  const shownTime = settings.kind === "speed" ? Math.max(0, settings.limitSec * 100 - cs) : cs;
  return (
    <div className="flex flex-1 flex-col">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-xl font-bold">نوبت {name}</h2>
        <button disabled={!!ended} onClick={() => finish(true)} className="surface flex items-center gap-1 rounded-xl border px-3 py-2 text-sm"><Flag className="size-4" />تسلیم</button>
      </div>
      <div className="game-stats mb-3 grid grid-cols-2 gap-2">
        <Stat label={settings.kind === "moves-limit" ? "حرکت باقی‌مانده" : "حرکت"} value={<N v={settings.kind === "moves-limit" ? Math.max(0, settings.maxMoves - moves) : moves} />} />
        <Stat label={settings.kind === "speed" ? "زمان باقی‌مانده" : "زمان"} value={<N v={fmtTime(shownTime, "en")} />} />
      </div>
      <PuzzleBoard n={n} board={board} goal={goal} onTap={tap} art={art}>
        {count > 0 && <div className="game-overlay absolute inset-0 grid place-items-center rounded-2xl bg-background/80"><span key={count} className="countdown"><N v={count} /></span></div>}
      </PuzzleBoard>
    </div>
  );
}

/* ---------------- Final ranking ---------------- */
function Ranking({ results, kind, onAgain, onHome, waiting }: { results: Result[]; kind: Kind; onAgain?: () => void; onHome: () => void; waiting?: string }) {
  const ranked = rank(results, kind);
  useEffect(() => { if (!waiting && sound() && ranked.some((r) => !r.failed)) playVictorySong(); }, [waiting]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="flex flex-1 flex-col">
      {!waiting && <Confetti />}
      <h2 className="mb-1 text-center text-2xl font-bold">{waiting ? "نتایج تا این لحظه" : "رتبه‌بندی نهایی"}</h2>
      {waiting && <p className="mb-3 text-center text-sm text-muted-foreground">{waiting}</p>}
      <div className="mt-2 grid gap-2">
        {ranked.map((r, i) => (
          <div key={r.id} data-rank={r.failed ? 0 : i + 1} className="rank-row surface flex items-center gap-3 rounded-xl border p-3">
            <span className="rank-medal">{r.failed ? "—" : i === 0 ? <Crown className="size-5" /> : <N v={i + 1} />}</span>
            <span className="min-w-0 flex-1 truncate font-bold">{r.name}</span>
            {r.failed ? <span className="text-sm text-muted-foreground">کامل نشد</span>
              : <span className="text-sm"><N v={fmtTime(r.time, "en")} /> · <N v={r.moves} /> حرکت</span>}
          </div>
        ))}
      </div>
      <div className="mt-auto grid grid-cols-2 gap-2 pt-6">
        <button onClick={onHome} className="surface rounded-xl border py-3 font-bold">خانه</button>
        {onAgain && <button onClick={onAgain} className="btn-wood rounded-xl py-3 font-bold"><RefreshCw className="me-1 inline size-4" />دوباره</button>}
      </div>
    </div>
  );
}

/* ---------------- Settings form (shared) ---------------- */
export const UNTIL_LAST = 99;
/** The ending options for a match: the first k finishers end it, or everyone plays. */
export function endChoices(players: number) {
  const list: { value: number; title: string; detail: string }[] = [{ value: 1, title: "با اولین برنده", detail: "اولین نفری که کامل کند، مسابقه تمام می‌شود" }];
  for (let k = 2; k < players; k++) list.push({ value: k, title: `تا نفر ${k}`, detail: `وقتی ${k} نفر کامل کنند تمام می‌شود` });
  if (players > 1) list.push({ value: UNTIL_LAST, title: "تا آخرین نفر", detail: "همه بازی می‌کنند" });
  return list;
}
/** Exactly one ending is ever selected: values beyond the player count mean "until the last player". */
export const stopChoice = (stopAfter: number, players: number) => stopAfter >= players ? UNTIL_LAST : stopAfter;
/** True once enough players have finished for the chosen ending. */
export const matchOver = (finishers: number, played: number, players: number, stopAfter: number) =>
  played >= players || finishers >= Math.min(stopChoice(stopAfter, players) === UNTIL_LAST ? players : stopAfter, players);

function SettingsForm({ s, set, players }: { s: Settings; set: (s: Settings) => void; players: number }) {
  return (
    <>
      <h3 className="mb-2 mt-4 font-bold">نوع پازل</h3>
      <div className="grid grid-cols-2 gap-2">
        <button aria-pressed={!s.picture} onClick={() => set({ ...s, picture: null })} className="mp-option surface"><b className="block">پازل اعداد</b><span className="text-xs text-muted-foreground">کاشی‌های شماره‌دار</span></button>
        <button aria-pressed={!!s.picture} onClick={() => set({ ...s, picture: s.picture ?? BUILTIN_PICTURES[0]!.id })} className="mp-option surface"><b className="block">پازل تصویری</b><span className="text-xs text-muted-foreground">رقابت روی یک تصویر</span></button>
      </div>
      {!!s.picture && (
        <div className="mp-pictures mt-2 grid grid-cols-4 gap-2">
          {BUILTIN_PICTURES.filter((p) => pictureUnlocked(p.id, getState())).map((p) => (
            <button key={p.id} aria-pressed={s.picture === p.id} aria-label={p.name} onClick={() => set({ ...s, picture: p.id })} className={`overflow-hidden rounded-lg border-2 ${s.picture === p.id ? "border-primary" : "border-transparent"}`}>
              <img src={p.src} alt="" loading="lazy" className="aspect-square w-full object-cover" />
            </button>
          ))}
        </div>
      )}
      <h3 className="mb-2 mt-4 font-bold">اندازهٔ پازل</h3>
      <div className="chip-row">
        {[3, 4, 5, 6, 7, 8].map((k) => <button key={k} aria-pressed={s.size === k} onClick={() => set({ ...s, size: k })} className="size-chip surface"><N v={`${k}×${k}`} /></button>)}
      </div>
      <h3 className="mb-2 mt-4 font-bold">پازل</h3>
      <div className="grid grid-cols-2 gap-2">
        <button aria-pressed={s.samePuzzle} onClick={() => set({ ...s, samePuzzle: true })} className="mp-option surface"><b className="block">یکسان برای همه</b><span className="text-xs text-muted-foreground">همه یک چیدمان را حل می‌کنند</span></button>
        <button aria-pressed={!s.samePuzzle} onClick={() => set({ ...s, samePuzzle: false })} className="mp-option surface"><b className="block">متفاوت برای هر نفر</b><span className="text-xs text-muted-foreground">هر نفر چیدمان خودش را دارد</span></button>
      </div>
      <h3 className="mb-2 mt-4 font-bold">نوع مسابقه</h3>
      <div className="grid grid-cols-2 gap-2">
        {KINDS.map(({ id, title, detail, icon: Icon }) => (
          <button key={id} aria-pressed={s.kind === id} onClick={() => set({ ...s, kind: id })} className="mp-option surface">
            <span className="flex items-center gap-1.5 font-bold"><Icon className="size-4 text-primary" />{title}</span>
            <span className="text-xs text-muted-foreground">{detail}</span>
          </button>
        ))}
      </div>
      {s.kind === "speed" && (
        <label className="surface mt-3 block rounded-xl border p-3">
          <span className="flex justify-between font-bold">سقف زمان <span><N v={s.limitSec} /> ثانیه</span></span>
          <input type="range" min={5} max={600} step={5} value={s.limitSec} onChange={(e) => set({ ...s, limitSec: Number(e.target.value) })} className="mt-2 w-full accent-[var(--color-primary)]" />
        </label>
      )}
      {s.kind === "moves-limit" && (
        <label className="surface mt-3 block rounded-xl border p-3">
          <span className="flex justify-between font-bold">حداکثر حرکت <span><N v={s.maxMoves} /></span></span>
          <input type="range" min={10} max={1000} step={5} value={s.maxMoves} onChange={(e) => set({ ...s, maxMoves: Number(e.target.value) })} className="mt-2 w-full accent-[var(--color-primary)]" />
        </label>
      )}
      {(
        <>
          <h3 className="mb-2 mt-4 font-bold">پایان مسابقه</h3>
          <p className="mb-2 text-xs text-muted-foreground">خودتان انتخاب کنید مسابقه کی تمام شود (فقط یکی).</p>
          <div className="grid grid-cols-2 gap-2">
            {endChoices(Math.max(players, 2)).map((c) => (
              <button key={c.value} aria-pressed={stopChoice(s.stopAfter, Math.max(players, 2)) === c.value} onClick={() => set({ ...s, stopAfter: c.value })} className="mp-option surface">
                <b className="block">{c.title}</b><span className="text-xs text-muted-foreground">{c.detail}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </>
  );
}

/* ---------------- One phone, players take turns ---------------- */
function LocalMatch({ onHome, onBack }: { onHome: () => void; onBack: () => void }) {
  const [names, setNames] = useState(["بازیکن ۱", "بازیکن ۲"]);
  const [s, setS] = useState<Settings>(defaults);
  const [phase, setPhase] = useState<"setup" | "ready" | "play" | "done">("setup");
  const [turn, setTurn] = useState(0);
  const [seed, setSeed] = useState(1);
  const [results, setResults] = useState<Result[]>([]);
  const players = names.map((n, i) => n.trim() || `بازیکن ${i + 1}`);
  useBackHandler(() => {
    if (phase === "setup") { onBack(); return true; }
    if (phase === "play" || phase === "ready") { if (window.confirm("مسابقه رها شود؟")) setPhase("setup"); return true; }
    setPhase("setup"); return true;
  });
  const start = () => { setSeed(Math.floor(Math.random() * 1e9)); setResults([]); setTurn(0); setPhase("ready"); };
  const finishTurn = (r: { time: number; moves: number; failed: boolean }) => {
    const all = [...results, { id: String(turn), name: players[turn] ?? `بازیکن ${turn + 1}`, ...r }];
    const over = matchOver(all.filter((x) => !x.failed).length, all.length, players.length, s.stopAfter);
    if (over && all.length < players.length) {
      for (let k = all.length; k < players.length; k++) all.push({ id: String(k), name: players[k] ?? `بازیکن ${k + 1}`, time: 0, moves: 0, failed: true });
    }
    setResults(all);
    if (!over) { setTurn(turn + 1); setPhase("ready"); }
    else {
      const done = all.filter((x) => !x.failed);
      if (done.length >= 2) recordLocalDuelMatch(done.map((x) => ({ name: x.name, time: x.time, moves: x.moves })), s.size, s.kind === "fewest" ? "moves" : "time");
      setPhase("done");
    }
  };
  if (phase === "play") return <Round key={turn} name={players[turn] ?? "بازیکن"} settings={s} board={boardFor(s, seed, turn)} onDone={finishTurn} />;
  if (phase === "ready") return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 text-center">
      <Smartphone className="size-14 text-primary" />
      <p className="text-muted-foreground">گوشی را به این بازیکن بدهید</p>
      <h2 className="text-3xl font-bold">{players[turn]}</h2>
      {results.length > 0 && <p className="text-sm text-muted-foreground">نفر قبلی: {results.at(-1)!.failed ? "کامل نشد" : <N v={fmtTime(results.at(-1)!.time, "en")} />}</p>}
      <button onClick={() => setPhase("play")} className="btn-wood mt-4 w-full rounded-2xl py-4 text-xl font-bold">آماده‌ام، شروع!</button>
    </div>
  );
  if (phase === "done") return <Ranking results={results} kind={s.kind} onHome={onHome} onAgain={start} />;
  return (
    <div className="flex flex-1 flex-col">
      <Header title="یک گوشی، نوبتی" back={onBack} />
      <h3 className="mb-2 font-bold">بازیکنان (به ترتیب نوبت)</h3>
      <div className="grid gap-2">
        {names.map((name, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="rank-medal"><N v={i + 1} /></span>
            <input value={name} maxLength={20} onChange={(e) => setNames(names.map((x, j) => j === i ? e.target.value : x))} className="mp-input" />
            {names.length > 2 && <button aria-label="حذف" onClick={() => setNames(names.filter((_, j) => j !== i))} className="surface grid size-10 shrink-0 place-items-center rounded-xl border"><Trash2 className="size-4" /></button>}
          </div>
        ))}
      </div>
      {<button onClick={() => setNames([...names, `بازیکن ${names.length + 1}`])} className="surface mt-2 flex items-center justify-center gap-1 rounded-xl border py-2.5 font-bold"><Plus className="size-4" />افزودن بازیکن</button>}
      <SettingsForm s={s} set={setS} players={names.length} />
      <button onClick={start} className="btn-wood mt-6 rounded-2xl py-4 text-xl font-bold">شروع مسابقه</button>
    </div>
  );
}

/* ---------------- Several phones on the same Wi-Fi ---------------- */
type Lobby = { room: string; hostName: string; players: Player[]; settings: Settings; seen: number };
function LanMatch({ onHome, onBack }: { onHome: () => void; onBack: () => void }) {
  const [name, setName] = useState("");
  useEffect(() => { setName(localStorage.getItem("npz-name") ?? ""); }, []);
  const [role, setRole] = useState<"none" | "host" | "guest">("none");
  const [phase, setPhase] = useState<"lobby" | "play" | "wait" | "done">("lobby");
  const [s, setS] = useState<Settings>(defaults);
  const [room, setRoom] = useState("");
  const [players, setPlayers] = useState<Player[]>([]);
  const [lobbies, setLobbies] = useState<Record<string, Lobby>>({});
  const [seed, setSeed] = useState(1);
  const [results, setResults] = useState<Result[]>([]);
  const [ended, setEnded] = useState(false);
  const [err, setErr] = useState("");
  const link = useRef<LanLink | null>(null);
  const hostId = useRef("");
  const lastHostSeen = useRef(Date.now());
  const lastSeen = useRef<Record<string, number>>({});
  const pendingResult = useRef<Result | null>(null);
  const startedAt = useRef(0);
  const st = useRef({ role, phase, room, players, s, results, seed, ended, name });
  st.current = { role, phase, room, players, s, results, seed, ended, name };

  const onMsg = (m: LanMessage) => {
    const c = st.current;
    if (m["room"] === c.room && c.role === "guest") {
      if (m.from !== hostId.current) return;
      lastHostSeen.current = Date.now();
    }
    if (m["room"] === c.room && c.role === "host" && c.players.some((p) => p.id === m.from)) lastSeen.current[m.from] = Date.now();
    if (m.t === "closed" && c.role === "guest" && m["room"] === c.room) { leave(); setErr("میزبان مسابقه را ترک کرد."); return; }
    if (m.t === "lobby" && typeof m["room"] === "string") {
      const lobby = { room: m["room"], hostName: String(m["hostName"]), players: m["players"] as Player[], settings: m["settings"] as Settings, seen: Date.now() };
      if (c.role === "guest" && lobby.room === c.room && c.phase !== "lobby") { setPhase("lobby"); setEnded(false); pendingResult.current = null; }
      setLobbies((all) => ({ ...all, [lobby.room]: lobby }));
      if (c.role === "guest" && lobby.room === c.room) { setPlayers(lobby.players); setS(lobby.settings); }
    }
    if (m.t === "join" && c.role === "host" && m["room"] === c.room && c.phase === "lobby") {
      lastSeen.current[m.from] = Date.now();
      setPlayers((ps) => ps.some((p) => p.id === m.from) ? ps : [...ps, { id: m.from, name: String(m["name"]).slice(0, 20) }]);
    }
    if (m.t === "leave" && c.role === "host" && m["room"] === c.room) {
      if (c.phase === "lobby") setPlayers((ps) => ps.filter((p) => p.id !== m.from));
      else { const p = c.players.find((p) => p.id === m.from); if (p) addResult({ ...p, time: 0, moves: 0, failed: true }); }
    }
    if (m.t === "start" && c.role === "guest" && m["room"] === c.room) {
      const key = `${c.room}:${m["seed"]}`;
      if (lanStarts.has(key)) return; lanStarts.add(key);
      setS(m["settings"] as Settings); setPlayers(m["players"] as Player[]); setSeed(Number(m["seed"]));
      startedAt.current = Number(m["startedAt"]); pendingResult.current = null;
      setResults([]); setEnded(false); setPhase("play");
    }
    if (m.t === "finish" && c.role === "host" && m["room"] === c.room && c.phase !== "lobby" && !c.ended && Number(m["seed"]) === c.seed && c.players.some((p) => p.id === m.from)) {
      addResult({ id: m.from, name: String(m["name"]), time: Number(m["time"]), moves: Number(m["moves"]), failed: Boolean(m["failed"]) });
    }
    if (m.t === "results" && c.role === "guest" && m["room"] === c.room && Number(m["seed"]) === c.seed) {
      setResults(m["results"] as Result[]);
      if ((m["results"] as Result[]).some((r) => r.id === myDeviceId)) pendingResult.current = null;
      if (m["ended"]) { setEnded(true); setPhase("done"); }
    }
  };
  const addResult = (r: Result) => setResults((rs) => rs.some((x) => x.id === r.id) ? rs : [...rs, r]);

  useEffect(() => {
    let alive = true;
    openLan((m) => onMsg(m)).then((l) => { if (alive) link.current = l; else l.close(); }).catch(() => setErr("اتصال به شبکهٔ محلی ممکن نشد. وای‌فای را روشن کنید."));
    return () => {
      alive = false;
      const c = st.current;
      if (c.role !== "none") link.current?.send({ t: c.role === "host" ? "closed" : "leave", room: c.room });
      link.current?.close(); link.current = null;
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Host: announce lobby and live results; guest: keep asking to join until listed.
  useEffect(() => {
    const id = window.setInterval(() => {
      const c = st.current, l = link.current; if (!l) return;
      if (c.role === "host" && c.phase === "lobby") l.send({ t: "lobby", room: c.room, hostName: c.name, players: c.players, settings: c.s });
      if (c.role === "host" && c.phase !== "lobby") l.send({ t: "results", room: c.room, seed: c.seed, results: c.results, ended: c.ended });
      if (c.role === "guest" && c.phase === "lobby" && !c.players.some((p) => p.id === myDeviceId)) l.send({ t: "join", room: c.room, name: c.name });
      if (c.role === "host" && c.phase === "play" && Date.now() < startedAt.current + 2400) l.send({ t: "start", room: c.room, seed: c.seed, settings: c.s, players: c.players, startedAt: startedAt.current });
      if (c.role === "host") {
        for (const p of c.players) {
          if (p.id === myDeviceId || Date.now() - (lastSeen.current[p.id] ?? Date.now()) < 10000) continue;
          if (c.phase === "lobby") setPlayers((ps) => ps.filter((v) => v.id !== p.id));
          else addResult({ ...p, time: 0, moves: 0, failed: true });
        }
      }
      if (c.role === "guest") {
        l.send({ t: "ping", room: c.room });
        if (pendingResult.current) l.send({ t: "finish", room: c.room, seed: c.seed, ...pendingResult.current });
        if (Date.now() - lastHostSeen.current > 10000) { leave(); setErr("ارتباط با میزبان قطع شد."); }
      }
      if (c.role === "none") setLobbies((all) => Object.fromEntries(Object.entries(all).filter(([, v]) => Date.now() - v.seen < 4000)));
    }, 700);
    return () => window.clearInterval(id);
  }, []);

  // Host decides when the match is over.
  useEffect(() => {
    if (role !== "host" || phase === "lobby" || ended) return;
    const finishers = results.filter((r) => !r.failed).length;
    if (matchOver(finishers, results.length, players.length, s.stopAfter)) {
      setResults((rs) => [...rs, ...players.filter((p) => !rs.some((r) => r.id === p.id)).map((p) => ({ ...p, time: 0, moves: 0, failed: true }))]);
      setEnded(true); setPhase("done");
    }
  }, [results, role, phase, players.length, s.stopAfter, ended]);

  useBackHandler(() => {
    if (phase === "play" || phase === "wait") { if (window.confirm("از مسابقه خارج می‌شوید؟")) leave(); return true; }
    if (role !== "none") { leave(); return true; }
    onBack(); return true;
  });
  const leave = () => {
    if (st.current.role !== "none") link.current?.send({ t: st.current.role === "host" ? "closed" : "leave", room: st.current.room });
    pendingResult.current = null;
    setRole("none"); setPhase("lobby"); setPlayers([]); setResults([]); setEnded(false);
  };
  const saveName = () => { const v = name.trim(); if (!v) { setErr("اول اسمت را بنویس"); return false; } localStorage.setItem("npz-name", v); setErr(""); return true; };
  const host = () => {
    if (!saveName()) return;
    const code = String(1000 + Math.floor(Math.random() * 9000));
    setRoom(code); setRole("host"); setPlayers([{ id: myDeviceId, name: name.trim() }]); setPhase("lobby");
  };
  const join = (l: Lobby) => { if (!saveName()) return; hostId.current = l.players[0]?.id ?? ""; lastHostSeen.current = Date.now(); setRoom(l.room); setRole("guest"); setPlayers(l.players); setS(l.settings); setPhase("lobby"); };
  const startMatch = () => {
    const sd = Math.floor(Math.random() * 1e9);
    startedAt.current = Date.now() + 1200;
    pendingResult.current = null;
    setSeed(sd); setResults([]); setEnded(false); setPhase("play");
    lanStarts.add(`${room}:${sd}`);
    for (let i = 0; i < 6; i++) setTimeout(() => link.current?.send({ t: "start", room, seed: sd, settings: s, players, startedAt: startedAt.current }), i * 180);
  };
  const myIndex = Math.max(0, players.findIndex((p) => p.id === myDeviceId));
  const finishMine = (r: { time: number; moves: number; failed: boolean }) => {
    const mine = { id: myDeviceId, name: name.trim(), ...r };
    if (role === "host") addResult(mine);
    else { pendingResult.current = mine; setResults((rs) => rs.some((x) => x.id === myDeviceId) ? rs : [...rs, mine]); for (let i = 0; i < 4; i++) setTimeout(() => link.current?.send({ t: "finish", room, seed, name: mine.name, time: r.time, moves: r.moves, failed: r.failed }), i * 250); }
    setPhase((p) => p === "done" ? p : "wait");
  };

  if (phase === "play") return <Round name={name.trim()} settings={s} board={boardFor(s, seed, myIndex)} onDone={finishMine} stopped={ended} startsAt={startedAt.current} />;
  if (phase === "wait") return <Ranking results={results} kind={s.kind} onHome={onHome} waiting="منتظر بقیهٔ بازیکنان..." />;
  if (phase === "done") return <Ranking results={results} kind={s.kind} onHome={onHome} {...(role === "host" ? { onAgain: () => setPhase("lobby") } : {})} />;

  if (role !== "none") return (
    <div className="flex flex-1 flex-col">
      <Header title={role === "host" ? "میزبان مسابقه" : "اتاق انتظار"} back={leave} />
      <div className="surface mb-3 rounded-xl border p-3 text-center">
        <p className="text-sm text-muted-foreground">کد اتاق</p>
        <p className="text-3xl font-bold tracking-widest"><N v={room} /></p>
      </div>
      <h3 className="mb-2 font-bold">بازیکنان متصل (<N v={players.length} />)</h3>
      <div className="grid gap-2">
        {players.map((p, i) => <div key={p.id} className="surface flex items-center gap-2 rounded-xl border p-2.5"><span className="rank-medal"><N v={i + 1} /></span><b className="flex-1 truncate">{p.name}</b>{p.id === myDeviceId && <span className="text-xs text-muted-foreground">شما</span>}</div>)}
      </div>
      {role === "host" ? <>
        <SettingsForm s={s} set={setS} players={players.length} />
        <button disabled={players.length < 2} onClick={startMatch} className="btn-wood mt-6 rounded-2xl py-4 text-xl font-bold disabled:opacity-50">{players.length < 2 ? "منتظر بازیکن دوم..." : "شروع همزمان"}</button>
      </> : <p className="mt-6 text-center text-muted-foreground">منتظر بمانید تا میزبان بازی را شروع کند. همه با هم شروع می‌کنید.</p>}
    </div>
  );

  const found = Object.values(lobbies);
  return (
    <div className="flex flex-1 flex-col">
      <Header title="چند گوشی، یک وای‌فای" back={onBack} />
      <p className="mb-3 text-sm text-muted-foreground">همهٔ گوشی‌ها به یک وای‌فای (یا هات‌اسپات یکی از گوشی‌ها) وصل باشند. اینترنت لازم نیست.</p>
      <label className="mb-1 block font-bold">اسم شما</label>
      <input value={name} maxLength={20} onChange={(e) => setName(e.target.value)} placeholder="مثلاً علی" className="mp-input" />
      {err && <p className="mt-2 text-sm text-destructive">{err}</p>}
      <button onClick={host} className="btn-wood mt-4 rounded-2xl py-3.5 text-lg font-bold">ساختن مسابقهٔ جدید</button>
      <h3 className="mb-2 mt-6 font-bold">مسابقه‌های نزدیک</h3>
      {found.length === 0 ? <p className="surface rounded-xl border p-4 text-center text-sm text-muted-foreground">در حال جست‌وجو... وقتی کسی مسابقه بسازد اینجا دیده می‌شود.</p> : (
        <div className="grid gap-2">
          {found.map((l) => (
            <button key={l.room} onClick={() => join(l)} className="surface flex items-center gap-3 rounded-xl border p-3 text-start">
              <Wifi className="size-5 text-primary" />
              <span className="flex-1"><b className="block">{l.hostName}</b><span className="text-xs text-muted-foreground">کد <N v={l.room} /> · <N v={`${l.settings.size}×${l.settings.size}`} />{l.settings.picture ? " · تصویری" : ""} · <N v={l.players.length} /> نفر</span></span>
              <span className="btn-wood rounded-lg px-3 py-1.5 text-sm font-bold">پیوستن</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function Multiplayer({ back, home }: { back: () => void; home: () => void }) {
  const [mode, setMode] = useState<"pick" | "local" | "lan">("pick");
  if (mode === "local") return <LocalMatch onHome={home} onBack={() => setMode("pick")} />;
  if (mode === "lan") return <LanMatch onHome={home} onBack={() => setMode("pick")} />;
  return (
    <div className="flex flex-1 flex-col">
      <Header title="چند نفره" back={back} />
      <div className="grid gap-3">
        <button onClick={() => setMode("local")} className="mode-card surface flex items-center gap-3 rounded-2xl border p-4 text-start">
          <span className="mode-icon grid size-12 shrink-0 place-items-center rounded-xl"><Users className="size-6" /></span>
          <span><b className="block text-lg">یک گوشی، نوبتی</b><span className="text-sm text-muted-foreground">اسم‌ها را بنویسید؛ هر نفر پازل را کامل می‌کند و گوشی را به نفر بعدی می‌دهد. کمترین زمان اول می‌شود.</span></span>
        </button>
        <button onClick={() => setMode("lan")} className="mode-card surface flex items-center gap-3 rounded-2xl border p-4 text-start">
          <span className="mode-icon grid size-12 shrink-0 place-items-center rounded-xl"><Wifi className="size-6" /></span>
          <span><b className="block text-lg">چند گوشی، همزمان</b><span className="text-sm text-muted-foreground">گوشی‌ها کنار هم و روی یک وای‌فای؛ همه با هم شروع می‌کنند و هر کس زودتر کامل کند برنده است.</span></span>
        </button>
      </div>
    </div>
  );
}
