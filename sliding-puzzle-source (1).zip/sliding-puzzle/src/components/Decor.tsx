import { useMemo } from "react";

/** Animated background scenery per theme (snow, bubbles, aurora, stars, sun). */
export function Decor({ theme }: { theme: string }) {
  const rnd = useMemo(() => Array.from({ length: 40 }, (_, i) => ({
    x: (i * 37) % 100, s: 2 + ((i * 7) % 5), d: 6 + ((i * 13) % 9), delay: -((i * 11) % 15), dx: `${((i * 17) % 40) - 20}px`,
  })), []);
  if (theme === "winter") return <div className="decor">{rnd.slice(0, 16).map((f, i) => (
    <span key={i} className="flake" style={{ left: `${f.x}%`, width: f.s, height: f.s, animationDuration: `${f.d}s`, animationDelay: `${f.delay}s`, ["--dx" as string]: f.dx }} />
  ))}</div>;
  if (theme === "ocean" || theme === "toxic") return <div className="decor">{rnd.slice(0, 10).map((f, i) => (
    <span key={i} className="bubble" style={{ left: `${f.x}%`, width: f.s * 3, height: f.s * 3, animationDuration: `${f.d * 1.5}s`, animationDelay: `${f.delay}s` }} />
  ))}</div>;
  if (theme === "aurora") return <div className="decor"><div className="aurora-band" /><div className="aurora-band" style={{ animationDelay: "-6s", top: "15%" }} /></div>;
  if (theme === "sunset") return <div className="decor"><div className="sun" /></div>;
  if (theme === "sakura") return <div className="decor">{rnd.slice(0, 12).map((f, i) => (
    <span key={i} className="petal" style={{ left: `${f.x}%`, width: f.s * 3, height: f.s * 3, animationDuration: `${f.d * 1.4}s`, animationDelay: `${f.delay}s`, ["--dx" as string]: f.dx }} />
  ))}</div>;
  if (theme === "lava" || theme === "dungeon") return <div className="decor">{rnd.slice(0, 12).map((f, i) => (
    <span key={i} className="spark" style={{ left: `${f.x}%`, width: f.s, height: f.s, animationDuration: `${f.d * 0.8}s`, animationDelay: `${f.delay}s`, ["--dx" as string]: f.dx }} />
  ))}</div>;
  if (theme === "midnight" || theme === "neon") return <div className="decor">{rnd.slice(0, 16).map((f, i) => (
    <span key={i} className="star" style={{ left: `${f.x}%`, top: `${(i * 23) % 100}%`, animationDelay: `${f.delay / 5}s` }} />
  ))}</div>;
  return null;
}
