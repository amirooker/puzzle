import { act, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { Game, PhotoPuzzle } from "@/routes/index";
import { BUILTIN_PICTURES } from "@/lib/pictures";
import { pictureThemeForId } from "@/lib/store";

class MockImage {
  static instances: MockImage[] = [];
  width = 100;
  height = 100;
  onload: HTMLImageElement["onload"] = null;
  onerror: HTMLImageElement["onerror"] = null;

  constructor() {
    MockImage.instances.push(this);
  }

  set src(_value: string) {}

  fail() {
    this.onerror?.call(this as unknown as GlobalEventHandlers, new Event("error"));
  }

  finish() {
    this.onload?.call(this as unknown as GlobalEventHandlers, new Event("load"));
  }
}

const createObjectUrlDescriptor = Object.getOwnPropertyDescriptor(URL, "createObjectURL");
const revokeObjectUrlDescriptor = Object.getOwnPropertyDescriptor(URL, "revokeObjectURL");

beforeEach(() => {
  MockImage.instances = [];
  let nextUrl = 0;
  Object.defineProperty(URL, "createObjectURL", {
    configurable: true,
    value: vi.fn(() => `blob:test-${++nextUrl}`),
  });
  Object.defineProperty(URL, "revokeObjectURL", {
    configurable: true,
    value: vi.fn(),
  });
  vi.stubGlobal("Image", MockImage as unknown as typeof Image);
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
  if (createObjectUrlDescriptor) Object.defineProperty(URL, "createObjectURL", createObjectUrlDescriptor);
  else Reflect.deleteProperty(URL, "createObjectURL");
  if (revokeObjectUrlDescriptor) Object.defineProperty(URL, "revokeObjectURL", revokeObjectUrlDescriptor);
  else Reflect.deleteProperty(URL, "revokeObjectURL");
});

describe("photo puzzle resource cleanup", () => {
  it("releases an in-flight image when a non-image file replaces it", () => {
    const { container } = render(<PhotoPuzzle back={() => {}} />);
    const input = container.querySelector<HTMLInputElement>('input[type="file"]');
    if (!input) throw new Error("Photo input was not rendered");

    fireEvent.change(input, {
      target: { files: [new File(["image"], "photo.png", { type: "image/png" })] },
    });
    fireEvent.change(input, {
      target: { files: [new File(["text"], "not-image.txt", { type: "text/plain" })] },
    });

    expect(URL.revokeObjectURL).toHaveBeenCalledWith("blob:test-1");
    expect(screen.getByText("لطفاً یک فایل تصویری انتخاب کن")).toBeInTheDocument();

    MockImage.instances[0]?.finish();

    expect(container.querySelector('img[alt="تصویر انتخاب‌شده"]')).toBeNull();
    expect(URL.revokeObjectURL).toHaveBeenCalledWith("blob:test-1");
  });

  it("releases a broken image URL after decoding fails", () => {
    const { container } = render(<PhotoPuzzle back={() => {}} />);
    const input = container.querySelector<HTMLInputElement>('input[type="file"]');
    if (!input) throw new Error("Photo input was not rendered");

    fireEvent.change(input, {
      target: { files: [new File(["broken"], "broken.png", { type: "image/png" })] },
    });
    act(() => MockImage.instances[0]?.fail());

    expect(URL.revokeObjectURL).toHaveBeenCalledWith("blob:test-1");
    expect(screen.getByText("این تصویر باز نشد، تصویر دیگری امتحان کن")).toBeInTheDocument();
  });
});

describe("image preview control", () => {
  it("hides the full image when the pointer is released", () => {
    render(
      <Game
        n={3}
        mode="training"
        image="data:image/jpeg;base64,dGVzdA=="
        back={() => {}}
      />,
    );
    const previewButton = screen.getByRole("button", { name: "نگاه" });

    fireEvent.pointerDown(previewButton, { pointerId: 1 });
    expect(screen.getByAltText("تصویر کامل پوسته")).toBeInTheDocument();

    fireEvent.pointerUp(window, { pointerId: 1 });
    expect(screen.queryByAltText("تصویر کامل پوسته")).not.toBeInTheDocument();
  });
});

describe("built-in picture catalog", () => {
  it("links every ready-made picture to a game skin purchase", () => {
    for (const picture of BUILTIN_PICTURES) {
      expect(pictureThemeForId(picture.id), picture.id).toBeDefined();
    }
  });
});
