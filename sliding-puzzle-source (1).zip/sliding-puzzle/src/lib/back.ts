import { useEffect, useRef } from "react";

/**
 * Phone back button: every press goes back exactly one step.
 * Screens register handlers; the most recently registered one runs first.
 * A handler returns true when it consumed the press.
 */
type Handler = () => boolean;
const stack: { current: Handler }[] = [];

export function handleBack(): boolean {
  for (let i = stack.length - 1; i >= 0; i--) if (stack[i]!.current()) return true;
  return false;
}

export function useBackHandler(handler: Handler, active = true) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!active) return;
    const entry = { current: () => ref.current() };
    stack.push(entry);
    return () => { const i = stack.indexOf(entry); if (i >= 0) stack.splice(i, 1); };
  }, [active]);
}

async function isNative() {
  try {
    const { Capacitor } = await import("@capacitor/core");
    return Capacitor.isNativePlatform();
  } catch { return false; }
}

export async function exitApp() {
  try {
    const { App } = await import("@capacitor/app");
    await App.exitApp();
  } catch { /* web: nothing to exit */ }
}

/** Installs the hardware back button listener. `onRoot` runs when nothing else handled the press. */
export function installBackButton(onRoot: () => void): () => void {
  let cleanup = () => {};
  let cancelled = false;
  void (async () => {
    if (await isNative()) {
      const { App } = await import("@capacitor/app");
      const sub = await App.addListener("backButton", () => { if (!handleBack()) onRoot(); });
      if (cancelled) void sub.remove(); else cleanup = () => void sub.remove();
      return;
    }
    if (typeof window === "undefined" || cancelled) return;
    // Browser fallback: keep one guard entry in history so "back" stays inside the game.
    window.history.pushState({ puzzleGuard: true }, "");
    const onPop = () => {
      window.history.pushState({ puzzleGuard: true }, "");
      if (!handleBack()) onRoot();
    };
    window.addEventListener("popstate", onPop);
    cleanup = () => window.removeEventListener("popstate", onPop);
  })();
  return () => { cancelled = true; cleanup(); };
}
