import { describe, expect, it } from "vitest";
import { buyTheme, getState, itemUnlocked, PREMIUM_THEMES, SPECIAL_PAID_IDS, SPECIAL_THEMES, THEMES, setState } from "@/lib/store";

describe("special skins", () => {
  it("keeps the paid 3D skins and their challenge gates", () => {
    expect(PREMIUM_THEMES.map((t) => t.id)).toEqual(["dragon-hearts", "magic-orbs", "geode", "planets", "mercury", "void-portal", "soap-bubbles", "gold-orbs", "holo-foil", "ember-cubes", "billiard-royal", "crystal-heart", "star-cascade", "solar-medallion", "moon-pearl", "rainbow-orbit", "sapphire-shard", "lotus-ember", "prism-rainbow", "lux-tictactoe", "lux-checkers", "lux-dominoes", "lux-letters", "lux-ludo", "lux-darts", "lux-go", "lux-snooker", "lux-backgammon", "lux-mahjong", "lux-poker", "lux-cards", "lux-dice", "lux-roulette", "lux-carpet", "lux-pearls", "lux-cube", "lux-watch", "lux-eggs", "lux-pharaoh", "lux-crown", "lux-phoenix", "lux-cosmic-gold", "lux-hoard", "lux-chess", "lux-diamonds", "lux-emerald-flow", "lux-rose-silk", "lux-sapphire-frost", "lux-ruby-inferno", "lux-opal-dream"]);
    for (const t of PREMIUM_THEMES) { expect(t.price).toBeGreaterThanOrEqual(40_000); expect(t.req).toBeTruthy(); }
  });
  it("removes the broken ivory ping-pong skin from the catalog", () => {
    expect(THEMES.some((theme) => theme.id === "ping-pong-pro")).toBe(false);
    expect(PREMIUM_THEMES.some((theme) => theme.id === "ping-pong-pro")).toBe(false);
  });
  it("puts the requested challenge skins and Dragon Hearts in Special", () => {
    const requested = [
      "icon-wood", "leopard-weave", "zebra-silk", "pink-embroidery", "rose-marble", "persian-mosaic",
      "minakari", "khatam", "iranian-brocade", "iran-flag-weave", "emerald-velvet", "peacock",
      "lapis", "white-gold-marble", "obsidian-prism", "black-gold-marble",
    ];
    expect(SPECIAL_THEMES.map((theme) => theme.id)).toEqual([...requested, "dragon-hearts", "lux-tictactoe", "lux-checkers", "lux-dominoes", "lux-letters", "lux-ludo", "lux-darts", "lux-go", "lux-snooker", "lux-backgammon", "lux-mahjong", "lux-poker", "lux-cards", "lux-dice", "lux-roulette", "lux-carpet", "lux-pearls", "lux-cube", "lux-watch", "lux-eggs", "lux-pharaoh", "lux-crown", "lux-phoenix", "lux-cosmic-gold", "lux-hoard", "lux-chess", "lux-diamonds", "lux-emerald-flow", "lux-rose-silk", "lux-sapphire-frost", "lux-ruby-inferno", "lux-opal-dream"]);
    for (const id of requested) {
      const theme = SPECIAL_THEMES.find((item) => item.id === id)!;
      expect(theme.req).toBeTruthy();
      expect(theme.price).toBeGreaterThan(0);
    }
  });
  it("moves every previous Special skin except Dragon Hearts to Skins", () => {
    for (const theme of PREMIUM_THEMES) {
      const listed = THEMES.find((item) => item.id === theme.id);
      expect(listed).toBeDefined();
      expect(listed!.section).toBe(SPECIAL_PAID_IDS.has(theme.id) ? "special" : undefined);
    }
  });
  it("makes every skin in the Special section paid", () => {
    for (const theme of SPECIAL_THEMES) expect(theme.price, theme.id).toBeGreaterThan(0);
  });
  it("removes the six skins the player asked to delete", () => {
    for (const id of ["aurora-borealis", "neon-cyber", "lava-core", "galaxy-nebula", "frost-crystal", "golden-phoenix"]) expect(THEMES.some((t) => t.id === id)).toBe(false);
  });
  it("gives every Special skin its own slide and win sound", async () => {
    const { hasSignatureSound } = await import("@/lib/sound");
    for (const theme of SPECIAL_THEMES) expect(hasSignatureSound(theme.id), theme.id).toBe(true);
  });
  it("keeps the previous tile designs (no symbol overlays)", async () => {
    const { SKIN_MOTIFS } = await import("@/lib/premium");
    expect(SKIN_MOTIFS["lux-tictactoe"]).toEqual(["X", "O"]);
    expect(SKIN_MOTIFS["icon-wood"]).toBeUndefined();
  });
  it("records picture puzzles separately from number puzzles", async () => {
    const { recordPhotoWin } = await import("@/lib/store");
    setState((s) => ({ ...s, stats: { ...s.stats, best: {}, photoBest: {} } }));
    recordPhotoWin(3, 20, 1500);
    expect(getState().stats.photoBest[3]).toEqual({ moves: 20, time: 1500 });
    expect(getState().stats.best[3]).toBeUndefined();
    recordPhotoWin(3, 30, 1200);
    expect(getState().stats.photoBest[3]).toEqual({ moves: 30, time: 1200 });
  });
  it("cannot be bought without finishing its challenge, even with enough points", () => {
    const skin = PREMIUM_THEMES[0]!; // dragon hearts: 3x3 under 6s
    setState((s) => ({ ...s, purchased: [], stats: { ...s.stats, points: skin.price! + 50, bestTime: {} } }));
    expect(buyTheme(skin.id)).toBe(false);
    setState((s) => ({ ...s, stats: { ...s.stats, bestTime: { 3: 600 } } }));
    expect(buyTheme(skin.id)).toBe(true);
    expect(getState().stats.points).toBe(50);
    expect(itemUnlocked(skin, getState().stats, false, getState().purchased)).toBe(true);
  });
});
