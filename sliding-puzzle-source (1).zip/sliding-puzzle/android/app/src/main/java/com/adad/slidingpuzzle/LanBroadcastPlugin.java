package com.adad.slidingpuzzle;

import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Local multiplayer transport.
 * - UDP broadcast on every interface (Wi-Fi, hotspot) so phones can discover matches.
 * - Direct UDP (unicast) to known peers / a typed address, which passes routers that filter
 *   broadcast and works phone-to-phone over a hotspot with no router at all.
 */
@CapacitorPlugin(name = "LanBroadcast")
public class LanBroadcastPlugin extends Plugin {
    private DatagramSocket socket;
    private Thread reader;
    private WifiManager.MulticastLock lock;
    private int port = 47321;
    private final ExecutorService sender = Executors.newSingleThreadExecutor();

    @PluginMethod
    public void start(PluginCall call) {
        port = call.getInt("port", 47321);
        try {
            closeSocket();
            WifiManager wifi = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null) {
                lock = wifi.createMulticastLock("npz-lan");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
            DatagramSocket s = new DatagramSocket(null);
            s.setReuseAddress(true);
            s.setBroadcast(true);
            s.bind(new InetSocketAddress(port));
            socket = s;
            reader = new Thread(() -> {
                byte[] buf = new byte[65507];
                while (!s.isClosed()) {
                    try {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        s.receive(p);
                        JSObject ev = new JSObject();
                        ev.put("data", new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8));
                        ev.put("from", p.getAddress().getHostAddress());
                        notifyListeners("message", ev);
                    } catch (Exception e) {
                        if (s.isClosed()) break;
                    }
                }
            });
            reader.setDaemon(true);
            reader.start();
            call.resolve();
        } catch (Exception e) {
            call.reject("LAN start failed: " + e.getMessage());
        }
    }

    /** Sends to all broadcast addresses plus each address in "targets" directly (Direct UDP). */
    @PluginMethod
    public void send(PluginCall call) {
        final String data = call.getString("data", "");
        final DatagramSocket s = socket;
        if (s == null) { call.reject("not started"); return; }
        final Set<InetAddress> direct = new LinkedHashSet<>();
        JSArray list = call.getArray("targets");
        if (list != null) {
            for (int i = 0; i < list.length(); i++) {
                try { direct.add(InetAddress.getByName(list.getString(i))); } catch (Exception ignored) {}
            }
        }
        sender.execute(() -> {
            byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
            Set<InetAddress> all = targets();
            all.addAll(direct);
            for (InetAddress target : all) {
                try { s.send(new DatagramPacket(bytes, bytes.length, target, port)); } catch (Exception ignored) {}
            }
        });
        call.resolve();
    }

    /** Local IPv4 addresses (with interface names) and the Wi-Fi gateway (= the hotspot phone when connected to one). */
    @PluginMethod
    public void info(PluginCall call) {
        JSObject out = new JSObject();
        JSArray ips = new JSArray();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address)) continue;
                    JSObject o = new JSObject();
                    o.put("ip", a.getHostAddress());
                    o.put("iface", ni.getName());
                    ips.put(o);
                }
            }
        } catch (Exception ignored) {}
        out.put("ips", ips);
        String gateway = "";
        try {
            WifiManager wifi = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null) {
                DhcpInfo d = wifi.getDhcpInfo();
                if (d != null && d.gateway != 0) {
                    int g = d.gateway;
                    gateway = (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
                }
            }
        } catch (Exception ignored) {}
        out.put("gateway", gateway);
        call.resolve(out);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        closeSocket();
        call.resolve();
    }

    /** Global broadcast plus every interface's subnet broadcast (needed on hotspots and some routers). */
    private Set<InetAddress> targets() {
        Set<InetAddress> out = new LinkedHashSet<>();
        try { out.add(InetAddress.getByName("255.255.255.255")); } catch (Exception ignored) {}
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress a : ni.getInterfaceAddresses()) {
                    if (a.getBroadcast() != null) out.add(a.getBroadcast());
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void closeSocket() {
        if (socket != null) { socket.close(); socket = null; }
        if (lock != null && lock.isHeld()) lock.release();
        lock = null;
    }

    @Override
    protected void handleOnDestroy() { closeSocket(); }
}
