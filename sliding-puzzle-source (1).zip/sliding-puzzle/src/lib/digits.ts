export type DigitLang = "fa" | "en";
const FA = "۰۱۲۳۴۵۶۷۸۹";
export function toDigits(v: number | string, lang: DigitLang): string {
  const s = String(v);
  return lang === "fa" ? s.replace(/[0-9]/g, (d) => FA[+d]!) : s;
}
/** cs = centiseconds */
export function fmtTime(cs: number, lang: DigitLang) {
  const m = Math.floor(cs / 6000), s = Math.floor(cs / 100) % 60, c = cs % 100;
  return toDigits(`${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(c).padStart(2, "0")}`, lang);
}
/** 8000000 -> "8,000,000"; strings (times like 01:23.45) are left as they are. */
export function groupThousands(v: number | string): string {
  if (typeof v !== "number" || !Number.isFinite(v) || Math.abs(v) < 1000) return String(v);
  return String(Math.trunc(v)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
