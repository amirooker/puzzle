/** Hard missions that rotate every 5 days (an "epoch"). */
import type { Stats } from "./store";

export const EPOCH_DAYS = 5;
const EPOCH_MS = EPOCH_DAYS * 864e5;
export const epochNum = (now = Date.now()) => Math.floor(now / EPOCH_MS);
export const epochId = (now = Date.now()) => `e${epochNum(now)}`;
export const epochEndsAt = (now = Date.now()) => (epochNum(now) + 1) * EPOCH_MS;

export type EpochStats = { id: string; noHelp: number; hardFast: number; lowMoves: number; big: number; records: number; noHelpBig: number };
export const newEpoch = (id = epochId()): EpochStats => ({ id, noHelp: 0, hardFast: 0, lowMoves: 0, big: 0, records: 0, noHelpBig: 0 });

export type EpochMission = { id: string; title: string; goal: number; value: (s: Stats) => number; points: number; reward: string };
type Tpl = { id: string; t: (g: number) => string; g: number[]; v: (e: EpochStats) => number; pts: number };
const POOL: Tpl[] = [
  { id: "nohelp", t: (g) => `${g} پازل را بدون «برگشت» و «نگاه» حل کن`, g: [6, 8, 10], v: (e) => e.noHelp, pts: 25 },
  { id: "nohelpbig", t: (g) => `${g} پازل ۵×۵ یا بزرگ‌تر بدون هیچ کمکی`, g: [2, 3, 4], v: (e) => e.noHelpBig, pts: 90 },
  { id: "hardfast", t: (g) => `${g} پازل ۴×۴ یا بزرگ‌تر زیر زمان مجاز`, g: [3, 5, 7], v: (e) => e.hardFast, pts: 60 },
  { id: "lowmoves", t: (g) => `${g} برد با کمتر از نصف سقف حرکت`, g: [3, 5, 8], v: (e) => e.lowMoves, pts: 50 },
  { id: "big", t: (g) => `${g} پازل ۶×۶ یا بزرگ‌تر را حل کن`, g: [2, 3, 5], v: (e) => e.big, pts: 80 },
  { id: "records", t: (g) => `${g} رکورد شخصی جدید (کم‌حرکت‌تر) ثبت کن`, g: [2, 3, 4], v: (e) => e.records, pts: 70 },
];
const hash = (str: string) => { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };

/** Four hard missions for the given epoch; rewards are large coin prizes. */
export function epochMissions(id: string): EpochMission[] {
  const pool = POOL.slice(); let h = hash(`epoch:${id}`); const out: EpochMission[] = [];
  while (out.length < 4) {
    h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0;
    const p = pool.splice(h % pool.length, 1)[0]!, g = p.g[(h >>> 8) % p.g.length]!;
    const points = 100 + p.pts * g;
    out.push({ id: `${p.id}${g}`, title: p.t(g), goal: g, value: (s) => s.epoch.id === id ? p.v(s.epoch) : 0, points, reward: `${points} سکه` });
  }
  return out;
}
export const epochKey = (missionId: string, s: Stats) => `${s.epoch.id}:${missionId}`;

/** Days and hours left until the missions change. */
export function epochCountdown(now = Date.now()) {
  const left = Math.max(0, epochEndsAt(now) - now);
  return { days: Math.floor(left / 864e5), hours: Math.floor((left % 864e5) / 36e5), minutes: Math.floor((left % 36e5) / 6e4) };
}
