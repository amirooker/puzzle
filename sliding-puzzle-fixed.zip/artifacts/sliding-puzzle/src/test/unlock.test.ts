import { describe, it, expect } from "vitest";
import {
  THEMES, sizeUnlocked, itemUnlocked, timeLimit, newDaily, type Stats,
  buyCustomPicture, buyTheme, customPicturePurchaseId, customPictureUnlocked,
  getState, PICTURE_PRICE, pictureThemeForId, pictureUnlocked, setState,
} from "@/lib/store";
const base: Stats = { points: 0, wins: 0, duelMatches: 0, duelWins: 0, duelLosses: 0, duelHistory: [], winsBySize: {}, best: {}, streak: 0, bestStreak: 0, efficientWins: 0, daily: newDaily(""),
  bestTime: {}, lastLogin: "", loginStreak: 0, week: { id: "", wins: 0, efficient: 0, days: 0 }, unlocked: [], fastRun: {}, bestFastRun: {}, bestLogin: 0, photoBest: {}, photoWins: 0 };
describe("unlocks", () => {
  it("only wood is free at start", () => {
    expect(THEMES.filter((t) => itemUnlocked(t, base, false)).map((t) => t.id)).toEqual(["wood", "garden-art"]);
  });
  it("picture skins stay locked until purchased, then can be equipped", () => {
    const free = THEMES.find((t) => t.id === "garden-art")!;
    expect(itemUnlocked(free, base, false)).toBe(true);
    const pics = THEMES.filter((t) => t.picture && t.id !== "garden-art");
    for (const art of pics) { expect(art.price).toBe(500); expect(itemUnlocked(art, base, false)).toBe(false); expect(itemUnlocked(art, base, true)).toBe(true); }
    expect(itemUnlocked(pics[0]!, base, false, [pics[0]!.id])).toBe(true);
  });
  it("only 3x3 open at start; 4x4 needs 3 consecutive 3x3 wins under 30s", () => {
    expect(sizeUnlocked(4, base, false)).toBe(false);
    expect(timeLimit(3)).toBe(30);
    expect(sizeUnlocked(4, { ...base, bestFastRun: { 3: 2 } }, false)).toBe(false);
    expect(sizeUnlocked(4, { ...base, bestFastRun: { 3: 3 } }, false)).toBe(true);
  });
  it("winter needs 14-day login streak; amethyst needs 5x5 under 50s", () => {
    const w = THEMES.find((t) => t.id === "winter")!, a = THEMES.find((t) => t.id === "amethyst")!;
    expect(itemUnlocked(w, { ...base, bestLogin: 13 }, false)).toBe(false);
    expect(itemUnlocked(w, { ...base, bestLogin: 14 }, false)).toBe(true);
    expect(itemUnlocked(a, { ...base, bestTime: { 5: 5001 } }, false)).toBe(false);
    expect(itemUnlocked(a, { ...base, bestTime: { 5: 5000 } }, false)).toBe(true);
  });
});
describe("picture puzzle purchases", () => {
  it("charges 500 once for each personal gallery picture", () => {
    setState((s) => ({ ...s, admin: false, purchased: [], stats: { ...s.stats, points: 1_000 } }));
    const id = "gallery-photo-one";
    expect(customPictureUnlocked(id)).toBe(false);
    expect(buyCustomPicture(id)).toBe(true);
    expect(getState().stats.points).toBe(1_000 - PICTURE_PRICE);
    expect(getState().purchased).toContain(customPicturePurchaseId(id));
    expect(customPictureUnlocked(id)).toBe(true);
    expect(buyCustomPicture(id)).toBe(true);
    expect(getState().stats.points).toBe(1_000 - PICTURE_PRICE);

    setState((s) => ({ ...s, purchased: [], stats: { ...s.stats, points: PICTURE_PRICE - 1 } }));
    expect(buyCustomPicture("not-enough-points")).toBe(false);
    expect(getState().stats.points).toBe(PICTURE_PRICE - 1);
  });

  it("uses the same price and ownership for a built-in puzzle and its skin", () => {
    setState((s) => ({ ...s, admin: false, purchased: [], stats: { ...s.stats, points: PICTURE_PRICE } }));
    const theme = pictureThemeForId("reef");
    expect(theme?.id).toBe("reef-art");
    expect(theme?.price).toBe(PICTURE_PRICE);
    expect(pictureUnlocked("reef", getState())).toBe(false);
    expect(buyTheme(theme!.id)).toBe(true);
    expect(pictureUnlocked("reef", getState())).toBe(true);
    expect(getState().stats.points).toBe(0);
  });
});
import { WEEKLY_THEMES } from "@/lib/store";
describe("new skins", () => {
  it("billiard needs 30 wins; weekly rotation has 12 skins", () => {
    const b = THEMES.find((t) => t.id === "billiard")!;
    expect(itemUnlocked(b, { ...base, wins: 29 }, false)).toBe(false);
    expect(itemUnlocked(b, { ...base, wins: 30 }, false)).toBe(true);
    expect(WEEKLY_THEMES.length).toBe(15);
  });
});
import { dailyMissions } from "@/lib/store";
describe("daily missions", () => {
  it("4 distinct missions per day, changing across days", () => {
    const a = dailyMissions("2026-10-28"), b = dailyMissions("2026-10-29");
    expect(a.length).toBe(4);
    expect(new Set(a.map((m) => m.id.replace(/\d+$/, ""))).size).toBe(4);
    expect(a.map((m) => m.id).join()).not.toBe(b.map((m) => m.id).join());
  });
  it("honey skin replaced; 18 new regular skins exist", () => {
    expect(THEMES.some((t) => t.id === "honey")).toBe(false);
    expect(THEMES.find((t) => t.id === "macaron")).toBeTruthy();
  });
});

describe("harder skins", () => {
  it("one skin needs 3x3 under 10 seconds", () => {
    const d = THEMES.find((t) => t.id === "dungeon")!;
    expect(itemUnlocked(d, { ...base, bestTime: { 3: 1001 } }, false)).toBe(false);
    expect(itemUnlocked(d, { ...base, bestTime: { 3: 1000 } }, false)).toBe(true);
  });
  it("special-section skins need their challenge and must be bought", () => {
    const k = THEMES.find((t) => t.id === "khatam")!;
    expect(k.price).toBe(5_000);
    expect(k.req!.ok({ ...base, wins: 599 }, 0)).toBe(false);
    expect(k.req!.ok({ ...base, wins: 600 }, 0)).toBe(true);
    expect(itemUnlocked(k, { ...base, wins: 600 }, false)).toBe(false);
    expect(itemUnlocked(k, { ...base, wins: 600 }, false, ["khatam"])).toBe(true);
  });
});
