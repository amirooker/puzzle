import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const storageKey = "adad-puzzle-v1";
const keyFor = (date: Date) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date(2026, 3, 1, 23, 59, 59));
  localStorage.clear();
});

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
  localStorage.clear();
  vi.resetModules();
});

describe("local game storage", () => {
  it("recovers from malformed saved data and replaces it with valid state", async () => {
    localStorage.setItem(storageKey, "{bad json");
    const store = await import("@/lib/store");

    expect(() => store.getState()).not.toThrow();
    expect(JSON.parse(localStorage.getItem(storageKey) ?? "null")).toHaveProperty("stats.daily.date");
  });

  it("continues the current session when browser storage is unavailable", async () => {
    vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
      throw new Error("Storage is blocked");
    });
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new Error("Storage is blocked");
    });
    const store = await import("@/lib/store");

    expect(() => store.getState()).not.toThrow();
    expect(() => store.setState((state) => ({ ...state, sound: !state.sound }))).not.toThrow();
  });
});

describe("daily calendar rollover", () => {
  it("refreshes daily challenges and streaks at midnight while the app stays open", async () => {
    const yesterday = new Date(2026, 3, 1, 23, 59, 59);
    const today = new Date(2026, 3, 2, 0, 0, 2);
    localStorage.setItem(
      storageKey,
      JSON.stringify({
        stats: {
          points: 20,
          lastLogin: keyFor(yesterday),
          loginStreak: 3,
          daily: { date: keyFor(yesterday), wins: 2, played: 4 },
          week: { id: "last-week", days: 1 },
        },
      }),
    );
    const store = await import("@/lib/store");
    expect(store.getState().stats.daily.wins).toBe(2);

    vi.advanceTimersByTime(3_000);

    const refreshed = store.getState();
    expect(refreshed.stats.daily.date).toBe(keyFor(today));
    expect(refreshed.stats.daily.wins).toBe(0);
    expect(refreshed.stats.loginStreak).toBe(4);
    expect(refreshed.stats.points).toBe(35);
  });
});
