import cork from "../assets/tex-cork.jpg";
import terrazzo from "../assets/tex-terrazzo.jpg";
import rosewood from "../assets/tex-rosewood.jpg";
import nacre from "../assets/tex-nacre.jpg";
import leopardWeave from "../assets/premium/leopard-weave.jpg";
import zebraSilk from "../assets/premium/zebra-silk.jpg";
import pinkEmbroidery from "../assets/premium/pink-embroidery.jpg";
import roseMarble from "../assets/premium/rose-marble.jpg";
import persianMosaic from "../assets/premium/persian-mosaic.jpg";
import minakari from "../assets/premium/minakari.jpg";
import khatam from "../assets/premium/khatam.jpg";
import iranianBrocade from "../assets/premium/iranian-brocade.jpg";
import iranFlagWeave from "../assets/premium/iran-flag-weave.jpg";
import emeraldVelvet from "../assets/premium/emerald-velvet.jpg";
import peacock from "../assets/premium/peacock.jpg";
import lapis from "../assets/premium/lapis.jpg";
import whiteGoldMarble from "../assets/premium/white-gold-marble.jpg";
import obsidianPrism from "../assets/premium/obsidian-prism.jpg";
import iconWood from "../assets/premium/icon-wood.jpg";
import dragonHearts from "../assets/premium/dragon-hearts.jpg";
import blackGoldMarble from "../assets/premium/black-gold-marble.jpg";
import premiumBilliardFelt from "../assets/premium/premium-billiard-felt.png";

import lux0 from "../assets/lux/tictactoe.jpg";
import lux1 from "../assets/lux/checkers.jpg";
import lux2 from "../assets/lux/dominoes.jpg";
import lux3 from "../assets/lux/letters.jpg";
import lux4 from "../assets/lux/ludo.jpg";
import lux5 from "../assets/lux/darts.jpg";
import lux6 from "../assets/lux/go.jpg";
import lux7 from "../assets/lux/snooker.jpg";
import lux8 from "../assets/lux/backgammon.jpg";
import lux9 from "../assets/lux/mahjong.jpg";
import lux10 from "../assets/lux/poker.jpg";
import lux11 from "../assets/lux/cards.jpg";
import lux12 from "../assets/lux/dice.jpg";
import lux13 from "../assets/lux/roulette.jpg";
import lux14 from "../assets/lux/carpet.jpg";
import lux15 from "../assets/lux/pearls.jpg";
import lux16 from "../assets/lux/cube.jpg";
import lux17 from "../assets/lux/watch.jpg";
import lux18 from "../assets/lux/eggs.jpg";
import lux19 from "../assets/lux/pharaoh.jpg";
import lux20 from "../assets/lux/crown.jpg";
import lux21 from "../assets/lux/phoenix.jpg";
import lux22 from "../assets/lux/cosmic-gold.jpg";
import lux23 from "../assets/lux/hoard.jpg";
import lux24 from "../assets/lux/chess.jpg";
import lux25 from "../assets/lux/diamonds.jpg";
import luxB0 from "../assets/lux/emerald-flow.jpg";
import luxB1 from "../assets/lux/rose-silk.jpg";
import luxB2 from "../assets/lux/sapphire-frost.jpg";
import luxB3 from "../assets/lux/ruby-inferno.jpg";
import luxB4 from "../assets/lux/opal-dream.jpg";

export const materialTextureUrls: Record<string, string> = {
  cork,
  terrazzo,
  rosewood,
  nacre,
  "leopard-weave": leopardWeave,
  "zebra-silk": zebraSilk,
  "pink-embroidery": pinkEmbroidery,
  "rose-marble": roseMarble,
  "persian-mosaic": persianMosaic,
  "minakari": minakari,
  "khatam": khatam,
  "iranian-brocade": iranianBrocade,
  "iran-flag-weave": iranFlagWeave,
  "emerald-velvet": emeraldVelvet,
  "peacock": peacock,
  "lapis": lapis,
  "white-gold-marble": whiteGoldMarble,
  "obsidian-prism": obsidianPrism,
  "black-gold-marble": blackGoldMarble,
  "icon-wood": iconWood,
  "dragon-hearts": dragonHearts,
  "billiard-royal": premiumBilliardFelt,
  "lux-tictactoe": lux0,
  "lux-checkers": lux1,
  "lux-dominoes": lux2,
  "lux-letters": lux3,
  "lux-ludo": lux4,
  "lux-darts": lux5,
  "lux-go": lux6,
  "lux-snooker": lux7,
  "lux-backgammon": lux8,
  "lux-mahjong": lux9,
  "lux-poker": lux10,
  "lux-cards": lux11,
  "lux-dice": lux12,
  "lux-roulette": lux13,
  "lux-carpet": lux14,
  "lux-pearls": lux15,
  "lux-cube": lux16,
  "lux-watch": lux17,
  "lux-eggs": lux18,
  "lux-pharaoh": lux19,
  "lux-crown": lux20,
  "lux-phoenix": lux21,
  "lux-cosmic-gold": lux22,
  "lux-hoard": lux23,
  "lux-chess": lux24,
  "lux-diamonds": lux25,
  "lux-emerald-flow": luxB0,
  "lux-rose-silk": luxB1,
  "lux-sapphire-frost": luxB2,
  "lux-ruby-inferno": luxB3,
  "lux-opal-dream": luxB4,
};
