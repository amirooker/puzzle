// Synthesized sound effects (no audio files). Browser-only.
let ctx: AudioContext | null = null;
function ac() {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const C = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!C) return null;
    ctx = new C();
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function tone(freq: number, start: number, dur: number, type: OscillatorType, vol: number, endFreq?: number) {
  const c = ac(); if (!c) return;
  if (![freq, start, dur, vol, endFreq ?? freq].every(Number.isFinite)) return;
  const t = c.currentTime + start;
  const o = c.createOscillator(), g = c.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(c.destination);
  o.start(t); o.stop(t + dur + 0.02);
}

function noise(start: number, dur: number, vol: number, freq: number, q = 1) {
  const c = ac(); if (!c) return;
  const t = c.currentTime + start;
  const buf = c.createBuffer(1, Math.ceil(c.sampleRate * dur), c.sampleRate);
  const d = buf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  const src = c.createBufferSource(); src.buffer = buf;
  const f = c.createBiquadFilter(); f.type = "bandpass"; f.frequency.value = freq; f.Q.value = q;
  const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  src.connect(f).connect(g).connect(c.destination); src.start(t);
}

export type Material = "wood" | "ice" | "metal" | "stone" | "glass" | "soft" | "digital" | "leather" | "bamboo" | "steel" | "ceramic" | "paper" | "toxic" | "gold";
const themeHash = (theme: string) => {
  let value = 2166136261;
  for (const char of theme) value = Math.imul(value ^ char.charCodeAt(0), 16777619);
  return value >>> 0;
};
const MAT: Record<string, Material> = {
  wood: "wood", forest: "wood", pirate: "wood", sakura: "wood",
  chocolate: "soft", midnight: "soft", light: "soft", sunset: "soft",
  candy: "glass", ocean: "glass", aurora: "glass", ruby: "glass", emerald: "glass", amethyst: "glass", crimson: "glass",
  winter: "ice", arctic: "ice",
  copper: "metal", royal: "gold", palace: "gold",
  obsidian: "stone", lava: "stone", desert: "stone", dungeon: "stone", jade: "ceramic", turquoise: "ceramic",
  neon: "digital", pixel: "digital", galaxy: "digital",
  leather: "leather", bamboo: "bamboo", steel: "steel", paper: "paper", toxic: "toxic",
};
export const materialOf = (theme: string): Material => MAT[theme] ?? "wood";

export function playSlide(theme = "wood", v = 1) {
  const r = Math.random();
  const fx = SLIDE_FX[theme]; if (fx) { fx(r, v); return; }
  switch (materialOf(theme)) {
    case "wood": // felt-like slide scrape, then a hollow wooden block knock
      noise(0, 0.07, 0.06, 420, 0.6);
      noise(0.06, 0.018, 0.5, 3200 + r * 500, 1.5);
      tone(165 + r * 25, 0.06, 0.18, "sine", 0.45, 105);
      tone(480 + r * 40, 0.06, 0.07, "triangle", 0.2, 330);
      tone(980 + r * 60, 0.06, 0.03, "sine", 0.07); break;
    case "bamboo": // hollow tube tok
      noise(0, 0.015, 0.4, 2400, 2);
      tone(720 + r * 60, 0, 0.12, "sine", 0.3, 640); tone(1450 + r * 80, 0, 0.05, "sine", 0.1); break;
    case "ice": noise(0, 0.09, 0.18, 6000, 1.2); tone(2800 + r * 400, 0.03, 0.15, "sine", 0.12, 2000); tone(4200, 0.03, 0.08, "sine", 0.05); break;
    case "metal": [880, 1320, 2093].forEach((f, i) => tone(f + r * 30, 0, 0.35 - i * 0.08, "sine", 0.09)); noise(0, 0.03, 0.1, 4000, 3); break;
    case "gold": [1046, 1568, 2349].forEach((f, i) => tone(f + r * 20, 0, 0.5 - i * 0.1, "sine", 0.08)); break;
    case "steel": // heavy clank with metallic ring
      noise(0, 0.04, 0.45, 1800, 0.8); tone(220 + r * 20, 0, 0.12, "square", 0.08, 160);
      [1180, 1870, 2650].forEach((f) => tone(f + r * 40, 0.01, 0.3, "sine", 0.05)); break;
    case "stone": noise(0, 0.1, 0.3, 700, 0.7); tone(120 + r * 30, 0.02, 0.15, "triangle", 0.35, 60); break;
    case "ceramic": noise(0, 0.02, 0.3, 3500, 2); tone(1650 + r * 150, 0, 0.14, "sine", 0.13, 1500); tone(2900, 0, 0.06, "sine", 0.05); break;
    case "glass": tone(1900 + r * 300, 0, 0.25, "sine", 0.14); tone(3800, 0, 0.12, "sine", 0.05); break;
    case "leather": noise(0, 0.06, 0.35, 300, 0.6); tone(95 + r * 15, 0, 0.1, "sine", 0.35, 60); break;
    case "paper": noise(0, 0.09, 0.22, 5000, 0.5); noise(0.03, 0.05, 0.15, 2500, 0.8); break;
    case "toxic": tone(300 + r * 80, 0, 0.18, "sine", 0.18, 900); tone(1200, 0.08, 0.06, "sine", 0.08, 1800); break;
    case "soft": tone(300 + r * 40, 0, 0.1, "sine", 0.2, 200); break;
    case "digital": tone(660 + r * 200, 0, 0.06, "square", 0.07, 990); break;
  }
  // Every skin without its own effect still gets a unique voice derived from its id.
  const signature = themeHash(theme);
  const types: OscillatorType[] = ["sine", "triangle", "square", "sawtooth"];
  const pitch = 260 + signature % 700 + (v % 5) * 22;
  const type = types[signature % 4]!;
  const vol = type === "square" || type === "sawtooth" ? 0.03 : 0.07;
  tone(pitch, 0.03, 0.09 + (signature % 5) * 0.02, type, vol, pitch * (signature % 3 === 0 ? 1.3 : 0.85));
  tone(pitch * [1.5, 2, 1.25, 2.5][(signature >>> 3) % 4]!, 0.05 + (signature % 4) * 0.012, 0.06, "sine", 0.035);
}

/** Distinct victory tune per material. */
const WIN: Record<Material, { n: number[]; step: number; dur: number; type: OscillatorType; vol: number }> = {
  wood: { n: [392, 494, 587, 784, 659, 784], step: 0.13, dur: 0.3, type: "triangle", vol: 0.2 },        // marimba-like
  bamboo: { n: [587, 659, 784, 880, 1175], step: 0.12, dur: 0.25, type: "sine", vol: 0.22 },            // pentatonic flute
  ice: { n: [1568, 1319, 1175, 1568, 2093, 2637], step: 0.09, dur: 0.9, type: "sine", vol: 0.1 },       // music box / chimes
  metal: { n: [523, 784, 1047, 1568], step: 0.16, dur: 1.4, type: "sine", vol: 0.12 },                  // bells
  gold: { n: [523, 659, 784, 1047, 784, 1047, 1319], step: 0.12, dur: 0.8, type: "sine", vol: 0.13 },   // royal fanfare
  steel: { n: [196, 262, 330, 392, 523], step: 0.14, dur: 0.5, type: "sawtooth", vol: 0.06 },           // industrial brass
  stone: { n: [131, 165, 196, 262], step: 0.2, dur: 0.9, type: "triangle", vol: 0.25 },                 // deep drums
  ceramic: { n: [880, 988, 1175, 1319, 1760], step: 0.1, dur: 0.6, type: "sine", vol: 0.12 },           // santur-like
  glass: { n: [1047, 1319, 1568, 2093, 2637], step: 0.1, dur: 0.8, type: "sine", vol: 0.1 },            // glass harp
  leather: { n: [220, 277, 330, 440], step: 0.15, dur: 0.35, type: "triangle", vol: 0.22 },             // tombak groove
  paper: { n: [659, 784, 988, 1319], step: 0.1, dur: 0.2, type: "triangle", vol: 0.15 },                // light pluck
  toxic: { n: [330, 494, 392, 659, 988], step: 0.11, dur: 0.3, type: "square", vol: 0.06 },             // weird lab
  soft: { n: [523, 659, 784, 1047], step: 0.14, dur: 0.6, type: "sine", vol: 0.15 },
  digital: { n: [523, 659, 784, 1047, 1319, 1568], step: 0.07, dur: 0.12, type: "square", vol: 0.07 },  // 8-bit
};
export function playWin(theme = "wood") {
  const wf = WIN_FX[theme]; if (wf) { wf(); return; }
  const m = materialOf(theme), w = WIN[m];
  w.n.forEach((f, i) => tone(f, i * w.step, w.dur, w.type, w.vol));
  const end = w.n.length * w.step;
  if (m === "wood") [0, 0.13, 0.26].forEach((t) => noise(end + t, 0.04, 0.3, 2600, 2));
  if (m === "leather" || m === "stone") [0, 0.15, 0.3, 0.38].forEach((t) => { tone(80, end + t, 0.15, "sine", 0.4, 50); });
  if (m === "ice" || m === "glass") [2093, 2637, 3136].forEach((f, i) => tone(f, end + i * 0.08, 0.8, "sine", 0.05));
  if (m === "metal" || m === "gold") tone(1047, end, 2, "sine", 0.1);
  if (m === "steel") noise(end, 0.3, 0.3, 1500, 0.8);
  if (m === "toxic") tone(200, end, 0.6, "sine", 0.15, 1600);
  if (m === "paper") noise(end, 0.3, 0.2, 4500, 0.4);
  if (m === "digital") tone(2093, end, 0.3, "square", 0.05);
  const signature = themeHash(theme);
  const scales = [[0, 4, 7, 12], [0, 3, 7, 10], [0, 2, 4, 7, 9], [0, 5, 7, 12], [0, 4, 9, 11, 14]];
  const sc = scales[signature % scales.length]!, root = 330 + (signature >>> 2) % 300;
  sc.forEach((st, i) => tone(root * 2 ** (st / 12), end + 0.5 + i * (0.08 + (signature % 3) * 0.03), 0.4, (signature >>> 4) % 2 ? "sine" : "triangle", 0.06));
  const base = 260 + signature % 460;
  tone(base, end + 0.08, 0.42, "sine", 0.045);
  tone(base * (signature % 3 === 0 ? 1.25 : signature % 3 === 1 ? 1.333 : 1.5), end + 0.18, 0.36, "triangle", 0.035);
}
/** Short celebration song for the multiplayer winner. */
export function playVictorySong() {
  const mel: [number, number, number][] = [[523, 0, 0.18], [523, 0.2, 0.18], [523, 0.4, 0.18], [659, 0.6, 0.5], [587, 1.15, 0.2], [659, 1.4, 0.2], [784, 1.65, 0.8]];
  mel.forEach(([f, t, d]) => { tone(f, t, d, "triangle", 0.12); tone(f * 2, t, d * 0.6, "sine", 0.03); });
  [[262, 0], [349, 0.6], [392, 1.15], [523, 1.65]].forEach(([f, t]) => tone(f!, t!, 0.5, "sine", 0.09));
  [0, 0.4, 0.6, 1.15, 1.65].forEach((t) => noise(t, 0.05, 0.12, 3000, 1.5));
}
export function playClick() { tone(900, 0, 0.04, "sine", 0.08, 700); }
/** Short sad melody: out of moves / time up, or losing a duel. */
export function playLose() {
  const mel: [number, number, number][] = [[494, 0, 0.28], [466, 0.3, 0.28], [440, 0.6, 0.28], [415, 0.9, 0.9]];
  mel.forEach(([f, t, d]) => { tone(f, t, d, "triangle", 0.12); tone(f / 2, t, d, "sine", 0.06); });
  tone(415, 0.9, 0.9, "sine", 0.04, 380);
  noise(0.9, 0.08, 0.08, 400, 1);
}
/** Neutral "nobody won" jingle for drawn matches. */
export function playDraw() {
  const mel: [number, number, number][] = [[523, 0, 0.22], [587, 0.25, 0.22], [523, 0.5, 0.22], [587, 0.75, 0.22], [554, 1.0, 0.6]];
  mel.forEach(([f, t, d]) => { tone(f, t, d, "sine", 0.1); tone(f * 1.5, t, d * 0.7, "triangle", 0.03); });
  [0, 0.5, 1.0].forEach((t) => noise(t, 0.04, 0.08, 2000, 1.5));
}

/* ---------- Signature sounds for object-style skins ---------- */
const PIANO = [0, 2, 4, 5, 7, 9, 11];
const pianoHz = (k: number) => 261.63 * 2 ** ((PIANO[k % 7]! + 12 * Math.floor(k / 7)) / 12);
function piano(f: number, t: number, d = 1.2, v = 0.18) {
  tone(f, t, d, "triangle", v); tone(f * 2, t, d * 0.6, "sine", v * 0.35); tone(f * 3, t, d * 0.3, "sine", v * 0.12);
  noise(t, 0.01, v * 0.6, 3000, 1);
}
const clack = (t: number, f: number, v: number, q = 2) => noise(t, 0.012, v, f, q);
const SLIDE_FX: Record<string, (r: number, v: number) => void> = {
  cork: (r) => { noise(0, 0.1, 0.16, 650 + r * 180, 0.6); tone(145 + r * 15, 0.065, 0.1, "sine", 0.3, 85); },
  terrazzo: (r) => { noise(0, 0.075, 0.22, 1200 + r * 150, 0.8); clack(0.055, 2800, 0.4, 2); tone(380, 0.055, 0.12, "triangle", 0.17, 220); },
  rosewood: (r, v) => { noise(0, 0.065, 0.1, 380, 0.7); clack(0.06, 2100 + r * 200, 0.45); tone(220 + (v % 5) * 24, 0.06, 0.23, "triangle", 0.23, 160); tone(690, 0.06, 0.1, "sine", 0.06); },
  nacre: (r, v) => { clack(0, 6100, 0.2, 3); tone(1568 + (v % 6) * 130, 0, 0.4, "sine", 0.09); tone(3200 + r * 180, 0.025, 0.25, "sine", 0.04); },
  billiard: (r) => { // a restrained cue-ball tap, felt roll, and pocket-like knock
    tone(1850 + r * 220, 0, 0.055, "sine", 0.13, 950);
    clack(0.018, 3200 + r * 450, 0.42, 1.1);
    noise(0.035, 0.12, 0.035, 520 + r * 110, 0.45);
    tone(125 + r * 12, 0.11, 0.12, "sine", 0.15, 72);
  },
  "garden-art": (r, v) => {
    tone(440 + (v % 6) * 75 + r * 15, 0, 0.16, "sine", 0.09);
    noise(0.015, 0.045, 0.06, 4400, 1.5);
  },
  "reef-art": (r, v) => {
    tone(520 + (v % 5) * 62, 0, 0.18, "sine", 0.1, 760 + r * 120);
    noise(0.02, 0.12, 0.035, 1050 + r * 250, 0.7);
  },
  "cosmos-art": (r, v) => {
    tone(660 + (v % 7) * 90, 0, 0.22, "triangle", 0.08, 1320 + r * 180);
    tone(1760 + r * 200, 0.025, 0.12, "sine", 0.035);
  },
  lego: (r) => { clack(0, 5200, 0.6, 3); tone(1900 + r * 200, 0, 0.025, "square", 0.05); clack(0.035, 3800, 0.5, 3); tone(1400, 0.035, 0.03, "square", 0.04); },
  piano: (_r, v) => piano(pianoHz((v - 1) % 21), 0, 0.9, 0.16),
  keycap: (r) => { tone(240 + r * 30, 0, 0.06, "sine", 0.4, 140); clack(0, 1300, 0.5, 1); clack(0.04, 2600, 0.2, 2); },
  typewriter: (r) => { clack(0, 2100 + r * 300, 1, 0.8); tone(140, 0, 0.05, "triangle", 0.35, 80); clack(0.05, 5200, 0.15, 3); },
  casino: (r) => { clack(0, 3100 + r * 300, 0.7, 3); tone(2300, 0, 0.03, "sine", 0.1); clack(0.028, 2800, 0.5, 3); clack(0.05, 3300, 0.25, 3); },
  scrabble: (r) => { clack(0, 3600 + r * 300, 0.6, 1.8); tone(880 + r * 80, 0, 0.07, "sine", 0.22, 760); },
  vinyl: (r) => { tone(380 + r * 60, 0, 0.09, "sawtooth", 0.06, 1400); noise(0, 0.1, 0.12, 2200, 0.7); tone(1400, 0.09, 0.08, "sawtooth", 0.04, 420); },
  coin: (r) => [3150, 4120, 5480].forEach((f, i) => tone(f + r * 90, 0, 0.35 - i * 0.08, "sine", 0.09 - i * 0.02)),
  balloon: (r) => { tone(620 + r * 80, 0, 0.14, "sine", 0.16, 1050); tone(1240, 0.02, 0.1, "triangle", 0.05, 1900); noise(0, 0.08, 0.06, 900, 2); },
  chalk: (r) => { noise(0, 0.13, 0.18, 3400 + r * 600, 4); noise(0.02, 0.09, 0.12, 6400, 5); clack(0, 1500, 0.3, 1); },
  cards: () => { noise(0, 0.045, 0.32, 5800, 0.6); noise(0.03, 0.02, 0.2, 2400, 1); },
  dice: (r) => [0, 0.045 + r * 0.02, 0.085, 0.11].forEach((t, i) => clack(t, 2800 + i * 300, 0.7 - i * 0.15, 2.5)),
  mahjong: (r) => { clack(0, 2600 + r * 300, 0.85, 2); tone(1100 + r * 100, 0, 0.06, "triangle", 0.18, 950); },
  domino: (r) => { clack(0, 2400 + r * 300, 0.9, 1.6); tone(620 + r * 60, 0, 0.05, "triangle", 0.2, 480); clack(0.03, 3400, 0.3, 2); },
  crystal: (r, v) => { tone(1760 + (v % 7) * 110, 0, 0.6, "sine", 0.1); tone(2640 + r * 200, 0, 0.35, "sine", 0.05); },
  stained: (r) => { tone(1320 + r * 200, 0, 0.4, "sine", 0.08); tone(1980, 0.01, 0.25, "sine", 0.04); noise(0, 0.03, 0.15, 5000, 2); },
  marquee: (r) => { tone(880 + r * 100, 0, 0.08, "square", 0.05); tone(1320, 0.05, 0.1, "square", 0.04); },
  bubblewrap: (r) => { noise(0, 0.025, 0.9, 1800 + r * 900, 0.8); tone(300, 0, 0.03, "sine", 0.3, 90); },
  cookie: (r) => { for (let i = 0; i < 4; i++) noise(i * 0.018, 0.02, 0.4, 2200 + r * 1500, 1); },
  led: (_r, v) => tone(660 + (v % 5) * 110, 0, 0.07, "square", 0.06),
  stamp: (r) => { tone(110 + r * 20, 0, 0.1, "sine", 0.5, 60); noise(0, 0.05, 0.3, 900, 0.8); },
  button: (r) => { clack(0, 3000 + r * 500, 0.5, 3); tone(1500, 0, 0.03, "sine", 0.1); },
  bottlecap: (r) => { [2700, 3900, 5200].forEach((f, i) => tone(f + r * 200, 0, 0.15 - i * 0.03, "triangle", 0.07)); clack(0, 4500, 0.4, 2); },
  jelly: (r) => { tone(180 + r * 30, 0, 0.18, "sine", 0.4, 420); tone(420, 0.06, 0.12, "sine", 0.15, 200); },
  brick: (r) => { tone(90 + r * 15, 0, 0.12, "sine", 0.6, 55); noise(0, 0.08, 0.4, 600, 0.6); noise(0.02, 0.1, 0.12, 2400, 1); },
  terminal: (r) => { tone(1200 + r * 300, 0, 0.03, "square", 0.05); clack(0.01, 1800, 0.25, 2); },
  blueprint: (r) => { noise(0, 0.12, 0.15, 4200 + r * 800, 3); noise(0.08, 0.06, 0.1, 5600, 3); },
  newspaper: (r) => { noise(0, 0.12, 0.3, 3000 + r * 1000, 0.5); noise(0.05, 0.08, 0.2, 1400, 0.6); },
  clay: (r) => { tone(140 + r * 30, 0, 0.12, "sine", 0.5, 80); noise(0, 0.05, 0.15, 500, 0.7); },
  circuit: (_r, v) => { tone(440 * 2 ** ((v % 8) / 8), 0, 0.05, "square", 0.05); tone(1760, 0.04, 0.04, "sine", 0.06); },
  ticket: (r) => { for (let i = 0; i < 6; i++) noise(i * 0.012, 0.012, 0.3, 4000 + r * 800, 2); },
  pearl: (r) => { tone(2400 + r * 400, 0, 0.12, "sine", 0.1); clack(0, 6000, 0.3, 3); },
  rune: (r) => { tone(70 + r * 10, 0, 0.3, "sine", 0.5, 50); tone(880, 0.05, 0.5, "sine", 0.05, 1320); noise(0, 0.1, 0.2, 700, 0.6); },
  denim: (r) => { noise(0, 0.09, 0.35, 700 + r * 300, 0.7); tone(120, 0, 0.06, "sine", 0.25, 80); },
  macaron: (r) => { tone(240 + r * 40, 0, 0.08, "sine", 0.35, 140); noise(0, 0.03, 0.15, 3000, 1); },
};
const seq = (n: number[], step: number, fn: (f: number, t: number) => void) => n.forEach((f, i) => fn(f, i * step));
const WIN_FX: Record<string, () => void> = {
  cork: () => seq([262, 349, 440, 523, 440, 698], 0.14, (f, t) => { tone(f, t, 0.24, "triangle", 0.17); noise(t, 0.025, 0.12, 700, 0.6); }),
  terrazzo: () => seq([196, 294, 392, 494, 587, 784], 0.16, (f, t) => { tone(f, t, 0.5, "triangle", 0.16); clack(t, 2700, 0.15); tone(f * 3, t, 0.2, "sine", 0.035); }),
  rosewood: () => seq([220, 330, 440, 554, 659, 880, 659, 880], 0.12, (f, t) => { tone(f, t, 0.55, "triangle", 0.16); tone(f * 2, t, 0.22, "sine", 0.04); }),
  nacre: () => { seq([1175, 1480, 1760, 2349, 2960], 0.17, (f, t) => { tone(f, t, 1.15, "sine", 0.075); tone(f * 1.5, t + 0.06, 0.6, "sine", 0.025); }); tone(587, 0.8, 1.8, "sine", 0.06); },
  billiard: () => { // two clean ball contacts, a pocket drop, and a compact win chord
    clack(0, 3900, 0.55, 1.2);
    tone(1780, 0.015, 0.09, "sine", 0.12, 900);
    clack(0.18, 3100, 0.38, 1.1);
    tone(112, 0.34, 0.23, "sine", 0.38, 58);
    noise(0.35, 0.16, 0.13, 360, 0.6);
    [262, 330, 392, 523].forEach((f, i) => tone(f, 0.62 + i * 0.08, 0.72, "triangle", 0.075));
  },
  "garden-art": () => seq([392, 494, 587, 784, 698, 587], 0.15, (f, t) => {
    tone(f, t, 0.42, "sine", 0.09);
    tone(f * 2, t + 0.035, 0.23, "sine", 0.025);
  }),
  "reef-art": () => {
    seq([523, 659, 784, 988, 880, 1175], 0.13, (f, t) => tone(f, t, 0.5, "sine", 0.075, f * 0.98));
    noise(0.25, 0.5, 0.025, 780, 0.5);
  },
  "cosmos-art": () => {
    seq([392, 587, 784, 1175, 1568], 0.12, (f, t) => {
      tone(f, t, 0.7, "triangle", 0.075);
      tone(f * 1.5, t + 0.03, 0.48, "sine", 0.025);
    });
  },
  lego: () => { for (let i = 0; i < 8; i++) clack(i * 0.08, 5000, 0.5, 3); seq([523, 659, 784, 1047, 1319], 0.1, (f, t) => tone(f, t + 0.7, 0.25, "square", 0.05)); },
  piano: () => { seq([262, 330, 392, 523, 659, 784, 1047], 0.1, (f, t) => piano(f, t, 1.3, 0.13)); [262, 330, 392, 523].forEach((f) => piano(f, 0.9, 2.2, 0.1)); },
  keycap: () => { for (let i = 0; i < 12; i++) { tone(230, i * 0.06, 0.05, "sine", 0.3, 140); clack(i * 0.06, 1300, 0.4); } tone(180, 0.8, 0.12, "sine", 0.5, 90); seq([659, 784, 988], 0.09, (f, t) => tone(f, t + 0.95, 0.3, "triangle", 0.1)); },
  typewriter: () => { for (let i = 0; i < 9; i++) clack(i * 0.07, 2100, 0.8, 0.8); for (let i = 0; i < 6; i++) clack(0.7 + i * 0.03, 4000, 0.25, 4); tone(2093, 0.95, 1.6, "sine", 0.18); tone(4186, 0.95, 0.8, "sine", 0.05); },
  casino: () => { for (let i = 0; i < 16; i++) clack(i * 0.03, 3000 + (i % 3) * 200, 0.5, 3); seq([784, 988, 1175, 1568, 1175, 1568, 1976], 0.08, (f, t) => tone(f, t + 0.55, 0.2, "square", 0.05)); tone(1568, 1.15, 1, "sine", 0.1); },
  scrabble: () => seq([523, 587, 659, 784, 880, 1047], 0.11, (f, t) => { clack(t, 3600, 0.4); tone(f, t, 0.35, "triangle", 0.18); }),
  vinyl: () => { for (let i = 0; i < 30; i++) noise(Math.random() * 2, 0.004, 0.15, 3000, 1); seq([196, 247, 294, 370, 440], 0.18, (f, t) => tone(f, t + 0.2, 1.2, "sine", 0.1)); tone(98, 0.2, 1.8, "triangle", 0.15); },
  coin: () => { for (let i = 0; i < 14; i++) { const t = i * 0.06 + Math.random() * 0.03; [3150, 4120].forEach((f) => tone(f + Math.random() * 400, t, 0.3, "sine", 0.06)); } seq([1047, 1319, 1568, 2093], 0.09, (f, t) => tone(f, t + 0.95, 0.5, "sine", 0.1)); },
  balloon: () => { [0, 0.25, 0.45, 0.6].forEach((t) => { noise(t, 0.07, 0.8, 1200, 0.5); tone(150, t, 0.06, "sine", 0.3, 60); }); seq([523, 659, 784, 1047], 0.12, (f, t) => tone(f, t + 0.8, 0.4, "sine", 0.14, f * 1.02)); },
  chalk: () => { noise(0, 0.25, 0.15, 3800, 4); noise(0.3, 0.25, 0.15, 4200, 4); for (let i = 0; i < 10; i++) tone(i % 2 ? 1480 : 1500, 0.65 + i * 0.05, 0.06, "sine", 0.12); seq([784, 659, 784, 1047], 0.14, (f, t) => tone(f, t + 1.25, 0.3, "triangle", 0.14)); },
  cards: () => { for (let i = 0; i < 22; i++) noise(i * 0.025, 0.02, 0.22, 5000, 0.8); noise(0.6, 0.06, 0.3, 1500, 0.8); seq([659, 831, 988, 1319], 0.1, (f, t) => tone(f, t + 0.75, 0.4, "triangle", 0.13)); },
  dice: () => { for (let i = 0; i < 18; i++) clack(i * 0.04 + Math.random() * 0.03, 2600 + Math.random() * 900, 0.7 - i * 0.03, 2.5); seq([392, 523, 659, 784], 0.1, (f, t) => tone(f, t + 0.9, 0.5, "triangle", 0.15)); },
  mahjong: () => { tone(110, 0, 2.5, "sine", 0.3); tone(220, 0, 1.6, "sine", 0.1); tone(330, 0, 1, "sine", 0.05); seq([587, 659, 784, 880, 1175, 1319], 0.13, (f, t) => tone(f, t + 0.4, 0.5, "sine", 0.12)); },
  domino: () => { for (let i = 0; i < 20; i++) clack(i * 0.06 * (1 - i * 0.02), 2400 + i * 40, 0.7, 1.6); seq([392, 494, 587, 784], 0.12, (f, t) => tone(f, t + 1.1, 0.5, "triangle", 0.14)); },
  crystal: () => seq([1319, 1568, 1976, 2637, 3136], 0.12, (f, t) => { tone(f, t, 1.4, "sine", 0.08); tone(f * 1.5, t, 0.6, "sine", 0.03); }),
  stained: () => { [262, 330, 392, 523].forEach((f) => tone(f, 0, 2.5, "sine", 0.07)); seq([1047, 1319, 1568, 2093], 0.2, (f, t) => tone(f, t + 0.3, 0.9, "sine", 0.06)); },
  marquee: () => seq([523, 659, 784, 1047, 784, 1047, 1319, 1568], 0.09, (f, t) => tone(f, t, 0.12, "square", 0.05)),
  bubblewrap: () => { for (let i = 0; i < 18; i++) noise(i * 0.05 + Math.random() * 0.03, 0.025, 0.9, 1500 + Math.random() * 1500, 0.8); seq([523, 659, 784], 0.1, (f, t) => tone(f, t + 1.1, 0.4, "sine", 0.12)); },
  cookie: () => { for (let i = 0; i < 14; i++) noise(i * 0.03, 0.025, 0.4, 2500, 1); seq([440, 554, 659, 880], 0.12, (f, t) => tone(f, t + 0.6, 0.45, "triangle", 0.14)); },
  led: () => { seq([988, 988, 988, 1319], 0.18, (f, t) => tone(f, t, 0.14, "square", 0.07)); tone(80, 0.8, 0.9, "sawtooth", 0.08); },
  stamp: () => { [0, 0.18, 0.36].forEach((t) => { tone(100, t, 0.12, "sine", 0.5, 55); noise(t, 0.05, 0.3, 900, 0.8); }); seq([587, 740, 880], 0.12, (f, t) => tone(f, t + 0.6, 0.5, "triangle", 0.12)); },
  button: () => { for (let i = 0; i < 8; i++) clack(i * 0.07, 3200, 0.4, 3); seq([659, 784, 988, 1319], 0.1, (f, t) => tone(f, t + 0.6, 0.4, "sine", 0.12)); },
  bottlecap: () => { noise(0, 0.4, 0.25, 4000, 0.4); for (let i = 0; i < 6; i++) tone(2800 + Math.random() * 1500, 0.4 + i * 0.07, 0.2, "triangle", 0.05); seq([523, 659, 784, 1047], 0.1, (f, t) => tone(f, t + 0.9, 0.4, "square", 0.04)); },
  jelly: () => seq([262, 330, 392, 523, 659], 0.13, (f, t) => tone(f, t, 0.3, "sine", 0.25, f * 1.6)),
  brick: () => { for (let i = 0; i < 6; i++) { tone(80, i * 0.12, 0.15, "sine", 0.5, 50); noise(i * 0.12, 0.08, 0.35, 600, 0.6); } seq([196, 262, 330, 392], 0.15, (f, t) => tone(f, t + 0.8, 0.6, "triangle", 0.15)); },
  terminal: () => { for (let i = 0; i < 16; i++) tone(800 + Math.random() * 1200, i * 0.035, 0.03, "square", 0.04); seq([440, 880, 1760], 0.12, (f, t) => tone(f, t + 0.65, 0.3, "square", 0.05)); },
  blueprint: () => { noise(0, 0.5, 0.12, 4500, 3); seq([392, 523, 659, 784, 1047], 0.11, (f, t) => tone(f, t + 0.5, 0.4, "triangle", 0.12)); },
  newspaper: () => { noise(0, 0.3, 0.3, 2500, 0.5); noise(0.3, 0.2, 0.25, 1500, 0.5); seq([349, 440, 523, 698], 0.14, (f, t) => tone(f, t + 0.6, 0.5, "triangle", 0.14)); },
  clay: () => seq([196, 247, 294, 392, 494], 0.12, (f, t) => tone(f, t, 0.35, "sine", 0.3, f * 0.8)),
  circuit: () => { seq([440, 554, 659, 880, 1109, 1319, 1760], 0.06, (f, t) => tone(f, t, 0.08, "square", 0.05)); tone(1760, 0.5, 0.8, "sine", 0.08); },
  ticket: () => { for (let i = 0; i < 12; i++) noise(i * 0.015, 0.012, 0.3, 4200, 2); seq([523, 659, 784, 1047, 1319], 0.15, (f, t) => tone(f, t + 0.4, 0.6, "triangle", 0.12)); },
  pearl: () => { for (let i = 0; i < 12; i++) tone(2000 + Math.random() * 1500, i * 0.06, 0.15, "sine", 0.06); seq([1047, 1319, 1568], 0.15, (f, t) => tone(f, t + 0.8, 1, "sine", 0.08)); },
  rune: () => { tone(55, 0, 2, "sine", 0.4); seq([440, 523, 659, 880, 1047], 0.18, (f, t) => tone(f, t + 0.2, 1, "sine", 0.06, f * 1.01)); },
  denim: () => { for (let i = 0; i < 6; i++) noise(i * 0.08, 0.07, 0.3, 800, 0.7); seq([330, 392, 494, 659], 0.12, (f, t) => tone(f, t + 0.6, 0.5, "triangle", 0.14)); },
  macaron: () => seq([659, 784, 988, 1175, 1319], 0.11, (f, t) => tone(f, t, 0.4, "sine", 0.15)),
};

/* ---------- Signature sounds for premium texture skins (one slide + one victory tune each) ---------- */
const pluck = (f: number, t: number, d = 0.5, v = 0.12) => { tone(f, t, d, "triangle", v, f * 0.995); tone(f * 2, t, d * 0.5, "sine", v * 0.3); noise(t, 0.008, v * 0.8, 3500, 2); };
const bell = (f: number, t: number, d = 1.2, v = 0.07) => { tone(f, t, d, "sine", v); tone(f * 2.76, t, d * 0.5, "sine", v * 0.35); tone(f * 5.4, t, d * 0.25, "sine", v * 0.15); };
const thump = (f: number, t: number, v = 0.35) => tone(f, t, 0.14, "sine", v, f * 0.55);
const daf = (t: number, v = 0.4) => { thump(95, t, v); noise(t, 0.09, v * 0.35, 2600, 0.7); };
// Persian "shur"-like and other small scales for victory tunes
const SHUR = [293.66, 311.13, 349.23, 392, 440, 466.16, 523.25, 587.33];
Object.assign(SLIDE_FX, {
  "leopard-weave": (r: number) => { noise(0, 0.08, 0.22, 420 + r * 120, 0.6); thump(110 + r * 15, 0.04, 0.3); noise(0.05, 0.12, 0.05, 180, 0.8); },
  "zebra-silk": (r: number) => { noise(0, 0.14, 0.12, 5200 + r * 900, 0.9); tone(990 + r * 80, 0.05, 0.09, "sine", 0.05, 1320); },
  "pink-embroidery": (r: number, v: number) => { noise(0, 0.05, 0.12, 2200, 0.8); bell(1760 + (v % 5) * 120 + r * 20, 0.03, 0.35, 0.05); },
  "rose-marble": (r: number) => { clack(0, 2600 + r * 300, 0.4, 1.4); tone(520 + r * 40, 0, 0.22, "sine", 0.12, 470); tone(1560, 0.01, 0.12, "sine", 0.04); },
  "persian-mosaic": (r: number, v: number) => { clack(0, 3400 + r * 300, 0.4, 2); pluck(SHUR[v % 8]! * 2, 0.01, 0.35, 0.09); },
  minakari: (r: number, v: number) => { clack(0, 5200, 0.25, 3); bell(2093 + (v % 6) * 130 + r * 30, 0, 0.5, 0.05); },
  khatam: (r: number) => { clack(0, 2300 + r * 200, 0.6, 1.8); clack(0.035, 3300 + r * 200, 0.35, 2.2); tone(330 + r * 30, 0, 0.1, "triangle", 0.18, 250); },
  "iranian-brocade": (r: number) => { noise(0, 0.07, 0.18, 1600 + r * 300, 0.7); daf(0.03, 0.28); },
  "iran-flag-weave": (r: number, v: number) => { noise(0, 0.09, 0.16, 900 + r * 300, 0.5); pluck(SHUR[(v + 2) % 8]!, 0.04, 0.45, 0.13); },
  "emerald-velvet": (r: number) => { noise(0, 0.1, 0.16, 300 + r * 80, 0.5); thump(130 + r * 15, 0.03, 0.35); },
  peacock: (r: number) => { noise(0, 0.1, 0.12, 3800 + r * 600, 0.7); tone(2400 + r * 300, 0.06, 0.07, "sine", 0.06, 3600); tone(3000, 0.13, 0.05, "sine", 0.04, 2400); },
  lapis: (r: number) => { noise(0, 0.07, 0.22, 900, 0.7); tone(180 + r * 20, 0.02, 0.18, "triangle", 0.25, 120); bell(1175 + r * 40, 0.04, 0.4, 0.035); },
  "white-gold-marble": (r: number) => { clack(0, 3000 + r * 300, 0.45, 1.5); tone(640, 0, 0.16, "sine", 0.1, 560); bell(2637, 0.02, 0.3, 0.03); },
  "obsidian-prism": (r: number, v: number) => { tone(2093 + (v % 7) * 150 + r * 50, 0, 0.45, "sine", 0.08); tone(3136 + r * 120, 0.015, 0.3, "sine", 0.04); noise(0, 0.02, 0.18, 7000, 2); },
  "icon-wood": (r: number) => { thump(180 + r * 25, 0, 0.09); noise(0, 0.035, 0.12, 2200, 1.4); },
  "black-gold-marble": (r: number) => { noise(0, 0.06, 0.3, 700, 0.6); tone(140 + r * 15, 0, 0.18, "sine", 0.4, 90); bell(1568 + r * 40, 0.04, 0.6, 0.05); },
});
Object.assign(WIN_FX, {
  "leopard-weave": () => { [0, 0.18, 0.36, 0.54, 0.63, 0.72].forEach((t) => thump(85, t, 0.4)); seq([220, 262, 330, 392, 440], 0.12, (f, t) => tone(f, t + 0.85, 0.5, "sawtooth", 0.04)); },
  "zebra-silk": () => { noise(0, 0.5, 0.06, 5000, 0.8); seq([523, 659, 784, 988, 1175, 1319], 0.1, (f, t) => tone(f, t + 0.1, 0.5, "sine", 0.08)); },
  "pink-embroidery": () => seq([1047, 1175, 1319, 1568, 1760, 2093], 0.12, (f, t) => bell(f, t, 0.9, 0.06)),
  "rose-marble": () => { seq([392, 494, 587, 740, 880], 0.16, (f, t) => tone(f, t, 0.9, "sine", 0.09)); bell(1480, 0.9, 1.6, 0.05); },
  "persian-mosaic": () => seq([SHUR[0]!, SHUR[1]!, SHUR[2]!, SHUR[3]!, SHUR[2]!, SHUR[1]!, SHUR[3]!, SHUR[4]!].map((f) => f * 2), 0.13, (f, t) => pluck(f, t, 0.5, 0.11)),
  minakari: () => { seq([1175, 1397, 1568, 1760, 2093, 2349], 0.1, (f, t) => bell(f, t, 1, 0.05)); },
  khatam: () => { for (let i = 0; i < 8; i++) clack(i * 0.07, 2400 + (i % 2) * 900, 0.5, 2); seq([SHUR[0]!, SHUR[2]!, SHUR[3]!, SHUR[4]!, SHUR[6]!], 0.14, (f, t) => pluck(f * 2, t + 0.6, 0.6, 0.1)); },
  "iranian-brocade": () => { [0, 0.2, 0.3, 0.5, 0.7, 0.8].forEach((t) => daf(t, 0.35)); seq([SHUR[0]!, SHUR[3]!, SHUR[4]!, SHUR[5]!, SHUR[4]!, SHUR[7]!], 0.14, (f, t) => tone(f * 2, t + 0.95, 0.5, "triangle", 0.09)); },
  "iran-flag-weave": () => seq([SHUR[0]!, SHUR[2]!, SHUR[3]!, SHUR[4]!, SHUR[5]!, SHUR[4]!, SHUR[3]!, SHUR[7]!], 0.15, (f, t) => pluck(f, t, 0.7, 0.14)),
  "emerald-velvet": () => { seq([262, 330, 392, 523, 659], 0.18, (f, t) => tone(f, t, 1, "sine", 0.1)); [262, 330, 392].forEach((f) => tone(f, 1, 1.6, "triangle", 0.05)); },
  peacock: () => { for (let i = 0; i < 6; i++) tone(2200 + i * 150, i * 0.09, 0.07, "sine", 0.06, 3400); seq([784, 988, 1175, 1568], 0.13, (f, t) => tone(f, t + 0.7, 0.6, "sine", 0.09)); },
  lapis: () => { thump(110, 0, 0.45); seq([587, 698, 880, 1047, 1397], 0.15, (f, t) => bell(f, t + 0.1, 1.2, 0.06)); },
  "white-gold-marble": () => { seq([523, 659, 784, 1047, 1319, 1568], 0.11, (f, t) => tone(f, t, 0.7, "sine", 0.08)); bell(2093, 0.8, 1.8, 0.06); },
  "obsidian-prism": () => { seq([1568, 1976, 2349, 3136, 2637, 3136], 0.1, (f, t) => tone(f, t, 0.9, "sine", 0.06)); noise(0.6, 0.4, 0.04, 8000, 1); },
  "icon-wood": () => { seq([523, 659, 784, 1047], 0.11, (f, t) => { thump(f / 3, t, 0.12); tone(f, t, 0.35, "triangle", 0.12); }); },
  "black-gold-marble": () => { thump(90, 0, 0.5); seq([392, 523, 659, 784, 1047], 0.15, (f, t) => bell(f, t + 0.15, 1.4, 0.07)); tone(196, 0.15, 1.8, "triangle", 0.08); },
});

/* ---------- Signature sounds: luxury CSS skins + the 3D special skins ---------- */
Object.assign(SLIDE_FX, {
  "imperial-jade": (r: number) => { clack(0, 2900 + r * 200, 0.45, 2.4); tone(1320 + r * 60, 0.005, 0.25, "sine", 0.06, 1250); },
  sapphire: (r: number, v: number) => { tone(2637 + (v % 5) * 110 + r * 40, 0, 0.35, "sine", 0.06); clack(0, 6000, 0.2, 3); },
  "royal-gold": (r: number) => { tone(988 + r * 40, 0, 0.6, "sine", 0.08); tone(2470 + r * 60, 0, 0.3, "sine", 0.04); noise(0, 0.02, 0.15, 4500, 2); },
  "rainbow-opal": (r: number, v: number) => { tone(784 * 2 ** ((v % 6) / 6) + r * 20, 0, 0.3, "sine", 0.07, 1047); tone(1568, 0.04, 0.2, "triangle", 0.03); },
  // Dragon hearts: a hot crackle plus a deep ember breath
  "dragon-hearts": (r: number) => { noise(0, 0.18, 0.18, 1200 + r * 600, 0.4); tone(65 + r * 10, 0, 0.35, "sawtooth", 0.08, 45); [0.03, 0.07, 0.12].forEach((t) => noise(t, 0.01, 0.2, 5000, 3)); },
  // Magic orbs: a glassy rolling ball with a shimmering wobble
  "magic-orbs": (r: number, v: number) => { noise(0, 0.12, 0.08, 2600, 1.2); tone(660 + (v % 7) * 70 + r * 30, 0.02, 0.6, "sine", 0.07, 880); tone(1980, 0.05, 0.4, "sine", 0.03, 2640); },
  // Geode: crystal shards chiming against stone
  geode: (r: number) => { clack(0, 4200 + r * 400, 0.5, 4); bell(3136 + r * 200, 0.01, 0.5, 0.05); bell(4186, 0.04, 0.3, 0.025); },
  // Planets: a deep cosmic whoosh with a low orbit hum
  planets: (r: number) => { noise(0, 0.3, 0.1, 400 + r * 200, 0.4); tone(110 + r * 20, 0, 0.5, "sine", 0.18, 82); tone(1760, 0.1, 0.3, "sine", 0.02, 1320); },
  // Mercury: a liquid blip that bends upward
  mercury: (r: number) => { tone(300 + r * 80, 0, 0.12, "sine", 0.25, 900 + r * 200); tone(1200, 0.08, 0.08, "sine", 0.06, 1800); },
  // Void portal: a reverse-sucked swoosh into nothing
  "void-portal": (r: number) => { tone(1400 + r * 200, 0, 0.35, "sine", 0.06, 90); noise(0, 0.3, 0.12, 300, 0.5); tone(45, 0.1, 0.4, "sine", 0.3, 30); },
  "billiard-royal": (r: number) => { clack(0, 3600 + r * 350, 0.48, 1.2); tone(1650 + r * 100, 0.01, 0.09, "sine", 0.11, 780); noise(0.04, 0.1, 0.04, 500, 0.5); tone(115, 0.09, 0.13, "sine", 0.14, 70); },
  "crystal-heart": (r: number) => { tone(640 + r * 90, 0, 0.24, "triangle", 0.08, 920); bell(1320 + r * 80, 0.035, 0.42, 0.035); },
  "star-cascade": (r: number, v: number) => { bell(1760 + (v % 5) * 170 + r * 50, 0, 0.36, 0.05); tone(2640, 0.035, 0.16, "sine", 0.035); },
  "solar-medallion": (r: number) => { clack(0, 3200 + r * 180, 0.4, 2); bell(880 + r * 60, 0.02, 0.42, 0.055); },
  "moon-pearl": (r: number) => { tone(740 + r * 40, 0, 0.35, "sine", 0.07, 420); bell(1175, 0.08, 0.55, 0.035); },
  "rainbow-orbit": (r: number, v: number) => { tone(523 * 2 ** ((v % 7) / 12) + r * 35, 0, 0.22, "sine", 0.06, 880); tone(1568, 0.04, 0.22, "triangle", 0.03, 2093); },
  "sapphire-shard": (r: number) => { clack(0, 5200 + r * 320, 0.35, 3); bell(2093 + r * 100, 0.01, 0.5, 0.045); },
  "lotus-ember": (r: number) => { tone(196 + r * 25, 0, 0.28, "sine", 0.12, 130); bell(784 + r * 45, 0.04, 0.4, 0.04); },
  "prism-rainbow": (r: number, v: number) => { tone(880 * 2 ** ((v % 6) / 8), 0, 0.25, "sine", 0.06, 1320 + r * 50); bell(1760, 0.06, 0.4, 0.03); },
});
Object.assign(WIN_FX, {
  "imperial-jade": () => seq([587, 659, 784, 880, 1175], 0.14, (f, t) => { pluck(f, t, 0.7, 0.1); }),
  sapphire: () => { seq([1319, 1568, 1976, 2637], 0.1, (f, t) => bell(f, t, 1.2, 0.06)); noise(0.4, 0.5, 0.03, 9000, 1); },
  "royal-gold": () => { seq([523, 659, 784, 1047], 0.13, (f, t) => tone(f, t, 0.8, "triangle", 0.09)); tone(1047, 0.6, 2, "sine", 0.1); bell(2093, 0.65, 1.6, 0.05); },
  "rainbow-opal": () => seq([523, 587, 659, 784, 880, 1047, 1175, 1319], 0.08, (f, t) => tone(f, t, 0.5, "sine", 0.07, f * 1.02)),
  "dragon-hearts": () => { tone(55, 0, 1.6, "sawtooth", 0.1, 40); noise(0, 1.2, 0.12, 900, 0.3); seq([220, 262, 330, 392, 523], 0.16, (f, t) => tone(f, t + 0.3, 0.6, "sawtooth", 0.05)); thump(70, 1.2, 0.5); },
  "magic-orbs": () => { seq([523, 784, 659, 988, 784, 1175, 1568], 0.1, (f, t) => tone(f, t, 0.9, "sine", 0.06, f * 1.01)); tone(262, 0, 1.6, "sine", 0.06, 270); },
  geode: () => { seq([2093, 2637, 3136, 3951, 4186], 0.09, (f, t) => bell(f, t, 1.4, 0.05)); clack(0.5, 5000, 0.3, 3); },
  planets: () => { tone(65, 0, 2.4, "sine", 0.25); tone(98, 0.3, 2, "sine", 0.12); seq([392, 587, 784, 1175], 0.35, (f, t) => tone(f, t + 0.2, 1.4, "sine", 0.05)); },
  mercury: () => seq([400, 600, 500, 800, 700, 1100, 1500], 0.07, (f, t) => tone(f, t, 0.15, "sine", 0.15, f * 1.6)),
  "void-portal": () => { tone(2000, 0, 1.2, "sine", 0.06, 60); noise(0, 1.2, 0.1, 250, 0.4); tone(40, 0.9, 1.5, "sine", 0.4, 30); seq([220, 233, 330, 349], 0.2, (f, t) => tone(f, t + 1, 0.8, "triangle", 0.05)); },
  "billiard-royal": () => { clack(0, 3900, 0.5, 1.2); tone(105, 0.18, 0.24, "sine", 0.34, 58); noise(0.24, 0.16, 0.1, 350, 0.6); seq([262, 330, 392, 523], 0.1, (f, t) => tone(f, t + 0.5, 0.62, "triangle", 0.07)); },
  "crystal-heart": () => seq([523, 659, 784, 1047, 1319], 0.13, (f, t) => { tone(f, t, 0.62, "triangle", 0.07); bell(f * 2, t + 0.03, 0.7, 0.025); }),
  "star-cascade": () => seq([784, 988, 1175, 1568, 1976, 2349], 0.1, (f, t) => bell(f, t, 0.9, 0.045)),
  "solar-medallion": () => { seq([392, 523, 659, 784], 0.14, (f, t) => tone(f, t, 0.7, "triangle", 0.08)); bell(1568, 0.56, 1.4, 0.06); },
  "moon-pearl": () => seq([1047, 880, 784, 659, 523], 0.18, (f, t) => tone(f, t, 0.8, "sine", 0.06, f * 0.98)),
  "rainbow-orbit": () => seq([523, 659, 784, 988, 1175, 1397, 1568], 0.11, (f, t) => { tone(f, t, 0.65, "sine", 0.055); tone(f * 1.5, t + 0.02, 0.4, "triangle", 0.022); }),
  "sapphire-shard": () => seq([1319, 1760, 2093, 2637, 3136], 0.11, (f, t) => bell(f, t, 1.1, 0.045)),
  "lotus-ember": () => { tone(110, 0, 1.6, "sine", 0.16, 73); seq([330, 392, 494, 659, 784], 0.14, (f, t) => tone(f, t + 0.2, 0.8, "triangle", 0.055)); thump(70, 0.6, 0.3); },
  "prism-rainbow": () => seq([587, 740, 880, 1175, 1397, 1760, 2349], 0.09, (f, t) => tone(f, t, 0.55, "sine", 0.06, f * 1.02)),
});

/* ---------- Sounds: more special skins + new picture skins ---------- */
Object.assign(SLIDE_FX, {
  "soap-bubbles": (r: number) => { tone(500 + r * 300, 0, 0.08, "sine", 0.18, 1400 + r * 300); tone(2200, 0.06, 0.05, "sine", 0.05, 3000); },
  "gold-orbs": (r: number) => { noise(0, 0.15, 0.08, 1800, 0.8); bell(1047 + r * 60, 0.02, 0.8, 0.06); tone(130, 0, 0.2, "sine", 0.25, 90); },
  "holo-foil": (r: number) => { noise(0, 0.07, 0.15, 6500 + r * 1000, 1); tone(1760 + r * 400, 0.02, 0.15, "square", 0.025, 2640); },
  "ember-cubes": (r: number) => { thump(90 + r * 20, 0, 0.4); noise(0, 0.2, 0.15, 900 + r * 400, 0.4); [0.04, 0.09].forEach((t) => noise(t, 0.01, 0.2, 4500, 3)); },
  "isfahan-art": (_r: number, v: number) => pluck(SHUR[v % 8]!, 0, 0.6, 0.12),
  "autumn-art": (r: number) => { noise(0, 0.12, 0.12, 2500 + r * 800, 0.6); tone(880 + r * 100, 0.03, 0.1, "sine", 0.04); },
  "aurora-art": (r: number, v: number) => { tone(523 * 2 ** ((v % 5) / 5), 0, 0.5, "sine", 0.07, 540); noise(0, 0.05, 0.08, 7000, 2); },
  "bazaar-art": (r: number) => { pluck(330 + r * 120, 0, 0.4, 0.1); },
  "catspace-art": (r: number) => { tone(880 + r * 300, 0, 0.15, "sine", 0.06, 1400); },
  "amir-anime-art": (r: number) => { tone(660 + r * 200, 0, 0.12, "triangle", 0.07, 990); tone(1320, 0.05, 0.08, "sine", 0.04); },
  "neoncity-art": (r: number) => { tone(220 + r * 40, 0, 0.12, "sawtooth", 0.05, 660); tone(1320, 0.04, 0.06, "square", 0.03); },
});
Object.assign(WIN_FX, {
  "soap-bubbles": () => seq([600, 900, 750, 1200, 1000, 1500, 1800], 0.08, (f, t) => tone(f, t, 0.1, "sine", 0.15, f * 2)),
  "gold-orbs": () => { seq([523, 659, 784, 1047, 1319], 0.14, (f, t) => bell(f, t, 1.6, 0.07)); noise(0.7, 0.8, 0.05, 3000, 0.6); },
  "holo-foil": () => seq([784, 988, 1175, 1568, 1976, 2349], 0.07, (f, t) => tone(f, t, 0.3, "square", 0.04)),
  "ember-cubes": () => { [0, 0.2, 0.4].forEach((t) => thump(70, t, 0.5)); seq([196, 262, 330, 392, 523], 0.13, (f, t) => tone(f, t + 0.5, 0.6, "sawtooth", 0.05)); },
  "isfahan-art": () => { seq(SHUR, 0.11, (f, t) => pluck(f, t, 0.7, 0.1)); daf(0.95, 0.4); },
  "autumn-art": () => seq([392, 440, 523, 587, 659, 784], 0.13, (f, t) => tone(f, t, 0.6, "triangle", 0.09)),
  "aurora-art": () => seq([523, 659, 784, 988, 1175], 0.22, (f, t) => tone(f, t, 1.6, "sine", 0.06, f * 1.01)),
  "bazaar-art": () => seq([294, 330, 349, 392, 440], 0.1, (f, t) => pluck(f, t, 0.5, 0.1)),
  "catspace-art": () => seq([523, 784, 1047, 1568], 0.1, (f, t) => tone(f, t, 0.3, "sine", 0.08)),
  "amir-anime-art": () => seq([523, 659, 784, 1047, 1319, 1568], 0.09, (f, t) => tone(f, t, 0.3, "triangle", 0.09)),
  "neoncity-art": () => seq([440, 554, 659, 880, 1109, 1319], 0.08, (f, t) => tone(f, t, 0.2, "sawtooth", 0.05)),
});

/* ---------- Signature sounds for the luxury «ویژه» picture skins (each matches its object) ---------- */
const chipStack = (t: number, n: number, f = 3000) => { for (let i = 0; i < n; i++) clack(t + i * 0.035, f + (i % 3) * 220, 0.45, 3); };
const woodPiece = (t: number, f = 2200, v = 0.6) => { clack(t, f, v, 1.6); tone(f / 6, t, 0.08, "triangle", 0.18, f / 9); };
const stoneClick = (t: number, f = 3400) => { clack(t, f, 0.7, 2.2); tone(f / 2.4, t, 0.05, "sine", 0.12); };
const ballHit = (t: number, f = 3600, v = 0.5) => { clack(t, f, v, 1.2); tone(1700, t + 0.01, 0.08, "sine", 0.1, 850); };
const tick = (t: number, f = 4200) => clack(t, f, 0.5, 6);
const silk = (t: number, d = 0.12, f = 4800) => noise(t, d, 0.14, f, 0.5);
Object.assign(SLIDE_FX, {
  "lux-tictactoe": (r: number, v: number) => { noise(0, 0.06, 0.18, 3800 + r * 600, 2.5); v % 2 ? noise(0.06, 0.05, 0.18, 3200, 2.5) : tone(520 + r * 40, 0.02, 0.12, "sine", 0.06, 780); },
  "lux-checkers": (r: number) => { noise(0, 0.05, 0.08, 600, 0.6); woodPiece(0.04, 1800 + r * 200, 0.7); },
  "lux-dominoes": (r: number) => { clack(0, 2400 + r * 300, 0.9, 1.6); clack(0.03, 3400, 0.3, 2); tone(620, 0, 0.05, "triangle", 0.18, 480); },
  "lux-letters": (r: number, v: number) => { woodPiece(0, 2600 + r * 200, 0.55); tone(660 + (v % 6) * 55, 0.01, 0.08, "sine", 0.08); },
  "lux-ludo": (r: number) => { woodPiece(0, 2000 + r * 200, 0.5); woodPiece(0.08, 2300, 0.35); },
  "lux-darts": (r: number) => { tone(1600 + r * 300, 0, 0.12, "sine", 0.04, 400); thump(160, 0.11, 0.35); clack(0.11, 1500, 0.4, 1); },
  "lux-go": (r: number) => stoneClick(0, 3200 + r * 400),
  "lux-snooker": (r: number) => { ballHit(0, 3800 + r * 300, 0.5); noise(0.03, 0.12, 0.04, 480, 0.5); },
  "lux-backgammon": (r: number) => { woodPiece(0, 2100 + r * 150, 0.8); noise(0.02, 0.06, 0.08, 800, 0.6); },
  "lux-mahjong": (r: number) => { clack(0, 2600 + r * 300, 0.85, 2); clack(0.04, 2900, 0.45, 2); tone(1100, 0, 0.06, "triangle", 0.15, 950); },
  "lux-poker": (r: number) => chipStack(0, 3, 2900 + r * 300),
  "lux-cards": (r: number) => { noise(0, 0.05, 0.32, 5600 + r * 500, 0.6); noise(0.035, 0.02, 0.2, 2400, 1); },
  "lux-dice": (r: number) => [0, 0.045 + r * 0.02, 0.085, 0.11].forEach((t, i) => clack(t, 2800 + i * 300, 0.7 - i * 0.15, 2.5)),
  "lux-roulette": (r: number) => { for (let i = 0; i < 5; i++) tick(i * 0.03 + r * 0.004, 4000 + i * 120); tone(1800, 0.15, 0.1, "sine", 0.05); },
  "lux-carpet": (r: number) => { noise(0, 0.12, 0.16, 900 + r * 300, 0.5); pluck(SHUR[Math.floor(r * 8)]! * 2, 0.04, 0.4, 0.08); },
  "lux-pearls": (r: number) => { [0, 0.035, 0.06].forEach((t, i) => tone(2600 + r * 300 + i * 180, t, 0.1, "sine", 0.07)); clack(0, 6200, 0.25, 3); },
  "lux-cube": (r: number) => { clack(0, 1800 + r * 200, 0.6, 1.4); clack(0.05, 2200, 0.5, 1.4); tone(300, 0, 0.05, "square", 0.04); },
  "lux-watch": (_r: number, v: number) => { tick(0, 4400); tick(0.12, v % 2 ? 3800 : 4100); tone(3200, 0, 0.02, "sine", 0.05); },
  "lux-eggs": (r: number) => { bell(1760 + r * 120, 0, 0.6, 0.05); clack(0, 5600, 0.2, 3); },
  "lux-pharaoh": (r: number) => { noise(0, 0.18, 0.12, 700 + r * 200, 0.5); tone(220, 0.05, 0.25, "triangle", 0.1, 196); bell(1320, 0.08, 0.4, 0.03); },
  "lux-crown": (r: number) => { bell(1568 + r * 80, 0, 0.6, 0.06); bell(2093, 0.04, 0.4, 0.03); },
  "lux-phoenix": (r: number) => { noise(0, 0.14, 0.14, 1400 + r * 600, 0.5); tone(440 + r * 60, 0.03, 0.2, "triangle", 0.08, 880); },
  "lux-cosmic-gold": (r: number, v: number) => { tone(660 * 2 ** ((v % 7) / 12) + r * 20, 0, 0.5, "sine", 0.06, 990); bell(2349, 0.06, 0.4, 0.02); },
  "lux-hoard": (r: number) => [3150, 4120, 5480].forEach((f, i) => tone(f + r * 120, i * 0.03, 0.3, "sine", 0.07)),
  "lux-chess": (r: number) => { thump(220 + r * 30, 0, 0.3); clack(0, 3600, 0.45, 2.5); tone(2637, 0.01, 0.2, "sine", 0.04); },
  "lux-diamonds": (r: number, v: number) => { tone(2793 + (v % 5) * 140 + r * 60, 0, 0.45, "sine", 0.07); tone(4186, 0.02, 0.25, "sine", 0.03); },
  "lux-emerald-flow": (r: number) => { tone(400 + r * 60, 0, 0.3, "sine", 0.1, 620); noise(0, 0.15, 0.05, 1200, 0.5); },
  "lux-rose-silk": (r: number) => { silk(0, 0.14, 4400 + r * 600); bell(1397 + r * 50, 0.05, 0.4, 0.035); },
  "lux-sapphire-frost": (r: number) => { noise(0, 0.08, 0.15, 6800, 1.4); bell(2637 + r * 120, 0.02, 0.5, 0.045); },
  "lux-ruby-inferno": (r: number) => { noise(0, 0.16, 0.14, 1000 + r * 500, 0.4); tone(110 + r * 20, 0, 0.25, "sawtooth", 0.06, 70); bell(1760, 0.04, 0.3, 0.03); },
  "lux-opal-dream": (r: number, v: number) => { tone(523 * 2 ** ((v % 8) / 8) + r * 20, 0, 0.6, "sine", 0.06, 700); tone(1568, 0.06, 0.4, "triangle", 0.025, 2093); },
});
Object.assign(WIN_FX, {
  "lux-tictactoe": () => { [0, 0.15, 0.3].forEach((t) => noise(t, 0.08, 0.2, 3600, 2.5)); noise(0.5, 0.35, 0.18, 3000, 2); seq([523, 659, 784, 1047], 0.11, (f, t) => tone(f, t + 0.9, 0.4, "triangle", 0.12)); },
  "lux-checkers": () => { [0, 0.18, 0.36].forEach((t) => woodPiece(t, 2000, 0.8)); seq([392, 494, 587, 784], 0.12, (f, t) => tone(f, t + 0.6, 0.5, "triangle", 0.13)); },
  "lux-dominoes": () => { for (let i = 0; i < 20; i++) clack(i * 0.06 * (1 - i * 0.02), 2400 + i * 40, 0.7, 1.6); seq([392, 494, 587, 784], 0.12, (f, t) => tone(f, t + 1.1, 0.5, "triangle", 0.14)); },
  "lux-letters": () => seq([523, 587, 659, 784, 880, 1047], 0.11, (f, t) => { woodPiece(t, 2600, 0.4); tone(f, t, 0.35, "triangle", 0.15); }),
  "lux-ludo": () => { for (let i = 0; i < 10; i++) clack(i * 0.05, 2600 + Math.random() * 700, 0.6, 2.5); seq([523, 659, 784, 1047], 0.1, (f, t) => tone(f, t + 0.7, 0.4, "triangle", 0.14)); },
  "lux-darts": () => { [0, 0.3, 0.6].forEach((t) => { tone(1600, t, 0.12, "sine", 0.04, 400); thump(150, t + 0.11, 0.4); }); seq([659, 784, 988, 1319], 0.1, (f, t) => tone(f, t + 1, 0.4, "square", 0.05)); },
  "lux-go": () => { [0, 0.2, 0.4, 0.6].forEach((t, i) => stoneClick(t, 3000 + i * 200)); seq([587, 659, 880, 988, 1175], 0.16, (f, t) => tone(f, t + 0.85, 0.7, "sine", 0.08)); },
  "lux-snooker": () => { ballHit(0, 3900, 0.6); ballHit(0.2, 3200, 0.45); tone(105, 0.38, 0.24, "sine", 0.34, 58); seq([262, 330, 392, 523], 0.1, (f, t) => tone(f, t + 0.65, 0.6, "triangle", 0.07)); },
  "lux-backgammon": () => { for (let i = 0; i < 14; i++) clack(i * 0.04 + Math.random() * 0.02, 2500 + Math.random() * 800, 0.6, 2.3); seq(SHUR.slice(0, 5), 0.13, (f, t) => pluck(f * 2, t + 0.8, 0.6, 0.1)); },
  "lux-mahjong": () => { tone(110, 0, 2.5, "sine", 0.3); tone(220, 0, 1.6, "sine", 0.1); seq([587, 659, 784, 880, 1175, 1319], 0.13, (f, t) => tone(f, t + 0.4, 0.5, "sine", 0.12)); },
  "lux-poker": () => { chipStack(0, 16); seq([784, 988, 1175, 1568], 0.09, (f, t) => tone(f, t + 0.7, 0.3, "square", 0.05)); tone(1568, 1.1, 1, "sine", 0.08); },
  "lux-cards": () => { for (let i = 0; i < 22; i++) noise(i * 0.025, 0.02, 0.22, 5000, 0.8); seq([659, 831, 988, 1319], 0.1, (f, t) => tone(f, t + 0.75, 0.4, "triangle", 0.13)); },
  "lux-dice": () => { for (let i = 0; i < 18; i++) clack(i * 0.04 + Math.random() * 0.03, 2600 + Math.random() * 900, 0.7 - i * 0.03, 2.5); seq([392, 523, 659, 784], 0.1, (f, t) => tone(f, t + 0.9, 0.5, "triangle", 0.15)); },
  "lux-roulette": () => { for (let i = 0; i < 28; i++) tick(i * (0.03 + i * 0.003), 4200); stoneClick(1.6, 3000); seq([523, 659, 784, 1047], 0.1, (f, t) => tone(f, t + 1.75, 0.4, "triangle", 0.12)); },
  "lux-carpet": () => { seq(SHUR, 0.11, (f, t) => pluck(f, t, 0.7, 0.1)); daf(0.95, 0.4); },
  "lux-pearls": () => { for (let i = 0; i < 14; i++) tone(2000 + Math.random() * 1600, i * 0.05, 0.15, "sine", 0.06); seq([1047, 1319, 1568], 0.15, (f, t) => tone(f, t + 0.8, 1, "sine", 0.08)); },
  "lux-cube": () => { for (let i = 0; i < 9; i++) clack(i * 0.06, 1800 + (i % 3) * 300, 0.55, 1.4); seq([523, 659, 784, 1047], 0.1, (f, t) => tone(f, t + 0.6, 0.35, "square", 0.05)); },
  "lux-watch": () => { for (let i = 0; i < 8; i++) tick(i * 0.12, i % 2 ? 3800 : 4400); seq([1047, 1319, 1568, 2093], 0.2, (f, t) => bell(f, t + 1, 1.2, 0.05)); },
  "lux-eggs": () => seq([1047, 1319, 1568, 1760, 2093, 2637], 0.14, (f, t) => bell(f, t, 1, 0.05)),
  "lux-pharaoh": () => { tone(110, 0, 2, "triangle", 0.12); seq([294, 311, 370, 392, 440, 466, 587], 0.14, (f, t) => tone(f, t + 0.2, 0.6, "sawtooth", 0.04)); bell(1175, 1.2, 1.4, 0.05); },
  "lux-crown": () => { seq([523, 659, 784, 1047, 784, 1047, 1319], 0.12, (f, t) => tone(f, t, 0.6, "triangle", 0.1)); bell(2093, 0.9, 1.8, 0.06); },
  "lux-phoenix": () => { noise(0, 1, 0.12, 1200, 0.4); seq([392, 494, 587, 784, 988, 1175, 1568], 0.11, (f, t) => tone(f, t + 0.2, 0.7, "triangle", 0.06)); bell(2349, 1, 1.5, 0.05); },
  "lux-cosmic-gold": () => seq([262, 392, 523, 784, 1047, 1568, 2093], 0.14, (f, t) => { tone(f, t, 1.2, "sine", 0.04); bell(f * 2, t + 0.05, 0.9, 0.02); }),
  "lux-hoard": () => { for (let i = 0; i < 18; i++) { const t = i * 0.05 + Math.random() * 0.03; tone(3150 + Math.random() * 2000, t, 0.3, "sine", 0.05); } tone(55, 0, 1.4, "sawtooth", 0.08, 40); seq([392, 523, 659, 784], 0.14, (f, t) => tone(f, t + 1, 0.6, "triangle", 0.1)); },
  "lux-chess": () => { thump(200, 0, 0.4); thump(160, 0.25, 0.4); seq([392, 523, 659, 784, 1047], 0.15, (f, t) => tone(f, t + 0.5, 0.8, "sine", 0.09)); bell(2093, 1.3, 1.6, 0.05); },
  "lux-diamonds": () => { seq([1568, 1976, 2349, 3136, 2637, 3136], 0.1, (f, t) => tone(f, t, 0.9, "sine", 0.06)); noise(0.6, 0.4, 0.04, 8000, 1); },
  "lux-emerald-flow": () => seq([392, 494, 587, 740, 880, 1175], 0.15, (f, t) => tone(f, t, 0.9, "sine", 0.08, f * 1.01)),
  "lux-rose-silk": () => { silk(0, 0.5); seq([659, 784, 988, 1175, 1319, 1568], 0.12, (f, t) => bell(f, t + 0.2, 1, 0.05)); },
  "lux-sapphire-frost": () => seq([2093, 1760, 2349, 2637, 3136, 3520], 0.1, (f, t) => bell(f, t, 1.2, 0.04)),
  "lux-ruby-inferno": () => { tone(55, 0, 1.8, "sawtooth", 0.1, 40); noise(0, 1.2, 0.1, 500, 0.4); seq([220, 262, 330, 440, 523], 0.15, (f, t) => tone(f, t + 0.4, 0.7, "triangle", 0.07)); bell(1760, 1.2, 1.2, 0.04); },
  "lux-opal-dream": () => seq([523, 587, 659, 784, 880, 1047, 1175, 1319], 0.09, (f, t) => tone(f, t, 0.6, "sine", 0.07, f * 1.02)),
});

/** Bright coin-chime played when a finished mission's reward is collected. */
export function playClaim() {
  [0, 0.06, 0.12].forEach((t, i) => clack(t, 5200 + i * 300, 0.35, 4));
  seq([1047, 1319, 1568, 2093], 0.08, (f, t) => { tone(f, t, 0.45, "sine", 0.1); tone(f * 2, t, 0.2, "sine", 0.03); });
  bell(2637, 0.34, 0.9, 0.05);
}

/** True when the skin has its own slide sound and its own victory tune. */
export const hasSignatureSound = (theme: string) => Boolean(SLIDE_FX[theme] && WIN_FX[theme]);
