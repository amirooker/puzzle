import { describe, expect, it } from "vitest";
import { buyTheme, getState, itemUnlocked, setState, TILE_STYLES } from "@/lib/store";

describe("tile styles", () => {
  it("does not offer the removed hexagon tile style", () => {
    expect(TILE_STYLES.some((style) => style.id === "hexagon")).toBe(false);
  });
  it("frosted glass tiles cost 1500 points and unlock once bought", () => {
    const frosted = TILE_STYLES.find((t) => t.id === "frosted")!;
    expect(frosted.price).toBe(1_500);
    setState((s) => ({ ...s, purchased: [], stats: { ...s.stats, points: 1_600 } }));
    expect(itemUnlocked(frosted, getState().stats, false, getState().purchased)).toBe(false);
    expect(buyTheme("frosted")).toBe(true);
    expect(getState().stats.points).toBe(100);
    expect(itemUnlocked(frosted, getState().stats, false, getState().purchased)).toBe(true);
  });
  it("cannot buy a tile style without enough points", () => {
    setState((s) => ({ ...s, purchased: [], stats: { ...s.stats, points: 100 } }));
    expect(buyTheme("royal-gem")).toBe(false);
    expect(getState().stats.points).toBe(100);
  });
});
