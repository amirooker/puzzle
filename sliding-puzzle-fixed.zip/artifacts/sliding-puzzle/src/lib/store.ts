import { useSyncExternalStore } from "react";
import type { DigitLang } from "./digits";
import { PREMIUM_SKINS } from "./premium";

/** Every picture puzzle except the free first one costs this many points. */
export const PICTURE_PRICE = 500;
export type Stats = {
  points: number;
  wins: number;
  duelMatches: number;
  duelWins: number;
  duelLosses: number;
  duelHistory: LocalDuelMatch[];
  winsBySize: Record<number, number>;
  best: Record<number, { moves: number; time: number }>;
  streak: number;
  bestStreak: number;
  efficientWins: number; // wins within move limit
  daily: Daily;
  bestTime: Record<number, number>; // centiseconds, independent of best moves
  lastLogin: string; loginStreak: number;
  week: { id: string; wins: number; efficient: number; days: number };
  unlocked: string[]; // themes earned via weekly missions
  fastRun: Record<number, number>; // current consecutive wins under the size's time limit
  bestFastRun: Record<number, number>;
  bestLogin: number;
  /** Picture-puzzle records, kept apart from the number-puzzle records. */
  photoBest: Record<number, { moves: number; time: number }>;
  photoWins: number;
};

export type LocalDuelResult = { name: string; time: number; moves: number };
export type RankedLocalDuelResult = LocalDuelResult & { rank: number; points: number };
export type LocalDuelMatch = {
  date: string;
  size: number;
  criterion: "time" | "moves";
  results: RankedLocalDuelResult[];
};

export type Daily = { date: string; wins: number; efficient: number; played: number; fast: number; big: number; run: number; bestRun: number; moves: number; sizes: number[] };
export const newDaily = (date: string): Daily => ({ date, wins: 0, efficient: 0, played: 0, fast: 0, big: 0, run: 0, bestRun: 0, moves: 0, sizes: [] });

export type State = {
  digits: DigitLang;
  theme: string;
  tileStyle: string;
  sound: boolean;
  admin: boolean;
  claimed: string[];
  purchased: string[];
  /** Last chosen board size and game mode on the home screen */
  size: number;
  mode: string;
  reverseLevel: string;
  stats: Stats;
};

const dateKey = (date = new Date()) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
const today = () => dateKey();
/** Week number since epoch (weeks start Saturday, Iranian week) */
export const weekNum = () => Math.floor((Date.now() / 864e5 + 5) / 7);
const weekId = () => `w${weekNum()}`;

const initial: State = {
  digits: "en",
  theme: "wood",
  tileStyle: "solid",
  sound: true,
  admin: false,
  claimed: [],
  purchased: [],
  size: 3,
  mode: "classic",
  reverseLevel: "easy",
  stats: {
    points: 0, wins: 0, duelMatches: 0, duelWins: 0, duelLosses: 0, duelHistory: [], winsBySize: {}, best: {}, streak: 0, bestStreak: 0, efficientWins: 0,
    daily: newDaily(today()),
    bestTime: {}, lastLogin: "", loginStreak: 0, week: { id: "", wins: 0, efficient: 0, days: 0 }, unlocked: [], fastRun: {}, bestFastRun: {}, bestLogin: 0, photoBest: {}, photoWins: 0,
  },
};

const KEY = "adad-puzzle-v1";
let state: State = initial;
let loaded = false;
const subs = new Set<() => void>();
let calendarTimer: number | null = null;
let calendarWatchInstalled = false;

function normalizeStats(value: unknown): Stats {
  const p = value && typeof value === "object" ? value as Partial<Stats> : {};
  const daily = p.daily && typeof p.daily === "object" ? p.daily as Partial<Daily> : {};
  const week = p.week && typeof p.week === "object" ? p.week as Partial<Stats["week"]> : {};
  const count = (v: unknown, fallback = 0) => typeof v === "number" && Number.isFinite(v) ? Math.max(0, Math.floor(v)) : fallback;
  const numberRecord = (v: unknown): Record<number, number> => {
    if (!v || typeof v !== "object" || Array.isArray(v)) return {};
    return Object.fromEntries(Object.entries(v).map(([key, item]) => [key, count(item)]));
  };
  const bestRecord = (src: unknown = p.best): Stats["best"] => {
    if (!src || typeof src !== "object" || Array.isArray(src)) return {};
    return Object.fromEntries(Object.entries(src).flatMap(([key, item]) => {
      const size = Number(key);
      if (!Number.isInteger(size) || size < 3 || size > 12) return [];
      if (!item || typeof item !== "object") return [];
      const candidate = item as { moves?: unknown; time?: unknown };
      if (typeof candidate.moves !== "number" || !Number.isFinite(candidate.moves) || typeof candidate.time !== "number" || !Number.isFinite(candidate.time)) return [];
      return [[size, { moves: count(candidate.moves), time: count(candidate.time) }]];
    }));
  };
  const localDuelHistory = (): LocalDuelMatch[] => {
    if (!Array.isArray(p.duelHistory)) return [];
    return p.duelHistory.flatMap((entry) => {
      if (!entry || typeof entry !== "object") return [];
      const candidate = entry as Partial<LocalDuelMatch>;
      if (
        typeof candidate.date !== "string" ||
        typeof candidate.size !== "number" ||
        !Number.isInteger(candidate.size) ||
        candidate.size < 3 ||
        candidate.size > 12 ||
        (candidate.criterion !== "time" && candidate.criterion !== "moves") ||
        !Array.isArray(candidate.results)
      ) return [];
      const results = candidate.results.flatMap((result) => {
        if (!result || typeof result !== "object") return [];
        const player = result as Partial<RankedLocalDuelResult>;
        if (
          typeof player.name !== "string" ||
          typeof player.time !== "number" ||
          !Number.isFinite(player.time) ||
          typeof player.moves !== "number" ||
          !Number.isFinite(player.moves) ||
          typeof player.rank !== "number" ||
          !Number.isInteger(player.rank) ||
          typeof player.points !== "number" ||
          !Number.isFinite(player.points)
        ) return [];
        return [{
          name: player.name.slice(0, 24),
          time: Math.max(0, Math.floor(player.time)),
          moves: Math.max(0, Math.floor(player.moves)),
          rank: Math.max(1, player.rank),
          points: Math.max(0, Math.floor(player.points)),
        }];
      });
      if (results.length < 2) return [];
      return [{
        date: candidate.date,
        size: candidate.size,
        criterion: candidate.criterion,
        results: results.slice(0, 10),
      }];
    }).slice(-30);
  };
  return {
    ...initial.stats,
    ...p,
    points: count(p.points),
    wins: count(p.wins),
    duelMatches: count(p.duelMatches),
    duelWins: count(p.duelWins),
    duelLosses: count(p.duelLosses),
    duelHistory: localDuelHistory(),
    winsBySize: numberRecord(p.winsBySize),
    best: bestRecord(),
    photoBest: bestRecord(p.photoBest),
    photoWins: count(p.photoWins),
    streak: count(p.streak),
    bestStreak: count(p.bestStreak),
    efficientWins: count(p.efficientWins),
    bestTime: numberRecord(p.bestTime),
    lastLogin: typeof p.lastLogin === "string" ? p.lastLogin : "",
    loginStreak: count(p.loginStreak),
    bestLogin: count(p.bestLogin),
    fastRun: numberRecord(p.fastRun),
    bestFastRun: numberRecord(p.bestFastRun),
    daily: {
      ...newDaily(typeof daily.date === "string" ? daily.date : today()),
      ...daily,
      date: typeof daily.date === "string" ? daily.date : today(),
      wins: count(daily.wins),
      efficient: count(daily.efficient),
      played: count(daily.played),
      fast: count(daily.fast),
      big: count(daily.big),
      run: count(daily.run),
      bestRun: count(daily.bestRun),
      moves: count(daily.moves),
      sizes: Array.isArray(daily.sizes) ? daily.sizes.filter((size): size is number => typeof size === "number" && Number.isInteger(size) && size >= 3 && size <= 12) : [],
    },
    week: {
      id: typeof week.id === "string" ? week.id : "",
      wins: count(week.wins),
      efficient: count(week.efficient),
      days: count(week.days),
    },
    unlocked: Array.isArray(p.unlocked) ? p.unlocked.filter((id): id is string => typeof id === "string") : [],
  };
}

function advanceCalendar(current: State): State {
  const t = today();
  let stats = normalizeStats(current.stats);
  if (stats.daily.date !== t) stats = { ...stats, daily: newDaily(t) };
  if (stats.lastLogin !== t) {
    const yesterday = dateKey(new Date(Date.now() - 864e5));
    const loginStreak = stats.lastLogin === yesterday ? stats.loginStreak + 1 : 1;
    const w = weekId();
    stats = {
      ...stats,
      points: stats.points + 15,
      lastLogin: t,
      loginStreak,
      bestLogin: Math.max(stats.bestLogin ?? 0, loginStreak),
      week: stats.week.id === w
        ? { ...stats.week, days: stats.week.days + 1 }
        : { id: w, wins: 0, efficient: 0, days: 1 },
    };
  }
  return { ...current, stats };
}

function persist() {
  try {
    if (typeof window !== "undefined") window.localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    // Storage may be disabled or full; keep the current session playable.
  }
}

function scheduleCalendarRefresh() {
  if (typeof window === "undefined") return;
  if (calendarTimer !== null) window.clearTimeout(calendarTimer);
  const now = new Date();
  const nextMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 2);
  calendarTimer = window.setTimeout(() => {
    calendarTimer = null;
    refreshCalendar();
    scheduleCalendarRefresh();
  }, Math.max(1_000, nextMidnight.getTime() - Date.now()));
}

export function refreshCalendar() {
  if (typeof window === "undefined") return;
  load();
  const current = state;
  const refreshed = advanceCalendar(current);
  if (
    refreshed.stats.daily.date === current.stats.daily.date &&
    refreshed.stats.lastLogin === current.stats.lastLogin &&
    refreshed.stats.week.id === current.stats.week.id
  ) return;
  state = refreshed;
  persist();
  subs.forEach((f) => f());
}

function ensureCalendarWatch() {
  if (typeof window === "undefined" || calendarWatchInstalled) return;
  calendarWatchInstalled = true;
  const onVisible = () => {
    if (!document.hidden) refreshCalendar();
  };
  window.addEventListener("focus", refreshCalendar);
  document.addEventListener("visibilitychange", onVisible);
  scheduleCalendarRefresh();
}

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const p: unknown = JSON.parse(raw);
      if (p && typeof p === "object") {
        const saved = !Array.isArray(p) ? p as Partial<State> : {};
        state = {
          ...initial,
          ...saved,
          digits: saved.digits === "fa" ? "fa" : "en",
          theme: typeof saved.theme === "string" ? saved.theme : initial.theme,
          tileStyle: typeof saved.tileStyle === "string" ? saved.tileStyle : initial.tileStyle,
          sound: typeof saved.sound === "boolean" ? saved.sound : initial.sound,
          admin: saved.admin === true,
          claimed: Array.isArray(saved.claimed) ? saved.claimed.filter((id): id is string => typeof id === "string") : [],
          purchased: Array.isArray(saved.purchased) ? saved.purchased.filter((id): id is string => typeof id === "string") : [],
          size: typeof saved.size === "number" && Number.isInteger(saved.size) && saved.size >= 3 && saved.size <= 12 ? saved.size : 3,
          mode: typeof saved.mode === "string" ? saved.mode : "classic",
          reverseLevel: typeof saved.reverseLevel === "string" ? saved.reverseLevel : "easy",
          stats: normalizeStats(saved.stats),
        };
      }
    }
  } catch {
    state = initial;
  }
  state = advanceCalendar(state);
  persist();
  ensureCalendarWatch();
}

export function setState(fn: (s: State) => State) {
  load();
  state = fn(advanceCalendar(state));
  persist();
  subs.forEach((f) => f());
}

export function useGame<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(
    (f) => { subs.add(f); return () => subs.delete(f); },
    () => { load(); return sel(state); },
    () => sel(initial),
  );
}

/** Seconds a win must stay under to count as "fast" for each board size. */
export const timeLimit = (n: number) => ({ 3: 30, 4: 60, 5: 120, 6: 240 } as Record<number, number>)[n] ?? n * n * 8;
export const moveLimit = (n: number) => Math.round(n * n * n * 1.6);

export function recordWin(n: number, moves: number, time: number) {
  setState((s) => {
    const st = s.stats;
    const prev = st.best[n];
    const eff = moves <= moveLimit(n);
    const fast = time <= timeLimit(n) * 100;
    const run = fast ? (st.fastRun[n] ?? 0) + 1 : 0;
    return {
      ...s,
      stats: {
        ...st,
        points: st.points + 8 + (eff ? 4 : 0),
        wins: st.wins + 1,
        winsBySize: { ...st.winsBySize, [n]: (st.winsBySize[n] ?? 0) + 1 },
        best: { ...st.best, [n]: !prev || moves < prev.moves || (moves === prev.moves && time < prev.time) ? { moves, time } : prev },
        bestTime: { ...st.bestTime, [n]: st.bestTime[n] == null ? time : Math.min(st.bestTime[n]!, time) },
        week: { ...st.week, wins: st.week.wins + 1, efficient: st.week.efficient + (eff ? 1 : 0) },
        fastRun: { ...st.fastRun, [n]: run },
        bestFastRun: { ...st.bestFastRun, [n]: Math.max(st.bestFastRun[n] ?? 0, run) },
        streak: st.streak + 1,
        bestStreak: Math.max(st.bestStreak, st.streak + 1),
        efficientWins: st.efficientWins + (eff ? 1 : 0),
        daily: { ...st.daily, wins: st.daily.wins + 1, efficient: st.daily.efficient + (eff ? 1 : 0), fast: st.daily.fast + (fast ? 1 : 0),
          big: st.daily.big + (n >= 4 ? 1 : 0), run: st.daily.run + 1, bestRun: Math.max(st.daily.bestRun, st.daily.run + 1),
          moves: st.daily.moves + moves, sizes: [...new Set([...st.daily.sizes, n])] },
      },
    };
  });
}
/** Picture puzzle win: only updates the separate picture record (fewest moves, then fastest). */
export function recordPhotoWin(n: number, moves: number, time: number) {
  setState((s) => {
    const prev = s.stats.photoBest[n];
    const better = !prev || time < prev.time || (time === prev.time && moves < prev.moves);
    return { ...s, stats: { ...s.stats, photoWins: s.stats.photoWins + 1, photoBest: better ? { ...s.stats.photoBest, [n]: { moves, time } } : s.stats.photoBest } };
  });
}
export function rankLocalDuelResults(
  results: LocalDuelResult[],
  criterion: "time" | "moves",
): RankedLocalDuelResult[] {
  const compare = criterion === "time"
    ? (a: LocalDuelResult, b: LocalDuelResult) => a.time - b.time || a.moves - b.moves
    : (a: LocalDuelResult, b: LocalDuelResult) => a.moves - b.moves || a.time - b.time;
  return results
    .filter((result) => result.name.trim() && Number.isFinite(result.time) && Number.isFinite(result.moves))
    .slice()
    .sort(compare)
    .map((result, index) => ({
      ...result,
      name: result.name.trim().slice(0, 24),
      rank: index + 1,
      points: index === 0 ? 30 : index === 1 ? 15 : index === 2 ? 10 : 5,
    }));
}

export function recordLocalDuelMatch(
  results: LocalDuelResult[],
  size: number,
  criterion: "time" | "moves",
) {
  const ranked = rankLocalDuelResults(results, criterion);
  if (ranked.length < 2 || !Number.isInteger(size) || size < 3 || size > 12) return;
  const match: LocalDuelMatch = { date: today(), size, criterion, results: ranked };
  setState((s) => ({
    ...s,
    stats: {
      ...s.stats,
      points: s.stats.points + ranked.reduce((total, result) => total + result.points, 0),
      duelMatches: s.stats.duelMatches + 1,
      duelWins: s.stats.duelWins + 1,
      duelLosses: s.stats.duelLosses + ranked.length - 1,
      duelHistory: [...s.stats.duelHistory, match].slice(-30),
    },
  }));
}
export function recordStart() {
  setState((s) => ({ ...s, stats: { ...s.stats, daily: { ...s.stats.daily, played: s.stats.daily.played + 1 } } }));
}
export function breakStreak() {
  setState((s) => ({ ...s, stats: { ...s.stats, streak: 0, fastRun: {}, daily: { ...s.stats.daily, run: 0 } } }));
}

export function checkAdminCode(code: string) {
  return code === "Amirooker5";
}

/* ---------- Content ---------- */
export type Theme = { id: string; name: string; req?: Req | undefined; weekly?: boolean; premium?: boolean; picture?: boolean; price?: number; section?: "special" };
export type Req = { label: string; ok: (s: Stats, sizes: number) => boolean };
const sizesDone = (s: Stats) => Object.keys(s.winsBySize).length;

/** One exclusive theme per week, earned only by finishing that week's missions. */
export const WEEKLY_THEMES: Theme[] = [
  { id: "jade", name: "یشم سبز" },
  { id: "sakura", name: "شکوفهٔ گیلاس" },
  { id: "pirate", name: "گنج دزدان دریایی" },
  { id: "pixel", name: "پیکسلی رترو" },
  { id: "vinyl", name: "صفحهٔ گرامافون" },
  { id: "coin", name: "سکه‌های طلا" },
  { id: "balloon", name: "بادکنک" },
  { id: "domino", name: "دومینو" },
  { id: "crystal", name: "کریستال تراش‌خورده" },
  { id: "stained", name: "شیشهٔ رنگی کلیسا" },
  { id: "marquee", name: "لامپ‌های شهربازی" },
  { id: "chalk", name: "تخته‌سیاه" },
  { id: "cards", name: "کارت بازی" },
  { id: "dice", name: "تاس" },
  { id: "mahjong", name: "ماهجونگ" },
].map((t) => ({ ...t, weekly: true, req: { label: "پوستهٔ هفتگی", ok: (s: Stats) => s.unlocked.includes(t.id) } }));
export const weeklyTheme = () => WEEKLY_THEMES[weekNum() % WEEKLY_THEMES.length]!;


const W = (n: number) => (s: Stats) => s.winsBySize[n] ?? 0;
const under = (n: number, sec: number) => (s: Stats) => s.bestTime[n] != null && s.bestTime[n]! <= sec * 100;
/** Former shop skins: now regular skins earned only through hard challenges. */
const MOVED_REQ: Record<string, Req> = {
  "pink-embroidery": { label: "۲۲۰ پیروزی", ok: (s) => s.wins >= 220 },
  "persian-mosaic": { label: "۳۰ پیروزی در ۵×۵", ok: (s) => W(5)(s) >= 30 },
  "icon-wood": { label: "۳۰ روز ورود پیاپی", ok: (s) => s.bestLogin >= 30 },
  "leopard-weave": { label: "۲۵ پیروزی پیاپی", ok: (s) => s.bestStreak >= 25 },
  "zebra-silk": { label: "۴×۴ زیر ۲۰ ثانیه", ok: under(4, 20) },
  "rose-marble": { label: "۱۵۰ پیروزی کم‌حرکت", ok: (s) => s.efficientWins >= 150 },
  "minakari": { label: "۲۵ پیروزی در ۶×۶", ok: (s) => W(6)(s) >= 25 },
  "iranian-brocade": { label: "۵×۵ زیر ۴۰ ثانیه", ok: under(5, 40) },
  "khatam": { label: "۶۰۰ پیروزی", ok: (s) => s.wins >= 600 },
  "iran-flag-weave": { label: "۵۰ روز ورود پیاپی", ok: (s) => s.bestLogin >= 50 },
  "emerald-velvet": { label: "۵ بار پیاپی ۴×۴ زیر ۴۰ ثانیه", ok: (s) => (s.bestFastRun[4] ?? 0) >= 5 },
  "peacock": { label: "۱۰ پیروزی در ۷×۷", ok: (s) => W(7)(s) >= 10 },
  "lapis": { label: "۳×۳ زیر ۸ ثانیه", ok: under(3, 8) },
  "white-gold-marble": { label: "۲۵۰ پیروزی کم‌حرکت", ok: (s) => s.efficientWins >= 250 },
  "obsidian-prism": { label: "۴۰ پیروزی پیاپی", ok: (s) => s.bestStreak >= 40 },
  "black-gold-marble": { label: "۱۰ پیروزی در ۸×۸", ok: (s) => W(8)(s) >= 10 },
  "imperial-jade": { label: "۶×۶ زیر ۱۵۰ ثانیه", ok: under(6, 150) },
  "sapphire": { label: "۵ پیروزی در ۹×۹", ok: (s) => W(9)(s) >= 5 },
  "royal-gold": { label: "۱۰۰۰ پیروزی", ok: (s) => s.wins >= 1000 },
  "rainbow-opal": { label: "۳ پیروزی در ۱۰×۱۰", ok: (s) => W(10)(s) >= 3 },
};
const SPECIAL_SECTION_IDS = new Set([
  "icon-wood", "leopard-weave", "zebra-silk", "pink-embroidery", "rose-marble", "persian-mosaic",
  "minakari", "khatam", "iranian-brocade", "iran-flag-weave", "emerald-velvet", "peacock",
  "lapis", "white-gold-marble", "obsidian-prism", "black-gold-marble",
]);
/** Special skins: need the challenge AND the (very high) price. */
export const SPECIAL_REQ: Record<string, Req> = {
  "dragon-hearts": { label: "۳×۳ زیر ۶ ثانیه", ok: under(3, 6) },
  "magic-orbs": { label: "۱۰ بار پیاپی ۴×۴ زیر ۳۰ ثانیه", ok: (s) => (s.bestFastRun[4] ?? 0) >= 10 },
  "geode": { label: "۵×۵ زیر ۳۵ ثانیه", ok: under(5, 35) },
  "planets": { label: "۶۰ پیروزی پیاپی", ok: (s) => s.bestStreak >= 60 },
  "mercury": { label: "۶×۶ زیر ۱۰۰ ثانیه", ok: under(6, 100) },
  "soap-bubbles": { label: "۴×۴ زیر ۱۸ ثانیه", ok: under(4, 18) },
  "gold-orbs": { label: "۱۵۰۰ پیروزی", ok: (s) => s.wins >= 1500 },
  "holo-foil": { label: "۱۰۰ روز ورود پیاپی", ok: (s) => s.bestLogin >= 100 },
  "ember-cubes": { label: "۷×۷ زیر ۳ دقیقه", ok: under(7, 180) },
  "void-portal": { label: "۳ پیروزی در ۱۲×۱۲", ok: (s) => W(12)(s) >= 3 },
  "billiard-royal": { label: "۵ پیروزی در ۸×۸", ok: (s) => W(8)(s) >= 5 },
  "crystal-heart": { label: "۱۰ پیروزی در ۷×۷", ok: (s) => W(7)(s) >= 10 },
  "star-cascade": { label: "۲۰ پیروزی پیاپی", ok: (s) => s.bestStreak >= 20 },
  "solar-medallion": { label: "۱۰۰ پیروزی بهینه", ok: (s) => s.efficientWins >= 100 },
  "moon-pearl": { label: "۴۵ روز ورود پیاپی", ok: (s) => s.bestLogin >= 45 },
  "rainbow-orbit": { label: "۱۵ پیروزی در ۶×۶", ok: (s) => W(6)(s) >= 15 },
  "sapphire-shard": { label: "۸ پیروزی در ۹×۹", ok: (s) => W(9)(s) >= 8 },
  "lotus-ember": { label: "۵۰ پیروزی پیاپی", ok: (s) => s.bestStreak >= 50 },
  "prism-rainbow": { label: "۱۵۰۰ پیروزی", ok: (s) => s.wins >= 1500 },
  "lux-tictactoe": { label: "۱,۶۰۰ پیروزی", ok: (s) => s.wins >= 1600 },
  "lux-checkers": { label: "۱,۷۲۰ پیروزی", ok: (s) => s.wins >= 1720 },
  "lux-dominoes": { label: "۱,۸۴۰ پیروزی", ok: (s) => s.wins >= 1840 },
  "lux-letters": { label: "۱,۹۶۰ پیروزی", ok: (s) => s.wins >= 1960 },
  "lux-ludo": { label: "۲,۰۸۰ پیروزی", ok: (s) => s.wins >= 2080 },
  "lux-darts": { label: "۲,۲۰۰ پیروزی", ok: (s) => s.wins >= 2200 },
  "lux-go": { label: "۲,۳۲۰ پیروزی", ok: (s) => s.wins >= 2320 },
  "lux-snooker": { label: "۲,۴۴۰ پیروزی", ok: (s) => s.wins >= 2440 },
  "lux-backgammon": { label: "۲,۵۶۰ پیروزی", ok: (s) => s.wins >= 2560 },
  "lux-mahjong": { label: "۲,۶۸۰ پیروزی", ok: (s) => s.wins >= 2680 },
  "lux-poker": { label: "۲,۸۰۰ پیروزی", ok: (s) => s.wins >= 2800 },
  "lux-cards": { label: "۲,۹۲۰ پیروزی", ok: (s) => s.wins >= 2920 },
  "lux-dice": { label: "۳,۰۴۰ پیروزی", ok: (s) => s.wins >= 3040 },
  "lux-roulette": { label: "۳,۱۶۰ پیروزی", ok: (s) => s.wins >= 3160 },
  "lux-carpet": { label: "۳,۲۸۰ پیروزی", ok: (s) => s.wins >= 3280 },
  "lux-pearls": { label: "۳,۴۰۰ پیروزی", ok: (s) => s.wins >= 3400 },
  "lux-cube": { label: "۳,۵۲۰ پیروزی", ok: (s) => s.wins >= 3520 },
  "lux-watch": { label: "۳,۶۴۰ پیروزی", ok: (s) => s.wins >= 3640 },
  "lux-eggs": { label: "۳,۷۶۰ پیروزی", ok: (s) => s.wins >= 3760 },
  "lux-pharaoh": { label: "۳,۸۸۰ پیروزی", ok: (s) => s.wins >= 3880 },
  "lux-crown": { label: "۴,۰۰۰ پیروزی", ok: (s) => s.wins >= 4000 },
  "lux-phoenix": { label: "۴,۱۲۰ پیروزی", ok: (s) => s.wins >= 4120 },
  "lux-cosmic-gold": { label: "۴,۲۴۰ پیروزی", ok: (s) => s.wins >= 4240 },
  "lux-hoard": { label: "۴,۳۶۰ پیروزی", ok: (s) => s.wins >= 4360 },
  "lux-chess": { label: "۴,۴۸۰ پیروزی", ok: (s) => s.wins >= 4480 },
  "lux-emerald-flow": { label: "۵,۰۰۰ پیروزی", ok: (s) => s.wins >= 5000 },
  "lux-rose-silk": { label: "۲۰۰ روز ورود پیاپی", ok: (s) => s.bestLogin >= 200 },
  "lux-sapphire-frost": { label: "۱۰۰ پیروزی پیاپی", ok: (s) => s.bestStreak >= 100 },
  "lux-ruby-inferno": { label: "۱۰ پیروزی در ۱۲×۱۲", ok: (s) => W(12)(s) >= 10 },
  "lux-opal-dream": { label: "۱۰,۰۰۰ پیروزی", ok: (s) => s.wins >= 10000 },
  "lux-diamonds": { label: "۴,۶۰۰ پیروزی", ok: (s) => s.wins >= 4600 },
};
/** Paid special skins that live in the «ویژه» section. */
export const SPECIAL_PAID_IDS = new Set(["dragon-hearts", "lux-tictactoe", "lux-checkers", "lux-dominoes", "lux-letters", "lux-ludo", "lux-darts", "lux-go", "lux-snooker", "lux-backgammon", "lux-mahjong", "lux-poker", "lux-cards", "lux-dice", "lux-roulette", "lux-carpet", "lux-pearls", "lux-cube", "lux-watch", "lux-eggs", "lux-pharaoh", "lux-crown", "lux-phoenix", "lux-cosmic-gold", "lux-hoard", "lux-chess", "lux-diamonds", "lux-emerald-flow", "lux-rose-silk", "lux-sapphire-frost", "lux-ruby-inferno", "lux-opal-dream"]);
/** Every skin in the «ویژه» section must be bought with points (after its challenge). */
export const MOVED_THEMES: Theme[] = PREMIUM_SKINS.filter((skin) => !skin.special).map((skin) => ({
  id: skin.id, name: skin.name, req: MOVED_REQ[skin.id],
  ...(SPECIAL_SECTION_IDS.has(skin.id) ? { section: "special" as const, price: skin.price, premium: true } : {}),
}));
export const PREMIUM_THEMES: Theme[] = PREMIUM_SKINS.filter((skin) => skin.special)
  .map((skin) => ({
    id: skin.id, name: skin.name, price: skin.price, premium: true, req: SPECIAL_REQ[skin.id],
    ...(SPECIAL_PAID_IDS.has(skin.id) ? { section: "special" as const } : {}),
  }));
export const THEMES: Theme[] = [
  { id: "wood", name: "چوب" },
  { id: "cork", name: "تختهٔ چوب‌پنبه", req: { label: "۲۰ پیروزی", ok: (s) => s.wins >= 20 } },
  { id: "terrazzo", name: "سنگ موزاییکی ترازو", req: { label: "۷۰ پیروزی", ok: (s) => s.wins >= 70 } },
  { id: "rosewood", name: "چوب سرخ منبت", req: { label: "۱۲۰ پیروزی", ok: (s) => s.wins >= 120 } },
  { id: "nacre", name: "صدف خاتم‌کاری", req: { label: "۲۰۰ پیروزی", ok: (s) => s.wins >= 200 } },
  { id: "crimson", name: "زرشکی", req: { label: "۱۵ پیروزی", ok: (s) => s.wins >= 15 } },
  { id: "ocean", name: "اقیانوس", req: { label: "۵ روز ورود پیاپی", ok: (s) => s.bestLogin >= 5 } },
  { id: "midnight", name: "شب پرستاره", req: { label: "۵ بار پیاپی ۳×۳ زیر ۲۵ ثانیه", ok: (s) => (s.bestFastRun[3] ?? 0) >= 5 } },
  { id: "winter", name: "زمستانی", req: { label: "۱۴ روز ورود پیاپی", ok: (s) => s.bestLogin >= 14 } },
  { id: "light", name: "مینیمال روشن", req: { label: "۴۰ پیروزی", ok: (s) => s.wins >= 40 } },
  { id: "emerald", name: "زمرد", req: { label: "۱۵ پیروزی در ۴×۴", ok: (s) => W(4)(s) >= 15 } },
  { id: "copper", name: "مس چکش‌خورده", req: { label: "۳×۳ زیر ۱۲ ثانیه", ok: under(3, 12) } },
  { id: "forest", name: "جنگل", req: { label: "۴×۴ زیر ۳۵ ثانیه", ok: under(4, 35) } },
  { id: "amethyst", name: "یاقوت بنفش", req: { label: "۵×۵ زیر ۵۰ ثانیه", ok: under(5, 50) } },
  { id: "neon", name: "نئون سایبری", req: { label: "۱۲ پیروزی پیاپی", ok: (s) => s.bestStreak >= 12 } },
  { id: "obsidian", name: "ابسیدین", req: { label: "۱۸۰ پیروزی", ok: (s) => s.wins >= 180 } },
  { id: "aurora", name: "شفق", req: { label: "۶ اندازهٔ متفاوت", ok: (s) => sizesDone(s) >= 6 } },
  { id: "arctic", name: "قطبی", req: { label: "۳۵ پیروزی کم‌حرکت", ok: (s) => s.efficientWins >= 35 } },
  { id: "royal", name: "طلایی سلطنتی", req: { label: "۵ پیروزی در ۶×۶", ok: (s) => W(6)(s) >= 5 } },
  { id: "candy", name: "آب‌نبات", req: { label: "۲۰ پیروزی پیاپی", ok: (s) => s.bestStreak >= 20 } },
  { id: "desert", name: "کویر", req: { label: "۲۵ روز ورود پیاپی", ok: (s) => s.bestLogin >= 25 } },
  { id: "sunset", name: "غروب", req: { label: "۳۰۰ پیروزی", ok: (s) => s.wins >= 300 } },
  { id: "lava", name: "آتشفشان", req: { label: "۳ پیروزی در ۷×۷", ok: (s) => W(7)(s) >= 3 } },
  { id: "chocolate", name: "شکلات", req: { label: "۱۰۰ پیروزی کم‌حرکت", ok: (s) => s.efficientWins >= 100 } },
  { id: "galaxy", name: "کهکشان", req: { label: "۳ پیروزی در ۸×۸", ok: (s) => W(8)(s) >= 3 } },
  { id: "ruby", name: "یاقوت سرخ", req: { label: "۷۵۰ پیروزی", ok: (s) => s.wins >= 750 } },
  { id: "leather", name: "چرم دوخته", req: { label: "۱۰۰ پیروزی", ok: (s) => s.wins >= 100 } },
  { id: "bamboo", name: "بامبو", req: { label: "۹ روز ورود پیاپی", ok: (s) => s.bestLogin >= 9 } },
  { id: "paper", name: "کاغذ اوریگامی", req: { label: "۱۵ پیروزی کم‌حرکت", ok: (s) => s.efficientWins >= 15 } },
  { id: "steel", name: "فولاد صنعتی", req: { label: "۵ بار پیاپی ۴×۴ زیر ۵۰ ثانیه", ok: (s) => (s.bestFastRun[4] ?? 0) >= 5 } },
  { id: "turquoise", name: "کاشی فیروزه‌ای", req: { label: "۲۵۰ پیروزی", ok: (s) => s.wins >= 250 } },
  { id: "dungeon", name: "سیاه‌چال مشعل", req: { label: "۳×۳ زیر ۱۰ ثانیه", ok: under(3, 10) } },
  { id: "toxic", name: "آزمایشگاه سمی", req: { label: "۴۰ روز ورود پیاپی", ok: (s) => s.bestLogin >= 40 } },
  { id: "palace", name: "کاخ مرمرین", req: { label: "۲ پیروزی در ۹×۹", ok: (s) => W(9)(s) >= 2 } },
  { id: "billiard", name: "بیلیارد", req: { label: "۳۰ پیروزی", ok: (s) => s.wins >= 30 } },
  { id: "lego", name: "آجرهای لگو", req: { label: "۷ روز ورود پیاپی", ok: (s) => s.bestLogin >= 7 } },
  { id: "piano", name: "پیانو", req: { label: "۶۰ پیروزی", ok: (s) => s.wins >= 60 } },
  { id: "keycap", name: "کیبورد مکانیکی", req: { label: "۳×۳ زیر ۱۴ ثانیه", ok: under(3, 14) } },
  { id: "typewriter", name: "ماشین تحریر", req: { label: "۵۰ پیروزی کم‌حرکت", ok: (s) => s.efficientWins >= 50 } },
  { id: "casino", name: "ژتون کازینو", req: { label: "۱۵ پیروزی پیاپی", ok: (s) => s.bestStreak >= 15 } },
  { id: "scrabble", name: "حروف چوبی", req: { label: "۲۵ پیروزی در ۴×۴", ok: (s) => W(4)(s) >= 25 } },
  { id: "bubblewrap", name: "پلاستیک حباب‌دار", req: { label: "۵۰ پیروزی", ok: (s) => s.wins >= 50 } },
  { id: "cookie", name: "کلوچهٔ شکلاتی", req: { label: "۱۱ روز ورود پیاپی", ok: (s) => s.bestLogin >= 11 } },
  { id: "led", name: "تابلوی امتیاز", req: { label: "۳×۳ زیر ۱۸ ثانیه", ok: under(3, 18) } },
  { id: "stamp", name: "تمبر پستی", req: { label: "۲۵ پیروزی کم‌حرکت", ok: (s) => s.efficientWins >= 25 } },
  { id: "button", name: "دکمهٔ لباس", req: { label: "۸۰ پیروزی", ok: (s) => s.wins >= 80 } },
  { id: "bottlecap", name: "درِ نوشابه", req: { label: "۸ پیروزی پیاپی", ok: (s) => s.bestStreak >= 8 } },
  { id: "jelly", name: "ژله", req: { label: "۴۰ پیروزی در ۴×۴", ok: (s) => W(4)(s) >= 40 } },
  { id: "brick", name: "دیوار آجری", req: { label: "۱۵ پیروزی در ۵×۵", ok: (s) => W(5)(s) >= 15 } },
  { id: "terminal", name: "ترمینال هکری", req: { label: "۴×۴ زیر ۲۵ ثانیه", ok: under(4, 25) } },
  { id: "blueprint", name: "نقشهٔ مهندسی", req: { label: "۴ اندازهٔ متفاوت", ok: (s) => sizesDone(s) >= 4 } },
  { id: "newspaper", name: "روزنامهٔ قدیمی", req: { label: "۱۵۰ پیروزی", ok: (s) => s.wins >= 150 } },
  { id: "clay", name: "خمیر بازی", req: { label: "۱۸ روز ورود پیاپی", ok: (s) => s.bestLogin >= 18 } },
  { id: "circuit", name: "برد الکترونیکی", req: { label: "۵ بار پیاپی ۵×۵ زیر ۱۰۰ ثانیه", ok: (s) => (s.bestFastRun[5] ?? 0) >= 5 } },
  { id: "ticket", name: "بلیت سینما", req: { label: "۷۰ پیروزی کم‌حرکت", ok: (s) => s.efficientWins >= 70 } },
  { id: "pearl", name: "مروارید", req: { label: "۴۰۰ پیروزی", ok: (s) => s.wins >= 400 } },
  { id: "rune", name: "سنگ‌های جادویی", req: { label: "۱۵ پیروزی در ۶×۶", ok: (s) => W(6)(s) >= 15 } },
  { id: "denim", name: "جین دوخته", req: { label: "۳۰ پیروزی پیاپی", ok: (s) => s.bestStreak >= 30 } },
  { id: "macaron", name: "ماکارون", req: { label: "۵۰۰ پیروزی", ok: (s) => s.wins >= 500 } },
  { id: "mint", name: "نعنایی", req: { label: "۵ پیروزی", ok: (s) => s.wins >= 5 } },
  { id: "coffee", name: "قهوه", req: { label: "۱۰ پیروزی", ok: (s) => s.wins >= 10 } },
  { id: "sky", name: "آسمان صاف", req: { label: "۳ روز ورود پیاپی", ok: (s) => s.bestLogin >= 3 } },
  { id: "graphite", name: "گرافیتی", req: { label: "۲۵ پیروزی", ok: (s) => s.wins >= 25 } },
  { id: "peach", name: "هلویی", req: { label: "۳۵ پیروزی", ok: (s) => s.wins >= 35 } },
  { id: "garden-art", name: "باغ ایرانی", picture: true },
  { id: "reef-art", name: "آب‌سنگ مرجانی", price: PICTURE_PRICE, picture: true },
  { id: "cosmos-art", name: "کهکشان رنگی", price: PICTURE_PRICE, picture: true },
  { id: "isfahan-art", name: "شب اصفهان", price: PICTURE_PRICE, picture: true },
  { id: "autumn-art", name: "جنگل پاییزی", price: PICTURE_PRICE, picture: true },
  { id: "aurora-art", name: "شفق قطبی", price: PICTURE_PRICE, picture: true },
  { id: "neoncity-art", name: "شهر نئونی", price: PICTURE_PRICE, picture: true },
  { id: "bazaar-art", name: "بازار ایرانی", price: PICTURE_PRICE, picture: true },
  { id: "catspace-art", name: "گربهٔ فضانورد", price: PICTURE_PRICE, picture: true },
  { id: "gilan-art", name: "شالیزار گیلان", price: PICTURE_PRICE, picture: true },
  { id: "desert-art", name: "کاروان رؤیایی", price: PICTURE_PRICE, picture: true },
  { id: "fox-art", name: "خانوادهٔ روباه", price: PICTURE_PRICE, picture: true },
  { id: "lantern-art", name: "کوچهٔ فانوس‌ها", price: PICTURE_PRICE, picture: true },
  { id: "amir-anime-art", name: "امیرمحمد", price: PICTURE_PRICE, picture: true },
  ...MOVED_THEMES,
  ...PREMIUM_THEMES,
  ...WEEKLY_THEMES,
];
export const SPECIAL_THEMES = THEMES.filter((theme) => theme.section === "special");

export const TILE_STYLES: Theme[] = [
  { id: "solid", name: "توپر" },
  { id: "flat", name: "تخت ساده" },
  { id: "clear", name: "شفاف", req: { label: "۳ پیروزی", ok: (s) => s.wins >= 3 } },
  { id: "outline", name: "خطی", req: { label: "۵ پیروزی", ok: (s) => s.wins >= 5 } },
  { id: "pillow", name: "بالشتی", req: { label: "۱۰ پیروزی", ok: (s) => s.wins >= 10 } },
  { id: "soft", name: "نرم", req: { label: "۳ بار پیاپی ۴×۴ زیر ۱ دقیقه", ok: (s) => (s.bestFastRun[4] ?? 0) >= 3 } },
  { id: "glass", name: "شیشه‌ای", req: { label: "۳۰ پیروزی", ok: (s) => s.wins >= 30 } },
  { id: "frosted", name: "شیشه‌ای مات", price: 1_500 },
  { id: "glow-rim", name: "لبهٔ درخشان", price: 2_500 },
  { id: "gold-frame", name: "قاب طلایی", price: 6_000 },
  { id: "diamond", name: "الماس تراش‌خورده", price: 15_000 },
  { id: "royal-gem", name: "جواهر سلطنتی", price: 25_000 },
  { id: "star", name: "ستاره‌ای", price: 3_000 },
  { id: "cube3d", name: "سه‌بعدی", price: 5_000 },
  { id: "soft3d", name: "سه‌بعدی نرم", price: 7_000 },
  { id: "heart", name: "قلبی", price: 6_000 },
];

export const SIZES = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
/** Board n opens after 3 consecutive wins on board n-1, each under that board's time limit. */
export function sizeUnlocked(n: number, s: Stats, admin: boolean) {
  return admin || n === 3 || (s.bestFastRun[n - 1] ?? 0) >= 3;
}
/** The skin that owns a built-in picture, so both screens share one purchase. */
export function pictureThemeForId(pictureId: string) {
  return THEMES.find((x) => x.id === `${pictureId}-art` || (pictureId === "amir" && x.id === "amir-anime-art"))
    ?? THEMES.find((x) => x.id === pictureId);
}
/** Picture puzzles the player may use (owned, free, or all with the secret code). */
export function pictureUnlocked(pictureId: string, s: State) {
  const t = pictureThemeForId(pictureId);
  if (s.admin) return true;
  return !!t && itemUnlocked(t, s.stats, false, s.purchased);
}
export const customPicturePurchaseId = (pictureId: string) => `custom-picture:${pictureId}`;
export function customPictureUnlocked(pictureId: string, s: State = getState()) {
  return s.admin || s.purchased.includes(customPicturePurchaseId(pictureId));
}
/** Personal gallery pictures cost 500 points once; ownership persists with skin purchases. */
export function buyCustomPicture(pictureId: string) {
  const purchaseId = customPicturePurchaseId(pictureId);
  let succeeded = false;
  setState((s) => {
    if (s.admin || s.purchased.includes(purchaseId)) {
      succeeded = true;
      return s;
    }
    if (s.stats.points < PICTURE_PRICE) return s;
    succeeded = true;
    return {
      ...s,
      purchased: [...s.purchased, purchaseId],
      stats: { ...s.stats, points: s.stats.points - PICTURE_PRICE },
    };
  });
  return succeeded;
}
export function itemUnlocked(t: Theme, s: Stats, admin: boolean, owned: string[] = []) {
  if (admin || owned.includes(t.id)) return true;
  if (t.price != null) return false;
  return !t.req || t.req.ok(s, 0);
}

export function buyTheme(id: string) {
  const theme = THEMES.find((t) => t.id === id) ?? TILE_STYLES.find((t) => t.id === id);
  if (theme?.price == null) return false;
  if (theme.req && !theme.req.ok(getState().stats, 0)) return false;
  let purchased = false;
  setState((s) => {
    if (s.purchased.includes(id) || s.stats.points < theme.price!) return s;
    purchased = true;
    return {
      ...s,
      purchased: [...s.purchased, id],
      stats: { ...s.stats, points: s.stats.points - theme.price! },
    };
  });
  return purchased;
}

export type Mission = { id: string; title: string; goal: number; value: (s: Stats) => number; daily?: boolean; reward: string; points?: number };
/** Daily mission pool; each day picks 4 different templates with day-seeded goals. */
type Tpl = { id: string; t: (g: number) => string; g: number[]; v: (d: Daily) => number; pts: number };
const POOL: Tpl[] = [
  { id: "play", t: (g) => `امروز ${g} بازی شروع کن`, g: [4, 5, 6], v: (d) => d.played, pts: 10 },
  { id: "win", t: (g) => `امروز ${g} بار پیروز شو`, g: [3, 4, 5], v: (d) => d.wins, pts: 20 },
  { id: "eff", t: (g) => `${g} پیروزی کم‌حرکت امروز`, g: [1, 2, 3], v: (d) => d.efficient, pts: 30 },
  { id: "fast", t: (g) => `${g} پیروزی زیر زمان مجاز اندازه`, g: [1, 2, 3], v: (d) => d.fast, pts: 35 },
  { id: "big", t: (g) => `${g} پیروزی در صفحهٔ 4×4 یا بزرگ‌تر`, g: [1, 2, 3], v: (d) => d.big, pts: 40 },
  { id: "run", t: (g) => `${g} پیروزی پیاپی بدون رها کردن بازی`, g: [3, 4, 5], v: (d) => d.bestRun, pts: 40 },
  { id: "sizes", t: (g) => `امروز ${g} اندازهٔ متفاوت را حل کن`, g: [2, 3], v: (d) => d.sizes.length, pts: 35 },
  { id: "moves", t: (g) => `امروز در مجموع ${g} حرکت انجام بده`, g: [200, 350, 500], v: (d) => d.moves, pts: 15 },
];
const hash = (str: string) => { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };
export function dailyMissions(date: string): Mission[] {
  const pool = POOL.slice(); let h = hash(date); const out: Mission[] = [];
  while (out.length < 4) {
    h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0;
    const p = pool.splice(h % pool.length, 1)[0]!, g = p.g[(h >>> 8) % p.g.length]!;
    const points = p.pts + g * 2;
    out.push({ id: `${p.id}${g}`, daily: true, title: p.t(g), goal: g, value: (s) => p.v(s.daily), reward: `${points} امتیاز`, points });
  }
  return out;
}
export const ACHIEVEMENTS: Mission[] = [
  { id: "first", title: "اولین پازل را حل کن", goal: 1, value: (s) => s.wins, reward: "۲۵ امتیاز", points: 25 },
  { id: "w3", title: "سه بار پیروز شو", goal: 3, value: (s) => s.wins, reward: "۲۵ امتیاز", points: 25 },
  { id: "s3", title: "صفحهٔ ۳×۳ را کامل کن", goal: 1, value: (s) => s.winsBySize[3] ?? 0, reward: "۲۵ امتیاز", points: 25 },
  { id: "s4", title: "صفحهٔ ۴×۴ را کامل کن", goal: 1, value: (s) => s.winsBySize[4] ?? 0, reward: "۵۰ امتیاز", points: 50 },
  { id: "s5", title: "صفحهٔ ۵×۵ را کامل کن", goal: 1, value: (s) => s.winsBySize[5] ?? 0, reward: "۵۰ امتیاز", points: 50 },
  { id: "eff", title: "با حرکات محدود پیروز شو", goal: 1, value: (s) => s.efficientWins, reward: "۴۰ امتیاز", points: 40 },
  { id: "streak", title: "سه پیروزی پیاپی", goal: 3, value: (s) => s.bestStreak, reward: "۴۰ امتیاز", points: 40 },
  { id: "sizes", title: "سه اندازهٔ متفاوت را حل کن", goal: 3, value: (s) => sizesDone(s), reward: "۴۰ امتیاز", points: 40 },
  { id: "w10", title: "ده پیروزی", goal: 10, value: (s) => s.wins, reward: "۵۰ امتیاز", points: 50 },
];

export const WEEKLY: Mission[] = [
  { id: "wlogin", title: "۷ روز این هفته وارد بازی شو", goal: 7, value: (s) => s.week.days, reward: "" },
  { id: "wwins", title: "این هفته ۱۵ بار پیروز شو", goal: 15, value: (s) => s.week.wins, reward: "" },
  { id: "weff", title: "این هفته ۵ پیروزی کم‌حرکت", goal: 5, value: (s) => s.week.efficient, reward: "" },
];
export const weeklyKey = (id: string, s: Stats) => `${s.week.id}:${id}`;
export function claimWeeklyTheme() {
  const t = weeklyTheme();
  setState((s) => ({ ...s, claimed: [...s.claimed, `${s.stats.week.id}:theme`], stats: { ...s.stats, unlocked: [...new Set([...s.stats.unlocked, t.id])] } }));
}

export function claim(id: string, points = 0) {
  setState((s) => (s.claimed.includes(id) ? s : {
    ...s,
    claimed: [...s.claimed, id],
    stats: { ...s.stats, points: s.stats.points + Math.max(0, points) },
  }));
}
export const dailyKey = (id: string, s: Stats) => `${s.daily.date}:${id}`;
export function getState() { refreshCalendar(); return state; }
