package com.adad.slidingpuzzle;

import android.content.Context;
import android.net.wifi.WifiManager;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** UDP broadcast on the local Wi-Fi / hotspot so phones can find each other's matches. */
@CapacitorPlugin(name = "LanBroadcast")
public class LanBroadcastPlugin extends Plugin {
    private DatagramSocket socket;
    private Thread reader;
    private WifiManager.MulticastLock lock;
    private int port = 47321;
    private final ExecutorService sender = Executors.newSingleThreadExecutor();

    @PluginMethod
    public void start(PluginCall call) {
        port = call.getInt("port", 47321);
        try {
            closeSocket();
            WifiManager wifi = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null) {
                lock = wifi.createMulticastLock("npz-lan");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
            DatagramSocket s = new DatagramSocket(null);
            s.setReuseAddress(true);
            s.setBroadcast(true);
            s.bind(new InetSocketAddress(port));
            socket = s;
            reader = new Thread(() -> {
                byte[] buf = new byte[65507];
                while (!s.isClosed()) {
                    try {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        s.receive(p);
                        JSObject ev = new JSObject();
                        ev.put("data", new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8));
                        ev.put("from", p.getAddress().getHostAddress());
                        notifyListeners("message", ev);
                    } catch (Exception e) {
                        if (s.isClosed()) break;
                    }
                }
            });
            reader.setDaemon(true);
            reader.start();
            call.resolve();
        } catch (Exception e) {
            call.reject("LAN start failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void send(PluginCall call) {
        final String data = call.getString("data", "");
        final DatagramSocket s = socket;
        if (s == null) { call.reject("not started"); return; }
        sender.execute(() -> {
            byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
            for (InetAddress target : targets()) {
                try { s.send(new DatagramPacket(bytes, bytes.length, target, port)); } catch (Exception ignored) {}
            }
        });
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        closeSocket();
        call.resolve();
    }

    /** Global broadcast plus every interface's subnet broadcast (needed on hotspots and some routers). */
    private Set<InetAddress> targets() {
        Set<InetAddress> out = new LinkedHashSet<>();
        try { out.add(InetAddress.getByName("255.255.255.255")); } catch (Exception ignored) {}
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress a : ni.getInterfaceAddresses()) {
                    if (a.getBroadcast() != null) out.add(a.getBroadcast());
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void closeSocket() {
        if (socket != null) { socket.close(); socket = null; }
        if (lock != null && lock.isHeld()) lock.release();
        lock = null;
    }

    @Override
    protected void handleOnDestroy() { closeSocket(); }
}
