import { describe, it, expect } from "vitest";
import { groupThousands } from "@/lib/digits";
describe("thousand separators", () => {
  it("10000 reads 10,000", () => expect(groupThousands(10000)).toBe("10,000"));
  it("8000000 reads 8,000,000", () => expect(groupThousands(8000000)).toBe("8,000,000"));
  it("small numbers unchanged", () => expect(groupThousands(660)).toBe("660"));
});
