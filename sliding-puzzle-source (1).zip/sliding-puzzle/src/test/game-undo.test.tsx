import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Game } from "@/routes/index";

function legalTile() {
  const tiles = [...document.querySelectorAll<HTMLButtonElement>(".puzzle-tile")];
  const first = tiles[0];
  if (!first) throw new Error("Puzzle tiles were not rendered");
  const cellSize = Number.parseFloat(first.style.width);
  const step = cellSize + 6;
  const occupied = new Set(
    tiles.map((tile) => {
      const match = tile.style.transform.match(/translate\(([-\d.]+)px,\s*([-\d.]+)px\)/);
      if (!match) throw new Error(`Unexpected tile transform: ${tile.style.transform}`);
      return `${Math.round(Number(match[2]) / step)},${Math.round(Number(match[1]) / step)}`;
    }),
  );
  let blank = "";
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 3; col++) {
      if (!occupied.has(`${row},${col}`)) blank = `${row},${col}`;
    }
  }
  const [blankRow, blankCol] = blank.split(",").map(Number);
  const candidate = tiles.find((tile) => {
    const match = tile.style.transform.match(/translate\(([-\d.]+)px,\s*([-\d.]+)px\)/);
    if (!match) return false;
    const row = Math.round(Number(match[2]) / step);
    const col = Math.round(Number(match[1]) / step);
    return Math.abs(row - blankRow!) + Math.abs(col - blankCol!) === 1;
  });
  if (!candidate) throw new Error("No legal move was found");
  return candidate;
}

function clockCentiseconds() {
  const value = document.querySelectorAll(".game-stats .stat-card .stat-value")[1]?.textContent?.trim();
  const match = value?.match(/^(\d+):(\d{2})\.(\d{2})$/);
  if (!match) throw new Error(`Unexpected game clock: ${value}`);
  return (Number(match[1]) * 60 + Number(match[2])) * 100 + Number(match[3]);
}

describe("game undo", () => {
  it("restores the clock snapshot instead of keeping time from the undone move", async () => {
    render(<Game n={3} mode="training" back={() => {}} />);
    fireEvent.click(legalTile());

    await waitFor(() => {
      expect(document.querySelector(".game-stats")?.textContent).toContain("1");
    });
    await new Promise((resolve) => window.setTimeout(resolve, 100));
    const beforeSecondMove = clockCentiseconds();
    fireEvent.click(legalTile());
    await new Promise((resolve) => window.setTimeout(resolve, 100));
    const beforeUndo = clockCentiseconds();
    fireEvent.click(screen.getByRole("button", { name: "برگشت" }));

    await waitFor(() => {
      expect(clockCentiseconds()).toBeLessThan(beforeUndo - 4);
      expect(clockCentiseconds()).toBeGreaterThanOrEqual(beforeSecondMove - 2);
      expect(clockCentiseconds()).toBeLessThanOrEqual(beforeSecondMove + 5);
    });
  });
});
