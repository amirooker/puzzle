import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.adad.slidingpuzzle",
  appName: "پازل اعداد",
  webDir: ".output/public",
};

export default config;
