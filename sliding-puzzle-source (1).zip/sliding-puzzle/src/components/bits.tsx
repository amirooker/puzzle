import type { ReactNode } from "react";
import { ArrowRight } from "lucide-react";
import { useGame } from "@/lib/store";
import { toDigits, groupThousands } from "@/lib/digits";

export function N({ v, className = "" }: { v: number | string; className?: string }) {
  const d = useGame((s) => s.digits);
  return <span dir="ltr" style={{ unicodeBidi: "isolate" }} className={`${d === "fa" ? "num-fa" : "num-en"} ${className}`}>{toDigits(groupThousands(v), d)}</span>;
}

/** Render Persian text with any embedded digits in the chosen digit font */
export function T({ children }: { children: string }) {
  // Keep "10,000" / "۱۰٬۰۰۰" as one number so right-to-left text doesn't flip it to "000,10".
  const parts = children.split(/([0-9۰-۹]+(?:\s*[,،٬]\s*[0-9۰-۹]+)*)/);
  return <>{parts.map((p, i) => (/[0-9۰-۹]/.test(p) ? <N key={i} v={Number(p.replace(/[۰-۹]/g, (c) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(c))).replace(/[\s,،٬]/g, ""))} /> : <span key={i}>{p}</span>))}</>;
}

export function Header({ title, back, right }: { title: ReactNode; back: () => void; right?: ReactNode }) {
  return (
    <header className="mb-4 flex items-center gap-3">
      <button onClick={back} aria-label="بازگشت" className="surface grid size-11 shrink-0 place-items-center rounded-xl border"><ArrowRight className="size-5" /></button>
      <h1 className="min-w-0 flex-1 truncate text-xl font-bold">{title}</h1>
      {right}
    </header>
  );
}

export const Stat = ({ label, value }: { label: string; value: ReactNode }) => (
  <div className="stat-card surface min-w-0 overflow-hidden rounded-xl border px-1.5 py-2 text-center">
    <div className="truncate text-xs text-muted-foreground">{label}</div>
    <div className="stat-value mt-0.5 min-w-0 overflow-hidden text-ellipsis whitespace-nowrap font-bold">{value}</div>
  </div>
);

/** Lightweight falling confetti (only rendered for a few seconds after a win). */
export function Confetti() {
  const colors = ["oklch(0.8 0.17 90)", "oklch(0.65 0.2 25)", "oklch(0.7 0.15 230)", "oklch(0.72 0.18 145)", "oklch(0.75 0.15 330)"];
  return (
    <div className="confetti" aria-hidden>
      {Array.from({ length: 28 }, (_, i) => (
        <i key={i} style={{ left: `${(i * 37) % 100}%`, background: colors[i % colors.length], animationDuration: `${2.2 + (i % 5) * 0.35}s`, animationDelay: `${(i % 7) * 0.12}s`, ["--dx" as string]: `${((i * 23) % 80) - 40}px` }} />
      ))}
    </div>
  );
}
