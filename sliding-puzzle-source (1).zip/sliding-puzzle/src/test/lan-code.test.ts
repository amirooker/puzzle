import { describe, expect, it } from "vitest";
import { codeToIp, ipToCode, pickLocalIp } from "@/lib/lan";

describe("room code ↔ host address", () => {
  it("round-trips a hotspot address", () => {
    const code = ipToCode("192.168.43.1");
    expect(codeToIp(code, "192.168.43.120")).toBe("192.168.43.1");
  });
  it("accepts a full IP typed directly", () => {
    expect(codeToIp("10.0.0.5", null)).toBe("10.0.0.5");
  });
  it("prefers the hotspot/Wi-Fi interface over mobile data", () => {
    expect(pickLocalIp([{ ip: "10.44.2.9", iface: "rmnet_data0" }, { ip: "192.168.43.1", iface: "ap0" }])).toBe("192.168.43.1");
  });
});
