import gardenArt from "@/assets/generated/skin-garden.jpg";
import reefArt from "@/assets/generated/skin-reef.jpg";
import cosmosArt from "@/assets/generated/skin-cosmos.jpg";
import isfahanArt from "@/assets/generated/skin-isfahan.jpg";
import autumnArt from "@/assets/generated/skin-autumn.jpg";
import auroraArt from "@/assets/generated/skin-aurora.jpg";
import neoncityArt from "@/assets/generated/skin-neoncity.jpg";
import bazaarArt from "@/assets/art-bazaar.jpg";
import catspaceArt from "@/assets/art-catspace.jpg";
import amirArt from "@/assets/art-amir-anime.jpg";
import gilanArt from "@/assets/generated/skin-gilan.jpg";
import desertArt from "@/assets/generated/skin-desert.jpg";
import foxArt from "@/assets/generated/skin-fox.jpg";
import lanternArt from "@/assets/generated/skin-lantern.jpg";
import { materialTextureUrls } from "@/lib/theme-textures";

/** Ready-made pictures that ship with the game. */
export const BUILTIN_PICTURES: { id: string; name: string; src: string }[] = [
  { id: "garden", name: "باغ ایرانی", src: gardenArt },
  { id: "reef", name: "آب‌سنگ مرجانی", src: reefArt },
  { id: "cosmos", name: "کهکشان رنگی", src: cosmosArt },
  { id: "isfahan", name: "شب اصفهان", src: isfahanArt },
  { id: "autumn", name: "جنگل پاییزی", src: autumnArt },
  { id: "aurora", name: "شفق قطبی", src: auroraArt },
  { id: "neoncity", name: "شهر نئونی", src: neoncityArt },
  { id: "bazaar", name: "بازار ایرانی", src: bazaarArt },
  { id: "catspace", name: "گربهٔ فضانورد", src: catspaceArt },
  { id: "gilan", name: "شالیزار گیلان", src: gilanArt },
  { id: "desert", name: "کاروان رؤیایی", src: desertArt },
  { id: "fox", name: "خانوادهٔ روباه", src: foxArt },
  { id: "lantern", name: "کوچهٔ فانوس‌ها", src: lanternArt },
  { id: "amir", name: "امیرمحمد", src: amirArt },
  ...([["peacock", "پر طاووس"], ["minakari", "میناکاری"], ["persian-mosaic", "موزاییک پارسی"], ["khatam", "خاتم‌کاری"], ["iranian-brocade", "قالیچهٔ نگارین"],
    ["lapis", "لاجورد"], ["emerald-velvet", "مخمل زمردی"], ["rose-marble", "مرمر صورتی"], ["leopard-weave", "پارچهٔ پلنگی"], ["icon-wood", "چوب"]] as const)
    .filter(([id]) => materialTextureUrls[id]).map(([id, name]) => ({ id, name, src: materialTextureUrls[id]! })),
];
export const pictureById = (id: string | null | undefined) => BUILTIN_PICTURES.find((p) => p.id === id);
