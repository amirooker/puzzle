/**
 * Local network link for multiplayer on several phones (same Wi-Fi, or one phone's hotspot).
 * On Android it uses the bundled LanBroadcast plugin: UDP broadcast for discovery plus direct
 * (unicast) packets to every known peer, so it also works on routers that block broadcast.
 * In a browser it falls back to BroadcastChannel so two tabs can play together for testing.
 */
import { Capacitor, registerPlugin, type PluginListenerHandle } from "@capacitor/core";

type NetInfo = { ips: { ip: string; iface: string }[]; gateway: string };
type LanPlugin = {
  start(options: { port: number }): Promise<void>;
  send(options: { data: string; targets?: string[] }): Promise<void>;
  info(): Promise<NetInfo>;
  stop(): Promise<void>;
  addListener(event: "message", cb: (e: { data: string; from: string }) => void): Promise<PluginListenerHandle>;
};
const Native = registerPlugin<LanPlugin>("LanBroadcast");
const PORT = 47321;
const APP_TAG = "npz1";

/** Messages carry `_ip`: the sender's address as seen by this phone (native only). */
export type LanMessage = { t: string; from: string; _ip?: string; [key: string]: unknown };
export type LanLink = {
  send: (msg: Record<string, unknown> & { t: string }) => void;
  close: () => void;
  native: boolean;
  /** Always send to this address directly too (unicast). */
  addPeer: (ip: string) => void;
  /** This phone's local IPv4 address (best guess) and its Wi-Fi gateway (the hotspot phone). */
  info: () => Promise<{ ip: string | null; gateway: string | null; prefix: string | null }>;
};

export const myDeviceId = (() => {
  const g = globalThis as { __npzId?: string };
  if (!g.__npzId) g.__npzId = Math.random().toString(36).slice(2, 10);
  return g.__npzId;
})();

const isPrivate = (ip: string) => /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);
/** Prefer hotspot / Wi-Fi interfaces over mobile-data ones. */
export function pickLocalIp(list: { ip: string; iface: string }[]): string | null {
  const score = (x: { ip: string; iface: string }) =>
    (isPrivate(x.ip) ? 10 : 0) + (/^(ap|swlan|softap)/.test(x.iface) ? 6 : /^wlan/.test(x.iface) ? 5 : /^(rmnet|ccmni|pdp|v4-)/.test(x.iface) ? -8 : 0) + (x.ip.startsWith("192.168.") ? 1 : 0);
  return [...list].filter((x) => /^\d+\.\d+\.\d+\.\d+$/.test(x.ip) && !x.ip.startsWith("127.")).sort((a, b) => score(b) - score(a))[0]?.ip ?? null;
}

/** Room / connection code: the last two parts of the host's address (works on any /16 network). */
export function ipToCode(ip: string): string {
  const p = ip.split(".").map(Number);
  return String(p[2]! * 256 + p[3]!).padStart(5, "0");
}
/** Turn a typed code (or a full IP) back into an address, using this phone's own network prefix. */
export function codeToIp(code: string, myIp: string | null): string | null {
  const c = code.trim();
  if (/^\d+\.\d+\.\d+\.\d+$/.test(c)) return c;
  if (!/^\d{1,5}$/.test(c) || !myIp) return null;
  const n = Number(c); if (n > 65535) return null;
  const p = myIp.split(".");
  return `${p[0]}.${p[1]}.${Math.floor(n / 256)}.${n % 256}`;
}

export async function openLan(onMessage: (msg: LanMessage) => void): Promise<LanLink> {
  const peers = new Set<string>();
  const deliver = (raw: string, ip?: string) => {
    try {
      const msg = JSON.parse(raw) as LanMessage & { app?: string };
      if (msg.app !== APP_TAG || msg.from === myDeviceId) return;
      if (ip) { peers.add(ip); msg._ip = ip; }
      onMessage(msg);
    } catch { /* ignore foreign packets */ }
  };
  const encode = (msg: Record<string, unknown>) => JSON.stringify({ ...msg, app: APP_TAG, from: myDeviceId });

  if (Capacitor.isNativePlatform()) {
    await Native.start({ port: PORT });
    const handle = await Native.addListener("message", (e) => deliver(e.data, e.from));
    return {
      native: true,
      send: (msg) => { void Native.send({ data: encode(msg), targets: [...peers] }).catch(() => {}); },
      close: () => { void handle.remove(); void Native.stop().catch(() => {}); },
      addPeer: (ip) => { peers.add(ip); },
      info: async () => {
        try {
          const i = await Native.info();
          const ip = pickLocalIp(i.ips);
          return { ip, gateway: i.gateway && i.gateway !== "0.0.0.0" ? i.gateway : null, prefix: ip ? ip.split(".").slice(0, 2).join(".") : null };
        } catch { return { ip: null, gateway: null, prefix: null }; }
      },
    };
  }
  const channel = new BroadcastChannel("npz-lan");
  channel.onmessage = (e) => deliver(String(e.data));
  return {
    native: false,
    send: (msg) => channel.postMessage(encode(msg)),
    close: () => channel.close(),
    addPeer: () => {},
    info: async () => ({ ip: null, gateway: null, prefix: null }),
  };
}
