/**
 * Local network link for multiplayer on several phones connected to the same Wi-Fi or hotspot.
 * On Android it uses the bundled LanBroadcast plugin (UDP broadcast, no internet needed).
 * In a browser it falls back to BroadcastChannel so two tabs can play together for testing.
 */
import { Capacitor, registerPlugin, type PluginListenerHandle } from "@capacitor/core";

type LanPlugin = {
  start(options: { port: number }): Promise<void>;
  send(options: { data: string }): Promise<void>;
  stop(): Promise<void>;
  addListener(event: "message", cb: (e: { data: string; from: string }) => void): Promise<PluginListenerHandle>;
};
const Native = registerPlugin<LanPlugin>("LanBroadcast");
const PORT = 47321;
const APP_TAG = "npz1";

export type LanMessage = { t: string; from: string; [key: string]: unknown };
export type LanLink = { send: (msg: Record<string, unknown> & { t: string }) => void; close: () => void; native: boolean };

export const myDeviceId = (() => {
  const g = globalThis as { __npzId?: string };
  if (!g.__npzId) g.__npzId = Math.random().toString(36).slice(2, 10);
  return g.__npzId;
})();

export async function openLan(onMessage: (msg: LanMessage) => void): Promise<LanLink> {
  const deliver = (raw: string) => {
    try {
      const msg = JSON.parse(raw) as LanMessage & { app?: string };
      if (msg.app !== APP_TAG || msg.from === myDeviceId) return;
      onMessage(msg);
    } catch { /* ignore foreign packets */ }
  };
  const encode = (msg: Record<string, unknown>) => JSON.stringify({ ...msg, app: APP_TAG, from: myDeviceId });

  if (Capacitor.isNativePlatform()) {
    await Native.start({ port: PORT });
    const handle = await Native.addListener("message", (e) => deliver(e.data));
    return {
      native: true,
      send: (msg) => { void Native.send({ data: encode(msg) }).catch(() => {}); },
      close: () => { void handle.remove(); void Native.stop().catch(() => {}); },
    };
  }
  const channel = new BroadcastChannel("npz-lan");
  channel.onmessage = (e) => deliver(String(e.data));
  return { native: false, send: (msg) => channel.postMessage(encode(msg)), close: () => channel.close() };
}
