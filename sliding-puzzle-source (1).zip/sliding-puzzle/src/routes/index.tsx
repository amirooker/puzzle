import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Volume2, VolumeX, Lock, Pause, Play, RotateCcw, Shuffle, Undo2, Settings, Trophy, Palette, Grid3x3, Target, Check, Eye, ImagePlus, Image as ImageIcon, Coins, Timer, Sparkles, Users, Zap, Home as HomeIcon, ChevronLeft, X, Trash2 } from "lucide-react";
import { Decor } from "@/components/Decor";
import { PuzzleBoard, tileAttrs } from "@/components/PuzzleBoard";
import { Multiplayer } from "@/components/Multiplayer";
import { N, T, Header, Stat, Confetti } from "@/components/bits";
import { playSlide, playWin, playClick, playClaim, playLose } from "@/lib/sound";
import { epochMissions, epochKey, epochCountdown, EPOCH_DAYS } from "@/lib/achievements";
import { shuffle, dailyShuffle, slide, isGoal, reverseGoal, solved, type Board, type ReverseLevel } from "@/lib/puzzle";
import { fmtTime } from "@/lib/digits";
import { materialTextureUrls } from "@/lib/theme-textures";
import { applyPremiumPalette, CSS_PREMIUM_IDS } from "@/lib/premium";
import { installBackButton, useBackHandler, exitApp } from "@/lib/back";
import { getState as _gs } from "@/lib/store";
import gardenArt from "@/assets/generated/skin-garden.jpg";
import reefArt from "@/assets/generated/skin-reef.jpg";
import cosmosArt from "@/assets/generated/skin-cosmos.jpg";
import isfahanArt from "@/assets/generated/skin-isfahan.jpg";
import autumnArt from "@/assets/generated/skin-autumn.jpg";
import auroraArt from "@/assets/generated/skin-aurora.jpg";
import neoncityArt from "@/assets/generated/skin-neoncity.jpg";
import bazaarArt from "@/assets/art-bazaar.jpg";
import catspaceArt from "@/assets/art-catspace.jpg";
import amirArt from "@/assets/art-amir-anime.jpg";
import gilanArt from "@/assets/generated/skin-gilan.jpg";
import desertArt from "@/assets/generated/skin-desert.jpg";
import foxArt from "@/assets/generated/skin-fox.jpg";
import lanternArt from "@/assets/generated/skin-lantern.jpg";
import { BUILTIN_PICTURES } from "@/lib/pictures";
import ribbonRed from "@/assets/ribbons/ribbon-red.png";
import ribbonGreen from "@/assets/ribbons/ribbon-green.png";
import ribbonBlue from "@/assets/ribbons/ribbon-blue.png";
import ribbonGray from "@/assets/ribbons/ribbon-gray.png";
/** Load and decode ribbon pictures up front so ribbon and text always appear together. */
const RIBBONS = [ribbonRed, ribbonGreen, ribbonBlue, ribbonGray];
const ribbonCache: HTMLImageElement[] = [];
import { Splash } from "@/components/Splash";
import {
  useGame, setState, THEMES, SPECIAL_THEMES, TILE_STYLES, SIZES, dailyMissions, sizeUnlocked, itemUnlocked, buyTheme,
  buyCustomPicture, customPicturePurchaseId, customPictureUnlocked, pictureThemeForId, pictureUnlocked,
  PICTURE_PRICE, recordWin, recordPhotoWin, recordStart, breakStreak, tryAdminCode, newSkinIds, markSkinsSeen, claim, dailyKey, moveLimit, type Mission, type Theme,
  WEEKLY, weeklyKey, timeLimit, weeklyTheme, claimWeeklyTheme,
} from "@/lib/store";
const getSound = () => _gs().sound;
const getTheme = () => _gs().theme;

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "پازل اعداد — بازی کشویی چوبی" },
      { name: "description", content: "پازل کشویی اعداد با صفحه‌های ۳×۳ تا ۱۲×۱۲، پوسته‌ها، حالت چند نفره، مأموریت‌ها و دستاوردها." },
      { property: "og:title", content: "پازل اعداد — بازی کشویی چوبی" },
      { property: "og:description", content: "پازل کشویی اعداد فارسی با پوسته‌های ویژه، چند نفره روی یک وای‌فای و مأموریت‌ها." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: App,
});

type Screen = "home" | "play" | "modes" | "themes" | "missions" | "progress" | "settings" | "photo" | "multi";
type GameMode = "classic" | "speed" | "limited" | "relaxed" | "daily" | "strict" | "record" | "training" | "survival" | "stages" | "reverse";
type GameHistoryStep = { board: Board; elapsedMs: number };
type SavedPhoto = { id: string; data: string };
type PhotoPurchaseRequest = { kind: "custom" | "theme"; id: string; title: string; src: string; price: number; requirement?: string | undefined };
const pictureSkins: Record<string, string> = { "garden-art": gardenArt, "reef-art": reefArt, "cosmos-art": cosmosArt, "isfahan-art": isfahanArt, "autumn-art": autumnArt, "aurora-art": auroraArt, "neoncity-art": neoncityArt, "bazaar-art": bazaarArt, "catspace-art": catspaceArt, "amir-anime-art": amirArt, "gilan-art": gilanArt, "desert-art": desertArt, "fox-art": foxArt, "lantern-art": lanternArt };

const MODES: { id: GameMode; title: string; detail: string; icon: typeof Grid3x3 }[] = [
  { id: "classic", title: "کلاسیک", detail: "ثبت زمان، حرکت و رکورد شخصی", icon: Grid3x3 },
  { id: "speed", title: "سرعتی", detail: "پیش از تمام شدن زمان مجاز حل کن", icon: Zap },
  { id: "limited", title: "حرکات محدود", detail: "حل پازل پیش از تمام‌شدن حرکت‌ها", icon: Target },
  { id: "relaxed", title: "آرام", detail: "بدون نمایش زمان و فشار رکورد", icon: Timer },
  { id: "daily", title: "چالش روزانه", detail: "یک صفحهٔ یکسان برای همه در هر روز", icon: Target },
  { id: "strict", title: "سخت‌گیرانه", detail: "اشتباه‌های لمس، امتیاز مرحله را کم می‌کند", icon: Lock },
  { id: "record", title: "رکوردشکنی", detail: "نتیجه‌ات را با بهترین رکورد خودت بسنج", icon: Trophy },
  { id: "training", title: "تمرینی", detail: "تمرین آزاد؛ در آمار و رکورد حساب نمی‌شود", icon: Sparkles },
  { id: "survival", title: "بقا", detail: "چند پازل را پیش از پایان زمان حل کن", icon: Timer },
  { id: "stages", title: "مرحله‌ای", detail: "با هر برد به صفحهٔ بزرگ‌تر برو", icon: Grid3x3 },
  { id: "reverse", title: "معکوس", detail: "از چیدمان معمولی به هدف ویژه برس", icon: RotateCcw },
];
const modeInfo = (id: string) => MODES.find((m) => m.id === id) ?? MODES[0]!;

type Preview = { kind: "theme" | "tiles"; id: string } | null;

function App() {
  const theme = useGame((s) => s.theme);
  const tiles = useGame((s) => s.tileStyle);
  const purchased = useGame((s) => s.purchased);
  const size = useGame((s) => s.size);
  const mode = useGame((s) => s.mode) as GameMode;
  const reverseLevel = useGame((s) => s.reverseLevel) as ReverseLevel;
  const stats = useGame((s) => s.stats); const admin = useGame((s) => s.admin);
  const [history, setHistory] = useState<Screen[]>(["home"]);
  const [preview, setPreview] = useState<Preview>(null);
  const [toast, setToast] = useState("");
  const [gameKey, setGameKey] = useState(0);
  const screen = history.at(-1)!;
  const go = (s: Screen) => setHistory((h) => [...h, s]);
  const back = () => setHistory((h) => h.length > 1 ? h.slice(0, -1) : h);
  const home = () => setHistory(["home"]);
  useEffect(() => { for (const src of RIBBONS) { const im = new Image(); im.src = src; void im.decode?.().catch(() => {}); ribbonCache.push(im); } }, []);
  // Skins count as "seen" only after leaving the skins page (not on mount/unmount, which runs twice in dev).
  const prevScreen = useRef<Screen>("home");
  useEffect(() => {
    if (prevScreen.current === "themes" && screen !== "themes") markSkinsSeen();
    prevScreen.current = screen;
  }, [screen]);

  useEffect(() => {
    const th = THEMES.find((t) => t.id === theme), ts = TILE_STYLES.find((t) => t.id === tiles);
    if (!th || !itemUnlocked(th, stats, admin, purchased)) setState((s) => ({ ...s, theme: "wood" }));
    if (!ts || !itemUnlocked(ts, stats, admin, purchased)) setState((s) => ({ ...s, tileStyle: "solid" }));
  }, [theme, tiles, stats, admin, purchased]);
  const shownTheme = preview?.kind === "theme" ? preview.id : theme;
  const shownTiles = preview?.kind === "tiles" ? preview.id : tiles;
  useEffect(() => {
    for (const [id, url] of Object.entries(materialTextureUrls)) document.documentElement.style.setProperty(`--material-image-${id}`, `url("${url}")`);
  }, []);
  useEffect(() => {
    document.documentElement.dataset["theme"] = shownTheme;
    document.documentElement.dataset["tiles"] = shownTiles;
    applyPremiumPalette(shownTheme);
  }, [shownTheme, shownTiles]);

  // Phone back button: one step back; on the home screen press twice to leave.
  const lastPress = useRef(0);
  useEffect(() => installBackButton(() => {
    const now = Date.now();
    if (now - lastPress.current < 2000) { void exitApp(); return; }
    lastPress.current = now;
    setToast("برای خروج، دوباره دکمهٔ برگشت را بزنید");
  }), []);
  useBackHandler(() => { if (screen === "home") return false; back(); return true; });
  useEffect(() => { if (!toast) return; const id = window.setTimeout(() => setToast(""), 2000); return () => window.clearTimeout(id); }, [toast]);

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))]">
      <Decor theme={shownTheme} />
      {screen === "home" && <Home go={go} start={() => { setGameKey((k) => k + 1); go("play"); }} />}
      {screen === "play" && <Game key={`${gameKey}-${size}-${mode}-${reverseLevel}`} n={size} back={back} home={home} mode={mode} reverseLevel={reverseLevel}
        {...(mode === "stages" && size < 12 ? { nextStage: () => setState((s) => ({ ...s, size: Math.min(12, s.size + 1) })) } : {})} />}
      {screen === "modes" && <Modes back={back} />}
      {screen === "themes" && <Themes back={back} preview={preview} setPreview={setPreview} />}
      {screen === "missions" && <Missions back={back} />}
      {screen === "progress" && <Progress back={back} />}
      {screen === "settings" && <SettingsScreen back={back} />}
      {screen === "photo" && <PhotoPuzzle back={back} />}
      {screen === "multi" && <Multiplayer back={back} home={home} />}
      {toast && <div className="app-toast" role="status">{toast}</div>}
      <Splash />
    </main>
  );
}

function Home({ go, start }: { go: (s: Screen) => void; start: () => void }) {
  const wins = useGame((s) => s.stats.wins);
  const points = useGame((s) => s.stats.points);
  const stats = useGame((s) => s.stats); const admin = useGame((s) => s.admin);
  const size = useGame((s) => s.size);
  const mode = modeInfo(useGame((s) => s.mode));
  const sizeRow = useRef<HTMLDivElement>(null);
  const items: [Screen, string, typeof Trophy][] = [
    ["multi", "چند نفره", Users], ["photo", "پازل تصویری", ImageIcon], ["missions", "مأموریت‌ها و دستاوردها", Target],
    ["themes", "پوسته‌ها و کلکسیون من", Palette], ["progress", "پیشرفت من", Trophy], ["settings", "تنظیمات", Settings],
  ];
  const ModeIcon = mode.icon;
  const newCount = useGame((s) => newSkinIds(s).length);
  return (
    <div className="flex flex-1 flex-col gap-5">
      <div className="flex items-center justify-end">
        <span className="points-badge" aria-label="امتیاز"><Coins className="size-6 text-primary" /><N v={points} /></span>
      </div>
      <div className="text-center animate-pop">
        <div className="board-frame mx-auto mb-4 grid w-36 grid-cols-3 gap-1.5 rounded-2xl p-2.5" dir="ltr">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((v) => <div key={v} {...tileAttrs(v)} className="tile grid aspect-square place-items-center text-2xl"><N v={v} /></div>)}
        </div>
        <h1 className="text-4xl font-bold">پازل اعداد</h1>
        <p className="mt-1 text-sm text-muted-foreground">کاشی‌ها را بلغزان و به ترتیب بچین · <N v={wins} /> پیروزی</p>
      </div>
      <section>
        <h2 className="mb-2 text-sm font-bold text-muted-foreground">اندازهٔ صفحه</h2>
        <div ref={sizeRow} className="chip-row" dir="ltr">
          {SIZES.map((n) => {
            const ok = sizeUnlocked(n, stats, admin);
            return <button key={n} disabled={!ok} aria-pressed={size === n} onClick={() => setState((s) => ({ ...s, size: n }))} className="size-chip surface">
              {ok ? <N v={`${n}×${n}`} /> : <span className="inline-flex items-center gap-1"><Lock className="size-3" /><N v={`${n}×${n}`} /></span>}
            </button>;
          })}
        </div>
      </section>
      <button onClick={() => go("modes")} className="surface flex items-center gap-3 rounded-xl border px-4 py-3 text-start">
        <span className="mode-icon grid size-10 shrink-0 place-items-center rounded-xl"><ModeIcon className="size-5" /></span>
        <span className="flex-1"><span className="block text-xs text-muted-foreground">حالت بازی</span><b>{mode.title}</b></span>
        <ChevronLeft className="size-5 text-muted-foreground" />
      </button>
      <button onClick={start} className="btn-wood rounded-2xl py-4 text-xl font-bold">
        شروع بازی <N v={`${size}×${size}`} className="ms-1" />
      </button>
      <nav className="grid gap-2.5">
        {items.map(([s, label, Icon]) => (
          <button key={s} onClick={() => go(s)} className="surface flex items-center gap-3 rounded-xl border px-4 py-3.5 text-start text-lg">
            <Icon className="size-5 text-primary" /><span className="flex-1">{label}</span>
            {s === "themes" && newCount > 0 && <span className="new-badge" aria-label="پوستهٔ جدید"><span className="new-dot" />جدید <N v={newCount} /></span>}
          </button>
        ))}
      </nav>
    </div>
  );
}

function Modes({ back }: { back: () => void }) {
  const current = useGame((s) => s.mode) as GameMode;
  const currentLevel = useGame((s) => s.reverseLevel) as ReverseLevel;
  const [mode, setMode] = useState<GameMode>(current);
  const [level, setLevel] = useState<ReverseLevel>(currentLevel);
  const save = () => { setState((s) => ({ ...s, mode, reverseLevel: level })); back(); };
  return (
    <div className="flex flex-1 flex-col">
      <Header title="حالت بازی" back={back} />
      <div className="grid gap-2.5">
        {MODES.map(({ id, title, detail, icon: Icon }) => (
          <button key={id} onClick={() => setMode(id)} className={`mode-card surface flex items-center gap-3 rounded-2xl border p-3 text-start ${mode === id ? "mode-card-active" : ""}`}>
            <span className="mode-icon grid size-11 shrink-0 place-items-center rounded-xl"><Icon className="size-5" /></span>
            <span className="min-w-0 flex-1">
              <span className="block font-bold">{title}</span>
              <span className="mt-0.5 block text-xs text-muted-foreground">{detail}</span>
            </span>
            {mode === id && <Check className="size-5 shrink-0 text-primary" />}
          </button>
        ))}
      </div>
      {mode === "reverse" && (
        <section className="surface mt-4 rounded-2xl border p-3">
          <h2 className="mb-2 font-bold">درجهٔ حالت معکوس</h2>
          <div className="grid grid-cols-2 gap-2">
            {([["easy", "آسان", "چیدمان نزولی"], ["medium", "متوسط", "چیدمان مارپیچی"], ["hard", "سخت", "هدف تصادفیِ قابل‌حل"], ["pro", "حرفه‌ای", "هدف تصادفی با سقف حرکت"]] as [ReverseLevel, string, string][]).map(([id, title, caption]) => (
              <button key={id} onClick={() => setLevel(id)} className={`rounded-xl border p-2 text-start ${level === id ? "btn-wood" : "surface"}`}>
                <span className="block font-bold">{title}</span><span className="text-xs opacity-80">{caption}</span>
              </button>
            ))}
          </div>
        </section>
      )}
      <button onClick={save} className="btn-wood sticky bottom-3 mt-5 rounded-2xl py-4 text-lg font-bold">تأیید</button>
    </div>
  );
}

export function Game({ n, back, home, image, mode = "classic", reverseLevel = "easy", nextStage }: {
  n: number; back: () => void; home?: () => void; image?: string; mode?: GameMode; reverseLevel?: ReverseLevel; nextStage?: () => void;
}) {
  const theme = useGame((s) => s.theme);
  const freshBoard = () => mode === "reverse" ? solved(n) : mode === "daily" ? dailyShuffle(n) : shuffle(n);
  const [board, setBoard] = useState<Board>(freshBoard);
  const [hist, setHist] = useState<GameHistoryStep[]>([]);
  const [time, setTime] = useState(0);
  const [paused, setPaused] = useState(false);
  const [won, setWon] = useState(false);
  /** The finished board stays on screen for a moment before the result card opens. */
  const [winOpen, setWinOpen] = useState(false);
  useEffect(() => {
    if (!won) { setWinOpen(false); return; }
    const id = window.setTimeout(() => setWinOpen(true), WIN_CARD_DELAY_MS);
    return () => window.clearTimeout(id);
  }, [won]);
  const [failed, setFailed] = useState(false);
  const [mistakes, setMistakes] = useState(0);
  const [rounds, setRounds] = useState(0);
  const [survivalLeft, setSurvivalLeft] = useState(60);
  const [showNums, setShowNums] = useState(true);
  const [peek, setPeek] = useState(false);
  const [showTarget, setShowTarget] = useState(false);
  // Refs mirror the latest board/history so very fast taps never act on a stale board.
  const boardRef = useRef(board); boardRef.current = board;
  const histRef = useRef(hist); histRef.current = hist;
  const lock = useRef(false);
  const started = useRef(false);
  const startRecorded = useRef(false);
  const winRecorded = useRef(false);
  /** True once undo or peek was used in this puzzle (hard missions need a solve without help). */
  const helped = useRef(false);
  const best = useGame((s) => s.stats.best[n]);
  const bestT = useGame((s) => s.stats.bestTime?.[n]);
  const prevBestRef = useRef<number | null>(null);
  const photoBest = useGame((s) => s.stats.photoBest[n]);
  const prevPhotoRef = useRef<number | null>(null);
  const goal = useMemo(() => mode === "reverse" ? reverseGoal(n, reverseLevel) : solved(n), [n, mode, reverseLevel]);
  const art = image ?? pictureSkins[theme];
  const isPractice = mode === "training" || Boolean(image);
  const score = Math.max(0, 1000 - hist.length * 8 - mistakes * 60);
  const survivalActive = hist.length > 0 || rounds > 0;
  const maxMoves = mode === "limited" ? moveLimit(n) : mode === "reverse" && reverseLevel === "pro" ? Math.max(12, n * n) : null;
  useBackHandler(() => { if (paused) { setPaused(false); return true; } return false; }, paused);

  useEffect(() => {
    if (!isPractice && !startRecorded.current) { startRecorded.current = true; recordStart(); }
  }, [isPractice]);
  const acc = useRef(0);
  const seg = useRef<number | null>(null);
  const elapsedCs = () => Math.floor((acc.current + (seg.current != null ? performance.now() - seg.current : 0)) / 10);
  useEffect(() => {
    if (paused || won || failed || hist.length === 0) {
      if (seg.current != null) { acc.current += performance.now() - seg.current; seg.current = null; }
      if (hist.length === 0) { acc.current = 0; setTime(0); }
      else setTime(elapsedCs());
      return;
    }
    if (seg.current == null) seg.current = performance.now();
    let raf = 0;
    const loop = () => {
      const nextTime = elapsedCs();
      if (mode === "speed" && nextTime >= timeLimit(n) * 100) {
        acc.current = timeLimit(n) * 1000; seg.current = null; setTime(timeLimit(n) * 100); setFailed(true); return;
      }
      setTime(nextTime);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [paused, won, failed, hist.length, mode, n]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (mode !== "survival" || paused || won || failed || !survivalActive) return;
    const interval = window.setInterval(() => setSurvivalLeft((left) => Math.max(0, left - 1)), 1000);
    return () => window.clearInterval(interval);
  }, [mode, paused, won, failed, survivalActive]);
  useEffect(() => {
    const clearPeek = () => setPeek(false);
    window.addEventListener("pointerup", clearPeek);
    window.addEventListener("pointercancel", clearPeek);
    window.addEventListener("blur", clearPeek);
    document.addEventListener("visibilitychange", clearPeek);
    return () => {
      window.removeEventListener("pointerup", clearPeek);
      window.removeEventListener("pointercancel", clearPeek);
      window.removeEventListener("blur", clearPeek);
      document.removeEventListener("visibilitychange", clearPeek);
    };
  }, []);
  useEffect(() => { if (failed && getSound()) playLose(); }, [failed]);
  useEffect(() => { if (mode === "survival" && survivalActive && survivalLeft === 0 && !won) setFailed(true); }, [mode, survivalActive, survivalLeft, won]);

  const tap = (i: number) => {
    if (paused || won || failed || winRecorded.current || lock.current) return;
    const current = boardRef.current;
    const nextBoard = slide(current, n, i);
    if (!nextBoard) { if (mode === "strict") setMistakes((count) => count + 1); return; }
    const now = performance.now();
    if (seg.current == null) seg.current = now;
    const elapsedMs = acc.current + now - seg.current;
    started.current = true;
    const nextHist = [...histRef.current, { board: current, elapsedMs }];
    const moveCount = nextHist.length;
    const completed = isGoal(nextBoard, goal);
    boardRef.current = nextBoard; histRef.current = nextHist;
    setHist(nextHist);
    setBoard(nextBoard);
    const snd = getSound(), activeTheme = getTheme();
    if (navigator.vibrate) navigator.vibrate(8);
    if (snd) playSlide(activeTheme, current[i]);
    if (completed) {
      winRecorded.current = true;
      const final = elapsedCs();
      prevBestRef.current = bestT ?? null;
      if (image) { prevPhotoRef.current = photoBest?.time ?? null; recordPhotoWin(n, moveCount, final); }
      else if (!isPractice) recordWin(n, moveCount, final, helped.current);
      if (snd) setTimeout(() => playWin(activeTheme), 120);
      if (mode === "survival") {
        lock.current = true;
        setRounds((count) => count + 1);
        setSurvivalLeft((left) => left + 20);
        setTimeout(() => {
          const b = shuffle(n); boardRef.current = b; histRef.current = [];
          setBoard(b); setHist([]); acc.current = 0; seg.current = null; setTime(0);
          winRecorded.current = false; lock.current = false;
        }, 450);
      } else {
        acc.current = final * 10; seg.current = null; setTime(final); setWon(true);
      }
    } else if (maxMoves != null && moveCount >= maxMoves) {
      setFailed(true);
      if (!isPractice) breakStreak();
    }
  };

  const reset = (fresh: boolean) => {
    if (started.current && !won && !isPractice) breakStreak();
    started.current = false;
    const b = fresh ? freshBoard() : hist[0]?.board ?? board;
    boardRef.current = b; histRef.current = [];
    setBoard(b); setHist([]); setTime(0);
    acc.current = 0; seg.current = null;
    setWon(false); setFailed(false); setPaused(false);
    setMistakes(0); setRounds(0); setSurvivalLeft(60); setPeek(false);
    winRecorded.current = false; lock.current = false; helped.current = false;
  };
  const undo = () => {
    const previous = histRef.current.at(-1);
    if (!previous || won) return;
    helped.current = true;
    const nextHist = histRef.current.slice(0, -1);
    boardRef.current = previous.board; histRef.current = nextHist;
    setBoard(previous.board); setHist(nextHist);
    acc.current = previous.elapsedMs;
    seg.current = paused ? null : performance.now();
    setTime(Math.floor(previous.elapsedMs / 10));
    setFailed(false);
  };
  const targetPreview = () => (
    <div className="target-grid" dir="ltr" style={{ gridTemplateColumns: `repeat(${n}, minmax(0, 1fr))` }}>
      {goal.map((value, index) => <span key={index} className={value === 0 ? "target-empty" : ""}>{value ? <N v={value} /> : "·"}</span>)}
    </div>
  );
  // Red = new personal record; green = close to the record; blue = further away.
  const rating = (() => {
    if (image) {
      const p = prevPhotoRef.current;
      if (p == null || time < p) return { r: 3, label: "رکورد جدید!" };
      return time <= p * 1.25 ? { r: 1, label: "عالی بود!" } : { r: 2, label: "آفرین!" };
    }
    const prev = prevBestRef.current;
    if (isPractice || prev == null || time < prev) return isPractice ? { r: 1, label: "آفرین!" } : { r: 3, label: "رکورد جدید!" };
    if (time <= prev * 1.25) return { r: 1, label: "عالی بود!" };
    return { r: 2, label: "آفرین!" };
  })();
  const title = mode === "reverse" ? "حالت معکوس" : image ? "پازل تصویری" : modeInfo(mode).title;

  return (
    <div className="game-shell flex flex-1 flex-col">
      <Header title={<span className="flex min-w-0 items-baseline gap-2"><span>{title}</span><span className="size-label"><N v={`${n}×${n}`} /></span></span>} back={back}
        right={<button onClick={() => setPaused((p) => !p)} aria-label="توقف" className="surface grid size-11 place-items-center rounded-xl border">{paused ? <Play className="size-5" /> : <Pause className="size-5" />}</button>} />
      <div className="game-stats mb-3 grid grid-cols-3 gap-2 text-center">
        <Stat label="حرکت" value={<N v={hist.length} />} />
        {mode !== "relaxed" && <Stat label={mode === "speed" ? "زمان مجاز" : mode === "survival" ? "زمان باقی‌مانده" : "زمان"} value={<N v={mode === "speed" ? fmtTime(Math.max(0, timeLimit(n) * 100 - time), "en") : mode === "survival" ? fmtTime(survivalLeft * 100, "en") : fmtTime(time, "en")} />} />}
        {image ? <button onClick={() => setShowNums((s) => !s)} className="surface stat-action rounded-xl border py-2 text-sm font-bold">{showNums ? "پنهان‌کردن شماره" : "نمایش شماره"}</button>
          : mode === "reverse" ? <button onClick={() => setShowTarget((s) => !s)} className="surface stat-action rounded-xl border py-2 text-sm font-bold">{showTarget ? "پنهان‌کردن هدف" : "دیدن هدف"}</button>
          : mode === "survival" ? <Stat label="پازل‌های حل‌شده" value={<N v={rounds} />} />
          : mode === "strict" ? <Stat label="امتیاز مرحله" value={<N v={score} />} />
          : <Stat label="بهترین" value={best ? <span className="best-inline"><N v={best.moves} /> · <N v={fmtTime(bestT ?? best.time, "en")} /></span> : "—"} />}
      </div>
      {mode === "reverse" && showTarget && <div className="target-card surface mb-3 flex items-center gap-3 rounded-xl border p-2"><div className="min-w-0 flex-1"><b className="text-sm">چیدمان هدف</b><p className="text-xs text-muted-foreground">{reverseLevel === "easy" ? "نزولی" : reverseLevel === "medium" ? "مارپیچی" : reverseLevel === "hard" ? "تصادفی و قابل‌حل" : `حداکثر ${maxMoves} حرکت`}</p></div>{targetPreview()}</div>}
      {maxMoves != null && <div className="move-limit-banner mb-2 flex items-center justify-between rounded-lg px-3 py-1.5 text-sm"><span>{mode === "reverse" ? "حرکت تا هدف" : "حداکثر حرکت"}</span><b><N v={Math.max(0, maxMoves - hist.length)} /> / <N v={maxMoves} /></b></div>}
      <div className={won ? "board-solved" : ""}>
      <PuzzleBoard n={n} board={board} goal={goal} onTap={tap} art={art} showNums={showNums}>
        {art && peek && <img src={art} alt="تصویر کامل پوسته" className="peek-overlay pointer-events-none absolute inset-2 size-[calc(100%-1rem)] rounded-xl object-cover" />}
        {(paused || failed) && !won && (
          <div className="game-overlay absolute inset-0 grid place-items-center rounded-2xl bg-background/85 p-4" dir="rtl">
            {failed ? <p className="text-xl font-bold text-muted-foreground">باختی!</p> : <button onClick={() => setPaused(false)} className="btn-wood rounded-xl px-6 py-3 text-lg font-bold">ادامهٔ بازی</button>}
          </div>
        )}
      </PuzzleBoard>
      </div>
      {won && !winOpen && <button onClick={() => setWinOpen(true)} className="btn-wood win-reopen mt-3 flex items-center justify-center gap-2 rounded-2xl py-3 text-lg font-bold"><Trophy className="size-5" />نمایش نتیجه</button>}
      <div className={`game-controls mt-4 grid gap-2 ${art ? "grid-cols-4" : "grid-cols-3"}`}>
        <Ctl onClick={undo} icon={Undo2} label="برگشت" />
        <Ctl onClick={() => reset(false)} icon={RotateCcw} label="از نو" />
        <Ctl onClick={() => reset(true)} icon={Shuffle} label="جدید" />
        {art && <button onPointerDown={(event) => { event.currentTarget.setPointerCapture(event.pointerId); helped.current = true; setPeek(true); }} onPointerUp={() => setPeek(false)} onPointerCancel={() => setPeek(false)} onLostPointerCapture={() => setPeek(false)} onPointerLeave={() => setPeek(false)} onBlur={() => setPeek(false)}
          className="btn-wood flex items-center justify-center gap-1 rounded-xl py-3 text-sm font-bold"><Eye className="size-4" />نگاه</button>}
      </div>
      {mode === "reverse" ? <p className="mt-3 text-center text-sm text-muted-foreground">از چیدمان معمولی به هدف انتخاب‌شده برسان.</p>
        : mode === "limited" ? <p className="mt-3 text-center text-sm text-muted-foreground">برای حل، حداکثر <N v={maxMoves ?? 0} /> حرکت داری.</p>
        : mode === "daily" ? <p className="mt-3 text-center text-sm text-muted-foreground">پازل امروز برای همهٔ بازیکنان با این اندازه یکسان است.</p>
        : mode !== "relaxed" && !image ? <p className="mt-3 text-center text-sm text-muted-foreground">هدف کم‌حرکت: <N v={moveLimit(n)} /> حرکت</p> : null}
      {won && <Confetti />}
      {failed && !won && (
        <div className="win-backdrop fixed inset-0 z-50 grid place-items-center p-6">
          <div className="win-card lose-card animate-pop" role="dialog" aria-modal="true">
            <div className="win-ribbon lose-ribbon" data-r="lose"><span>باختی!</span></div>
            <p className="font-bold">{mode === "speed" ? "زمان تمام شد" : mode === "survival" ? "زمان بقا به پایان رسید" : "حرکت‌ها تمام شد"}</p>
            <div className="win-stats mt-3">
              {mode === "survival" ? <div className="col-span-2"><span className="text-sm">پازل حل‌شده</span><b><N v={rounds} /></b></div> : <>
                <div><span className="text-sm">زمان</span><b><N v={fmtTime(time, "en")} /></b></div>
                <div><span className="text-sm">حرکت</span><b><N v={hist.length} />{maxMoves != null && <> / <N v={maxMoves} /></>}</b></div>
              </>}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button onClick={home ?? back} className="btn-wood flex items-center justify-center gap-1.5 rounded-full py-3 text-lg font-bold"><HomeIcon className="size-5" />خانه</button>
              <button onClick={() => reset(true)} className="btn-wood flex items-center justify-center gap-1.5 rounded-full py-3 text-lg font-bold"><RotateCcw className="size-5" />دوباره</button>
            </div>
          </div>
        </div>
      )}
      {won && winOpen && (
        <div className="win-backdrop fixed inset-0 z-50 grid place-items-center p-6">
          <div className="win-card animate-pop">
            <div className="win-ribbon" data-r={rating.r}><span>{rating.label}</span></div>
            {art && <img src={art} alt="" className="mx-auto mb-3 size-20 rounded-xl object-cover shadow-lg" />}
            <div className="win-stats">
              {mode !== "relaxed" && <div><span className="text-sm">زمان</span><b><N v={fmtTime(time, "en")} /></b></div>}
              <div className={mode === "relaxed" ? "col-span-2" : ""}><span className="text-sm">حرکت</span><b><N v={hist.length} /></b></div>
            </div>
            {mode === "strict" && <p className="mt-2 text-sm">امتیاز مرحله: <N v={score} /></p>}
            {image && photoBest && <p className="mt-3 flex items-center justify-center gap-1.5 font-bold"><Trophy className="size-5" />رکورد پازل تصویری <N v={fmtTime(photoBest.time, "en")} /></p>}
            {(bestT ?? best?.time) != null && !isPractice && <p className="mt-3 flex items-center justify-center gap-1.5 font-bold"><Trophy className="size-5" />بهترین زمان <N v={fmtTime(bestT ?? best!.time, "en")} /></p>}
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button onClick={home ?? back} className="btn-wood flex items-center justify-center gap-1.5 rounded-full py-3 text-lg font-bold"><HomeIcon className="size-5" />خانه</button>
              <button onClick={() => { if (mode === "stages" && nextStage) nextStage(); else reset(true); }} className="btn-wood rounded-full py-3 text-lg font-bold">{mode === "stages" && nextStage ? "مرحلهٔ بعد" : "بعدی"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const WIN_CARD_DELAY_MS = 1400;

const Ctl = ({ onClick, icon: I, label }: { onClick: () => void; icon: typeof Undo2; label: string }) => (
  <button onClick={onClick} className="btn-wood flex min-w-0 items-center justify-center gap-1.5 rounded-xl px-1 py-3 text-sm font-bold"><I className="size-4 shrink-0" />{label}</button>
);

function themeThumb(id: string) { return materialTextureUrls[id] || pictureSkins[id]; }

function Picker({ items, current, onPreview, kind }: { items: Theme[]; current: string; onPreview: (p: Preview) => void; kind: "theme" | "tiles" }) {
  const stats = useGame((s) => s.stats); const admin = useGame((s) => s.admin);
  const purchased = useGame((s) => s.purchased);
  const fresh = new Set(useGame((s) => newSkinIds(s).join(",")).split(","));
  return (
    <div className="grid grid-cols-2 gap-3">
      {items.map((t) => {
        const ok = itemUnlocked(t, stats, admin, purchased);
        const thumb = themeThumb(t.id);
        return (
          <button key={t.id} onClick={() => onPreview({ kind, id: t.id })} className={`theme-card surface relative min-w-0 overflow-hidden rounded-xl border p-2.5 text-start ${current === t.id ? "ring-2 ring-primary" : ""}`}>
            {fresh.has(t.id) && <span className="new-tag">جدید</span>}
            {thumb ? <img src={thumb} alt="" loading="lazy" className="theme-preview mb-2 w-full rounded-lg object-cover" />
              : CSS_PREMIUM_IDS.has(t.id) ? <span className="theme-preview mb-2 block w-full rounded-lg" style={{ background: `var(--material-image-${t.id})` }} /> : null}
            <span className="flex min-w-0 items-center gap-1.5 truncate font-bold">
              <span className="truncate">{t.name}</span>
            </span>
            {t.weekly && <span className="mt-1 inline-block rounded-md bg-primary px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground">هفتگی</span>}
            <span className="mt-1 flex min-w-0 items-center gap-1 text-xs text-muted-foreground">
              {ok ? (current === t.id ? <><Check className="size-3 shrink-0" />فعال</> : fresh.has(t.id) ? <span className="fresh-label"><Sparkles className="size-3 shrink-0" />تازه باز شد!</span> : "باز شده")
                : t.price != null ? <span className="flex min-w-0 flex-col gap-0.5">{t.req && <span className="flex items-center gap-1 truncate"><Lock className="size-3 shrink-0" /><T>{t.req.label}</T></span>}<span className="flex items-center gap-1"><Coins className="size-3 shrink-0" /><N v={t.price} /></span></span>
                : <><Lock className="size-3 shrink-0" /><span className="truncate"><T>{t.req?.label ?? "قفل‌شده"}</T></span></>}
            </span>
            <span className="preview-btn mt-2 flex items-center justify-center gap-1 rounded-lg py-1.5 text-xs font-bold"><Eye className="size-3.5" />پیش‌نمایش</span>
          </button>
        );
      })}
    </div>
  );
}

/** Bottom sheet that temporarily applies a skin so it can be tried (with its sound) before buying. */
function PreviewSheet({ preview, close }: { preview: NonNullable<Preview>; close: () => void }) {
  const stats = useGame((s) => s.stats); const admin = useGame((s) => s.admin);
  const purchased = useGame((s) => s.purchased); const sound = useGame((s) => s.sound);
  const item = (preview.kind === "theme" ? THEMES : TILE_STYLES).find((t) => t.id === preview.id)!;
  const ok = itemUnlocked(item, stats, admin, purchased);
  const goal = useMemo(() => solved(3), []);
  const [board, setBoard] = useState<Board>(() => [1, 2, 3, 4, 5, 6, 7, 0, 8]);
  useBackHandler(() => { close(); return true; });
  const tap = (i: number) => {
    const next = slide(board, 3, i); if (!next) return;
    if (sound) playSlide(preview.kind === "theme" ? preview.id : getTheme(), board[i]);
    setBoard(next);
    if (isGoal(next, goal) && sound) setTimeout(() => playWin(preview.kind === "theme" ? preview.id : getTheme()), 120);
  };
  const apply = () => { setState((s) => preview.kind === "theme" ? { ...s, theme: item.id } : { ...s, tileStyle: item.id }); close(); };
  const art = preview.kind === "theme" ? pictureSkins[preview.id] : undefined;
  return (
    <div className="preview-sheet" onClick={close}>
      <div className="preview-panel surface border-t" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center gap-2">
          <h2 className="flex-1 text-xl font-bold">{item.name}</h2>
          <button onClick={close} aria-label="بستن" className="surface grid size-10 place-items-center rounded-xl border"><X className="size-5" /></button>
        </div>
        <div className="mx-auto w-[min(78vw,300px)]"><PuzzleBoard n={3} board={board} goal={goal} onTap={tap} art={art} /></div>
        <p className="mt-2 text-center text-xs text-muted-foreground">روی کاشی‌ها بزن تا صدای این پوسته را بشنوی</p>
        <div className="mt-4">
          {ok ? <button onClick={apply} className="btn-wood w-full rounded-2xl py-3.5 text-lg font-bold">استفاده از این پوسته</button>
            : item.price != null && item.req && !item.req.ok(stats, 0) ? <p className="surface rounded-xl border p-3 text-center text-sm"><span className="flex items-center justify-center gap-1.5 font-bold"><Lock className="size-4" />شرط: <T>{item.req.label}</T></span><span className="mt-1 block text-xs text-muted-foreground">بعد از انجام این چالش، با <N v={item.price} /> امتیاز قابل خرید است.</span></p>
            : item.price != null ? <button disabled={stats.points < item.price} onClick={() => { if (buyTheme(item.id)) apply(); }} className="btn-wood flex w-full items-center justify-center gap-2 rounded-2xl py-3.5 text-lg font-bold disabled:opacity-50">
                <Coins className="size-5" />خرید با <N v={item.price} /> امتیاز</button>
            : <p className="surface flex items-center justify-center gap-1.5 rounded-xl border p-3 text-sm"><Lock className="size-4" /><T>{item.req?.label ?? "قفل‌شده"}</T></p>}
          {!ok && item.price != null && stats.points < item.price && <p className="mt-2 text-center text-xs text-muted-foreground">امتیاز شما: <N v={stats.points} /></p>}
        </div>
      </div>
    </div>
  );
}

function Themes({ back, preview, setPreview }: { back: () => void; preview: Preview; setPreview: (p: Preview) => void }) {
  const theme = useGame((s) => s.theme); const tile = useGame((s) => s.tileStyle);
  const points = useGame((s) => s.stats.points);
  const [tab, setTab] = useState<"basic" | "premium" | "picture" | "tiles">("basic");
  const tabs: [typeof tab, string][] = [["basic", "پوسته‌ها"], ["premium", "ویژه"], ["picture", "تصویری"], ["tiles", "طرح کاشی"]];
  const freshIds = new Set(useGame((s) => newSkinIds(s).join(",")).split(","));
  const tabItems: Record<typeof tab, Theme[]> = { basic: THEMES.filter((t) => t.section !== "special" && !t.picture), premium: SPECIAL_THEMES, picture: THEMES.filter((t) => t.picture), tiles: TILE_STYLES };
  const tabNew = (id: typeof tab) => tabItems[id].filter((t) => freshIds.has(t.id)).length;
  useEffect(() => () => { setPreview(null); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div>
      <Header title="پوسته‌ها" back={back} right={<span className="points-badge !text-lg"><Coins className="size-5 text-primary" /><N v={points} /></span>} />
      <div className="theme-tabs mb-4">
        {tabs.map(([id, label]) => <button key={id} aria-pressed={tab === id} onClick={() => setTab(id)} className="surface relative inline-flex items-center justify-center gap-1.5">{label}{tabNew(id) > 0 && <span className="tab-dot" aria-label={`${tabNew(id)} پوستهٔ تازه باز شده`}><N v={tabNew(id)} /></span>}</button>)}
      </div>
      {tab === "basic" && <Picker kind="theme" items={THEMES.filter((t) => t.section !== "special" && !t.picture)} current={theme} onPreview={setPreview} />}
      {tab === "premium" && <><p className="mb-3 text-sm text-muted-foreground">پوسته‌های ویژه با چالش‌های اختصاصی؛ شرط بازشدن هرکدام را ببین و پیش‌نمایش کن.</p><Picker kind="theme" items={SPECIAL_THEMES} current={theme} onPreview={setPreview} /></>}
      {tab === "picture" && <><p className="mb-3 text-sm text-muted-foreground">در این پوسته‌ها کاشی‌ها تکه‌های یک تصویرند؛ با دکمهٔ «نگاه» تصویر کامل را ببین.</p><Picker kind="theme" items={THEMES.filter((t) => t.picture)} current={theme} onPreview={setPreview} /></>}
      {tab === "tiles" && <Picker kind="tiles" items={TILE_STYLES} current={tile} onPreview={setPreview} />}
      {preview && <PreviewSheet preview={preview} close={() => setPreview(null)} />}
    </div>
  );
}

const PHOTOS_KEY = "npz-photos";
const MAX_SAVED_PHOTOS = 24;
function customPhotoId(data: string) {
  let first = 2166136261, second = 0x9e3779b9;
  for (let i = 0; i < data.length; i++) {
    const code = data.charCodeAt(i);
    first = Math.imul(first ^ code, 16777619);
    second = Math.imul(second ^ code, 2246822519);
  }
  return `${(first >>> 0).toString(36)}-${(second >>> 0).toString(36)}`;
}
function loadSavedPhotos(): SavedPhoto[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(PHOTOS_KEY) ?? "[]");
    if (!Array.isArray(value)) return [];
    return value.flatMap((entry): SavedPhoto[] => {
      if (typeof entry === "string") return [{ id: customPhotoId(entry), data: entry }];
      if (entry && typeof entry === "object" && "data" in entry && typeof entry.data === "string") {
        return [{ id: "id" in entry && typeof entry.id === "string" ? entry.id : customPhotoId(entry.data), data: entry.data }];
      }
      return [];
    }).slice(0, MAX_SAVED_PHOTOS);
  } catch { return []; }
}
/** Saves newest-first; drops the oldest photos if the phone's storage is full. */
function storePhotos(list: SavedPhoto[]): SavedPhoto[] {
  let keep = list.slice(0, MAX_SAVED_PHOTOS);
  while (keep.length) {
    try { localStorage.setItem(PHOTOS_KEY, JSON.stringify(keep)); return keep; } catch { keep = keep.slice(0, -1); }
  }
  try { localStorage.removeItem(PHOTOS_KEY); } catch { /* ignore */ }
  return [];
}

/** Picture puzzles: built-in pictures, your saved photos, or a new photo from the gallery/camera. */
export function PhotoPuzzle({ back }: { back: () => void }) {
  const stats = useGame((s) => s.stats);
  const purchased = useGame((s) => s.purchased);
  const admin = useGame((s) => s.admin);
  const [saved, setSaved] = useState<SavedPhoto[]>([]);
  const [img, setImg] = useState<string | null>(null);
  const [n, setN] = useState(3);
  const [playing, setPlaying] = useState(false);
  const [err, setErr] = useState("");
  const [purchaseRequest, setPurchaseRequest] = useState<PhotoPurchaseRequest | null>(null);
  const [purchaseError, setPurchaseError] = useState("");
  const [busy, setBusy] = useState(false);
  const pendingUrl = useRef<string | null>(null);
  const loadToken = useRef(0);
  useEffect(() => { setSaved(loadSavedPhotos()); }, []);
  useEffect(() => () => { loadToken.current++; if (pendingUrl.current) URL.revokeObjectURL(pendingUrl.current); }, []);
  const selectCustomPhoto = (photo: SavedPhoto) => {
    setErr("");
    if (customPictureUnlocked(photo.id, { ..._gs(), admin, stats, purchased })) {
      setImg(photo.data);
      return;
    }
    setPurchaseError("");
    setPurchaseRequest({ kind: "custom", id: photo.id, title: "تصویر شخصی", src: photo.data, price: PICTURE_PRICE });
  };
  const selectBuiltinPicture = (picture: (typeof BUILTIN_PICTURES)[number]) => {
    const skin = pictureThemeForId(picture.id);
    if (!skin) {
      setErr("برای این تصویر، پوستهٔ متناظر پیدا نشد");
      return;
    }
    setErr("");
    const current = { ..._gs(), admin, stats, purchased };
    if (pictureUnlocked(picture.id, current) || itemUnlocked(skin, stats, admin, purchased)) {
      setImg(picture.src);
      return;
    }
    const requirement = skin.req && !skin.req.ok(stats, 0) ? skin.req.label : undefined;
    setPurchaseError("");
    setPurchaseRequest({ kind: "theme", id: skin.id, title: skin.name, src: picture.src, price: skin.price ?? 0, requirement });
  };
  const confirmPicturePurchase = () => {
    if (!purchaseRequest) return;
    const current = _gs();
    const alreadyOwned = purchaseRequest.kind === "custom"
      ? customPictureUnlocked(purchaseRequest.id, current)
      : pictureUnlocked(purchaseRequest.id, current);
    const success = alreadyOwned || (purchaseRequest.kind === "custom"
      ? buyCustomPicture(purchaseRequest.id)
      : buyTheme(purchaseRequest.id));
    if (!success) {
      setPurchaseError(purchaseRequest.kind === "theme" && purchaseRequest.requirement
        ? "ابتدا شرط بازشدن این پوسته را کامل کن."
        : "امتیاز کافی نیست.");
      return;
    }
    setImg(purchaseRequest.src);
    setPurchaseRequest(null);
    setPurchaseError("");
  };
  const onFile = (f?: File) => {
    if (!f) return;
    const token = ++loadToken.current;
    if (pendingUrl.current) { URL.revokeObjectURL(pendingUrl.current); pendingUrl.current = null; setBusy(false); }
    setErr("");
    if (!f.type.startsWith("image/")) { setErr("لطفاً یک فایل تصویری انتخاب کن"); return; }
    const url = URL.createObjectURL(f);
    pendingUrl.current = url;
    const release = () => { URL.revokeObjectURL(url); if (pendingUrl.current === url) pendingUrl.current = null; };
    const im = new Image();
    setBusy(true);
    im.onload = () => {
      if (token !== loadToken.current) { release(); return; }
      try {
        const side = Math.min(im.width, im.height), out = Math.min(900, side);
        const cv = document.createElement("canvas"); cv.width = cv.height = out;
        const context = cv.getContext("2d");
        if (!context || !side) throw new Error("Image canvas is unavailable");
        context.drawImage(im, (im.width - side) / 2, (im.height - side) / 2, side, side, 0, 0, out, out);
        const data = cv.toDataURL("image/jpeg", 0.85);
        const photo = { id: customPhotoId(data), data };
        setSaved((list) => storePhotos([photo, ...list.filter((item) => item.id !== photo.id)]));
        selectCustomPhoto(photo);
      } catch {
        setErr("این تصویر پردازش نشد؛ تصویر دیگری انتخاب کن");
      } finally { release(); setBusy(false); }
    };
    im.onerror = () => { release(); if (token !== loadToken.current) return; setBusy(false); setErr("این تصویر باز نشد، تصویر دیگری امتحان کن"); };
    im.src = url;
  };
  const remove = (photo: SavedPhoto) => {
    setSaved((list) => storePhotos(list.filter((item) => item.id !== photo.id)));
    if (img === photo.data) setImg(null);
  };
  useBackHandler(() => {
    if (purchaseRequest) { setPurchaseRequest(null); setPurchaseError(""); }
    else if (playing) setPlaying(false);
    else setImg(null);
    return true;
  }, Boolean(img || purchaseRequest));
  if (playing && img) return <Game key={`${n}-${img.length}`} n={n} image={img} back={() => setPlaying(false)} />;
  if (img) return (
    <div>
      <Header title="پازل تصویری" back={() => setImg(null)} />
      <img src={img} alt="تصویر انتخاب‌شده" className="photo-hero aspect-square w-full rounded-2xl object-cover" />
      <h2 className="mb-2 mt-5 font-bold">تعداد قطعه‌ها</h2>
      <div className="grid grid-cols-4 gap-2">
        {[3, 4, 5, 6, 7, 8, 10, 12].map((k) => (
          <button key={k} onClick={() => setN(k)} className={`rounded-xl border py-3 font-bold ${n === k ? "btn-wood" : "surface"}`}><N v={`${k}×${k}`} /></button>
        ))}
      </div>
      <button onClick={() => setPlaying(true)} className="btn-wood mt-5 w-full rounded-2xl py-4 text-xl font-bold">شروع پازل</button>
    </div>
  );
  return (
    <div>
      <Header title="پازل تصویری" back={back} right={<span className="points-badge !text-lg"><Coins className="size-5 text-primary" /><N v={stats.points} /></span>} />
      <label className="photo-add surface flex cursor-pointer items-center gap-3 rounded-2xl border-2 border-dashed p-4">
        <ImagePlus className="size-9 shrink-0 text-primary" />
        <span className="flex-1"><b className="block text-lg">{busy ? "در حال آماده‌سازی..." : "افزودن عکس جدید"}</b><span className="text-sm text-muted-foreground">هر تصویر شخصی با <N v={PICTURE_PRICE} /> امتیاز یک‌بار باز می‌شود</span></span>
        <input type="file" accept="image/*" className="hidden" onChange={(e) => { onFile(e.target.files?.[0]); e.currentTarget.value = ""; }} />
      </label>
      {err && <p className="mt-2 text-center text-sm text-destructive">{err}</p>}
      {saved.length > 0 && <>
        <h2 className="mb-2 mt-5 font-bold">عکس‌های من</h2>
        <div className="photo-grid">
          {saved.map((photo, i) => {
            const unlocked = customPictureUnlocked(photo.id, { ..._gs(), admin, stats, purchased });
            return <div key={photo.id} className="photo-cell">
              <button onClick={() => selectCustomPhoto(photo)} className="size-full" aria-label={`انتخاب عکس ${i + 1}`}>
                <img src={photo.data} alt={`عکس ${i + 1}`} className="size-full object-cover" />
                {!unlocked && <span className="photo-lock-badge"><Lock className="size-4" /><N v={PICTURE_PRICE} /></span>}
              </button>
              <button onClick={() => remove(photo)} aria-label="حذف عکس" className="photo-del"><Trash2 className="size-4" /></button>
            </div>
          })}
        </div>
      </>}
      <h2 className="mb-2 mt-5 font-bold">پازل‌های آماده</h2>
      <p className="mb-3 text-sm text-muted-foreground">قیمت تصویرهای آماده با پوستهٔ متناظر یکی است؛ خرید از هر بخش، قفل بخش دیگر را هم باز می‌کند.</p>
      <div className="photo-grid">
        {BUILTIN_PICTURES.map((picture) => {
          const skin = pictureThemeForId(picture.id);
          const unlocked = Boolean(skin && (pictureUnlocked(picture.id, { ..._gs(), admin, stats, purchased }) || itemUnlocked(skin, stats, admin, purchased)));
          const challengeLocked = Boolean(skin?.req && !skin.req.ok(stats, 0));
          return <button key={picture.id} onClick={() => selectBuiltinPicture(picture)} className="photo-cell" aria-label={picture.name}>
            <img src={picture.src} alt={picture.name} loading="lazy" className="size-full object-cover" />
            <span className="photo-name">{picture.name}</span>
            {!unlocked && <span className="photo-lock-badge"><Lock className="size-4" />{challengeLocked ? "چالش" : <N v={skin?.price ?? 0} />}</span>}
          </button>;
        })}
      </div>
      {purchaseRequest && <div className="preview-sheet" onClick={() => { setPurchaseRequest(null); setPurchaseError(""); }}>
        <div className="preview-panel surface border-t" role="dialog" aria-modal="true" aria-labelledby="photo-purchase-title" onClick={(event) => event.stopPropagation()}>
          <div className="mb-3 flex items-center gap-2">
            <h2 id="photo-purchase-title" className="flex-1 text-xl font-bold">{purchaseRequest.title}</h2>
            <button onClick={() => { setPurchaseRequest(null); setPurchaseError(""); }} aria-label="بستن" className="surface grid size-10 place-items-center rounded-xl border"><X className="size-5" /></button>
          </div>
          <p className="text-sm text-muted-foreground">
            {purchaseRequest.kind === "custom"
              ? "این تصویر با پرداخت یک‌باره باز می‌شود و برای همیشه در پازل‌های شما می‌ماند."
              : "مالکیت این تصویر با پوستهٔ متناظر مشترک است؛ اگر پوسته را قبلاً خریده‌ای، تصویر هم باز است."}
          </p>
          {purchaseRequest.requirement
            ? <p className="surface mt-3 rounded-xl border p-3 text-center text-sm"><span className="flex items-center justify-center gap-1.5 font-bold"><Lock className="size-4" />شرط: <T>{purchaseRequest.requirement}</T></span><span className="mt-1 block text-xs text-muted-foreground">پس از انجام چالش، با <N v={purchaseRequest.price} /> امتیاز می‌توانی آن را بخری.</span></p>
            : <button disabled={stats.points < purchaseRequest.price} onClick={confirmPicturePurchase} className="btn-wood mt-4 flex w-full items-center justify-center gap-2 rounded-2xl py-3.5 text-lg font-bold disabled:opacity-50">
                <Coins className="size-5" />خرید با <N v={purchaseRequest.price} /> امتیاز</button>}
          {purchaseError && <p role="alert" className="mt-2 text-center text-sm text-destructive">{purchaseError}</p>}
          {!purchaseRequest.requirement && stats.points < purchaseRequest.price && <p className="mt-2 text-center text-xs text-muted-foreground">امتیاز شما: <N v={stats.points} /></p>}
          <button onClick={() => { setPurchaseRequest(null); setPurchaseError(""); }} className="surface mt-2 w-full rounded-xl border py-3 text-sm font-bold">انصراف</button>
        </div>
      </div>}
    </div>
  );
}

function MissionRow({ m, k, noClaim }: { m: Mission; k: string; noClaim?: boolean }) {
  const stats = useGame((s) => s.stats); const claimed = useGame((s) => s.claimed.includes(k));
  const v = Math.min(m.value(stats), m.goal); const done = v >= m.goal;
  return (
    <div className="surface rounded-xl border p-3">
      <div className="flex items-center justify-between gap-2">
        <div className="font-bold"><T>{m.title}</T></div>
        {done ? (noClaim ? <Check className="size-4 text-primary" /> : claimed ? <span className="text-xs text-muted-foreground">دریافت شد</span> :
          <button onClick={() => { claim(k, m.points ?? 0); if (getSound()) playClaim(); }} className="btn-wood rounded-lg px-3 py-1 text-sm font-bold">دریافت</button>) :
          <span className="text-sm"><N v={v} />/<N v={m.goal} /></span>}
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${(v / m.goal) * 100}%` }} /></div>
      <div className="mt-1.5 text-xs text-muted-foreground">جایزه: <T>{m.reward}</T></div>
    </div>
  );
}
function Missions({ back }: { back: () => void }) {
  const stats = useGame((s) => s.stats);
  return (
    <div>
      <Header title="مأموریت‌ها" back={back} />
      <Weekly />
      <h2 className="mb-2 font-bold">مأموریت‌های روزانه</h2>
      <div className="mb-6 grid gap-2">{dailyMissions(stats.daily.date).map((m) => <MissionRow key={m.id} m={m} k={dailyKey(m.id, stats)} />)}</div>
      <EpochMissions />
    </div>
  );
}

/** Hard missions that change every 5 days, with a live countdown. */
function EpochMissions() {
  const stats = useGame((s) => s.stats);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 30_000); return () => window.clearInterval(id); }, []);
  const left = epochCountdown(now);
  return (
    <section className="epoch-card surface rounded-xl border p-3">
      <div className="mb-1 flex items-center justify-between gap-2">
        <h2 className="flex items-center gap-1.5 font-bold"><Zap className="size-4 text-primary" />دستاوردها</h2>
        <span className="epoch-timer" aria-label="زمان باقی‌مانده"><Timer className="size-3.5" /><N v={left.days} /> روز و <N v={left.hours} /> ساعت</span>
      </div>
      <p className="mb-3 text-xs text-muted-foreground">هر {EPOCH_DAYS} روز دستاوردهای تازه می‌آیند؛ «برگشت» و «نگاه» کمک حساب می‌شوند.</p>
      <div className="grid gap-2">{epochMissions(stats.epoch.id).map((m) => <MissionRow key={m.id} m={m} k={epochKey(m.id, stats)} />)}</div>
    </section>
  );
}

function Weekly() {
  const stats = useGame((s) => s.stats); const claimed = useGame((s) => s.claimed);
  const t = weeklyTheme(); const key = `${stats.week.id}:theme`;
  const done = WEEKLY.every((m) => m.value(stats) >= m.goal);
  const have = stats.unlocked.includes(t.id);
  return (
    <section className="surface mb-6 rounded-xl border p-3">
      <div className="mb-2 flex items-center justify-between">
        <h2 className="font-bold">مأموریت هفتگی</h2>
        <span className="text-xs text-muted-foreground">ورود پیاپی: <N v={stats.loginStreak} /> روز</span>
      </div>
      <p className="mb-3 text-sm">جایزهٔ این هفته: پوستهٔ ویژهٔ <b className="text-primary">{t.name}</b></p>
      <div className="grid gap-2">{WEEKLY.map((m) => <MissionRow key={m.id} m={{ ...m, reward: t.name }} k={weeklyKey(m.id, stats)} noClaim />)}</div>
      <button disabled={!done || have || claimed.includes(key)} onClick={() => { claimWeeklyTheme(); if (getSound()) playClaim(); }}
        className="btn-wood mt-3 w-full rounded-lg py-2.5 font-bold disabled:opacity-50">
        {have ? "پوستهٔ این هفته باز شد ✓" : done ? "باز کردن پوستهٔ هفته" : "همهٔ مأموریت‌های هفته را کامل کن"}
      </button>
    </section>
  );
}

function Progress({ back }: { back: () => void }) {
  const s = useGame((x) => x.stats); const claimed = useGame((x) => x.claimed);
  const pts = 8;
  return (
    <div>
      <Header title="پیشرفت من" back={back} />
      <div className="grid grid-cols-2 gap-2">
        <Stat label="امتیاز" value={<N v={s.points} />} />
        <Stat label="کل پیروزی‌ها" value={<N v={s.wins} />} />
        <Stat label="بهترین رکورد پیاپی" value={<N v={s.bestStreak} />} />
        <Stat label="پیروزی کم‌حرکت" value={<N v={s.efficientWins} />} />
        <Stat label="جوایز دریافتی" value={<N v={claimed.length} />} />
      </div>
      <h2 className="mb-2 mt-6 font-bold">رکوردها</h2>
      <div className="grid gap-2">
        {SIZES.filter((n) => s.best[n]).map((n) => (
          <div key={n} className="surface flex justify-between rounded-xl border px-4 py-3">
            <N v={`${n}×${n}`} className="font-bold" /><span><N v={s.best[n]!.moves} /> حرکت · <N v={fmtTime(s.bestTime?.[n] ?? s.best[n]!.time, "en")} /></span>
          </div>
        ))}
        {!Object.keys(s.best).length && <p className="text-muted-foreground">هنوز رکوردی ثبت نشده است.</p>}
      </div>
      <h2 className="mb-2 mt-6 font-bold">رکوردهای پازل تصویری</h2>
      <div className="grid gap-2">
        {SIZES.filter((n) => s.photoBest[n]).map((n) => (
          <div key={n} className="surface flex justify-between rounded-xl border px-4 py-3">
            <N v={`${n}×${n}`} className="font-bold" /><span><N v={s.photoBest[n]!.moves} /> حرکت · <N v={fmtTime(s.photoBest[n]!.time, "en")} /></span>
          </div>
        ))}
        {!Object.keys(s.photoBest).length && <p className="text-muted-foreground">هنوز پازل تصویری حل نشده است.</p>}
      </div>
      <p className="mt-4 text-xs text-muted-foreground"><N v={pts} /> مأموریت و دستاورد در بازی وجود دارد.</p>
    </div>
  );
}

function SettingsScreen({ back }: { back: () => void }) {
  const digits = useGame((s) => s.digits); const sound = useGame((s) => s.sound); const admin = useGame((s) => s.admin);
  const [taps, setTaps] = useState(0); const [code, setCode] = useState(""); const [msg, setMsg] = useState("");
  return (
    <div>
      <Header title="تنظیمات" back={back} />
      <section className="surface rounded-xl border p-4">
        <h2 className="font-bold">زبان اعداد</h2>
        <p className="mb-3 text-sm text-muted-foreground">اعداد کاشی‌ها و همهٔ صفحه‌ها</p>
        <div className="grid grid-cols-2 gap-2">
          {(["fa", "en"] as const).map((d) => (
            <button key={d} onClick={() => setState((s) => ({ ...s, digits: d }))}
              className={`rounded-xl border py-3 ${digits === d ? "btn-wood font-bold" : ""}`}>
              {d === "fa" ? <>فارسی <span className="num-fa">۱۲۳</span></> : <>انگلیسی <span className="num-en">123</span></>}
            </button>
          ))}
        </div>
      </section>
      <section className="surface mt-3 flex items-center justify-between rounded-xl border p-4">
        <div><h2 className="font-bold">صدا</h2><p className="text-sm text-muted-foreground">جلوه‌های صوتی جابه‌جایی و پایان بازی</p></div>
        <button onClick={() => { const on = !sound; setState((s) => ({ ...s, sound: on })); if (on) playClick(); }} aria-pressed={sound}
          className={`flex items-center gap-2 rounded-xl border px-4 py-2.5 font-bold ${sound ? "btn-wood" : ""}`}>
          {sound ? <><Volume2 className="size-5" />روشن</> : <><VolumeX className="size-5" />خاموش</>}
        </button>
      </section>
      <section className="surface mt-3 rounded-xl border p-4 text-center">
        <p className="text-sm text-muted-foreground">سازنده</p>
        <p className="mt-1 text-lg font-bold text-primary">تولید شده توسط امیر محمد اسدی</p>
      </section>
      <button onClick={() => setTaps((t) => t + 1)} className="mt-8 w-full text-center text-xs text-muted-foreground">
        نسخهٔ <N v="1.0.0" />
      </button>
      {taps >= 5 && (
        <form className="surface mt-3 grid gap-2 rounded-xl border p-4" onSubmit={(e) => {
          e.preventDefault();
          const r = tryAdminCode(code.trim());
          if (r.ok) { setState((s) => ({ ...s, admin: true })); setMsg("همهٔ پوسته‌ها، کاشی‌ها و اندازه‌ها باز شدند."); }
          else if (r.locked > 0) setMsg(`تلاش‌های زیاد؛ ${r.locked} ثانیه صبر کنید.`);
          else setMsg("کد نادرست است.");
          setCode("");
        }}>
          <input value={code} onChange={(e) => setCode(e.target.value)} type="password" dir="ltr" placeholder="کد مخفی" autoFocus autoComplete="off" className="rounded-lg border bg-background px-3 py-2" />
          <button className="btn-wood rounded-lg py-2 font-bold">تأیید</button>
          {(msg || admin) && <p className="text-sm text-primary">{msg || "حالت مدیر فعال است."}</p>}
        </form>
      )}
    </div>
  );
}
