import { useEffect, useRef, useState } from "react";
import { useGame } from "@/lib/store";
import { toDigits } from "@/lib/digits";

/** The loading screen always stays on screen for at least this long. */
export const SPLASH_MIN_MS = 10_000;

/** The path lists the empty cell's moves while shuffling; solving plays it backwards.
 *  Long enough (~30 moves) that tiles move briskly across the whole 10s load. */
const PATHS = [[5, 4, 1, 0, 3, 6, 7, 4, 5, 8, 7, 6, 3, 4, 1, 2, 5, 4, 7, 8, 5, 2, 1, 0, 3, 6, 7, 4, 5, 8]];
const SOLVED = [1, 2, 3, 4, 5, 6, 7, 8, 0];
function shuffled(path: number[]) {
  const b = SOLVED.slice(); let blank = 8;
  for (const c of path) { b[blank] = b[c]!; b[c] = 0; blank = c; }
  return b;
}

/**
 * Startup loading screen with a mini puzzle that solves itself.
 * Shown for at least 10 seconds on every launch.
 */
export function Splash() {
  const digits = useGame((s) => s.digits);
  const [native] = useState(() => typeof document !== "undefined" && !!document.getElementById("splash"));
  const [progress, setProgress] = useState(0);
  const [fading, setFading] = useState(false);
  const [gone, setGone] = useState(native);
  const [board, setBoard] = useState<number[]>(() => shuffled(PATHS[0]!));
  const [solved, setSolved] = useState(false);
  const [instant, setInstant] = useState(true);
  const alive = useRef(true);

  // Progress bar: fills smoothly over the full minimum time.
  useEffect(() => {
    if (native) return;
    const start = performance.now();
    let raf = 0;
    const loop = () => {
      const p = Math.min(100, ((performance.now() - start) / SPLASH_MIN_MS) * 100);
      setProgress(p);
      if (p < 100) raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    let t2 = 0;
    const fonts = document.fonts?.ready ?? Promise.resolve();
    const minWait = new Promise((r) => setTimeout(r, SPLASH_MIN_MS));
    void Promise.all([fonts, minWait]).then(() => {
      if (!alive.current) return;
      setFading(true);
      t2 = window.setTimeout(() => setGone(true), 500);
    });
    return () => { cancelAnimationFrame(raf); window.clearTimeout(t2); };
  }, [native]);

  // Mini puzzle: moves are spread across the whole loading time so the
  // final move lands right as the progress bar reaches 100%.
  useEffect(() => {
    if (native) return;
    alive.current = true;
    const timers: number[] = [];
    const later = (fn: () => void, ms: number) => { timers.push(window.setTimeout(() => { if (alive.current) fn(); }, ms)); };
    const path = PATHS[0]!;
    const solve = [...path.slice(0, -1).reverse(), 8];
    let b = shuffled(path), blank = path.at(-1)!;
    setInstant(true); setSolved(false); setBoard(b);
    later(() => setInstant(false), 30);
    const n = solve.length;
    const span = SPLASH_MIN_MS * 0.96; // last move just before the bar hits 100%
    solve.forEach((cell, i) => {
      later(() => {
        b = b.slice(); b[blank] = b[cell]!; b[cell] = 0; blank = cell;
        setBoard(b);
        if (i === n - 1) setSolved(true);
      }, 30 + Math.round(((i + 1) / n) * span));
    });
    return () => { alive.current = false; timers.forEach((t) => window.clearTimeout(t)); };
  }, [native]);

  if (gone) return null;
  const pct = Math.round(progress);
  const fa = digits === "fa";
  return (
    <div className={`splash-screen ${fading ? "done" : ""}`} role="progressbar" aria-label="در حال بارگذاری" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct}>
      <div className={`splash-grid ${instant ? "instant" : ""} ${solved ? "solved" : ""}`} aria-hidden="true">
        {board.map((v, cell) => v ? (
          <div key={v} className={`splash-tile ${fa ? "num-fa" : "num-en"}`} style={{ transform: `translate(${(cell % 3) * 44}px, ${Math.floor(cell / 3) * 44}px)` }}>
            {toDigits(v, digits)}
          </div>
        ) : null)}
      </div>
      <div className="splash-title">پازل اعداد</div>
      <div className="splash-bar"><div className="splash-fill" style={{ transform: `scaleX(${Math.max(0.03, progress / 100)})` }} /></div>
      <div className={`splash-pct ${fa ? "num-fa" : "num-en"}`}>{toDigits(pct, digits)}{fa ? "٪" : "%"}</div>
    </div>
  );
}
