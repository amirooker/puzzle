<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Multiplayer transport (src/lib/lan.ts + android LanBroadcastPlugin.java) always sends broadcast AND direct UDP to known peers; room code encodes the host IP's last two octets so guests can connect by unicast or via the hotspot gateway — keeps play working with no router.
- Round/series logic lives in src/lib/series.ts (pure, tested) and 5-day missions in src/lib/achievements.ts; store.ts signs saves (v2 + sig) and never holds the secret code in plaintext.
