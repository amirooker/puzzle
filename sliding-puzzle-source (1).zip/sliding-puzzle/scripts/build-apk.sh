#!/usr/bin/env bash
set -euo pipefail

artifact_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
workspace_dir="$(cd "$artifact_dir/../.." && pwd)"
sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$workspace_dir/.local/android-sdk}}"

export ANDROID_HOME="$sdk_root"
export ANDROID_SDK_ROOT="$sdk_root"

cd "$artifact_dir"
pnpm run build:android:web
./node_modules/.bin/cap sync android
cd android
./gradlew assembleDebug

mkdir -p "$workspace_dir/generated-artifacts"
cp app/build/outputs/apk/debug/app-debug.apk "$workspace_dir/generated-artifacts/sliding-puzzle.apk"
printf 'APK saved to %s/generated-artifacts/sliding-puzzle.apk\n' "$workspace_dir"
