import { describe, expect, it } from "vitest";
import { epochId, epochMissions, epochCountdown, EPOCH_DAYS } from "@/lib/achievements";

describe("5-day rotating missions", () => {
  it("missions stay the same inside one 5-day period and change after it", () => {
    const start = 20000 * EPOCH_DAYS * 864e5;
    expect(epochId(start)).toBe(epochId(start + 4.9 * 864e5));
    expect(epochId(start)).not.toBe(epochId(start + EPOCH_DAYS * 864e5));
    expect(epochMissions(epochId(start))).toHaveLength(4);
  });
  it("countdown shows days and hours left", () => {
    const start = 20000 * EPOCH_DAYS * 864e5;
    expect(epochCountdown(start + 36e5)).toMatchObject({ days: 4, hours: 23 });
  });
});
