/** Multi-round match logic shared by the one-phone and multi-phone modes. */
export type Kind = "time" | "speed" | "moves-limit" | "fewest";
export type Result = { id: string; name: string; time: number; moves: number; failed: boolean };

export function rank(results: Result[], kind: Kind): Result[] {
  const done = results.filter((r) => !r.failed).sort((a, b) => kind === "fewest" ? a.moves - b.moves || a.time - b.time : a.time - b.time || a.moves - b.moves);
  return [...done, ...results.filter((r) => r.failed)];
}

/** Round winner id, or null when nobody finished or the top two are exactly level. */
export function roundWinner(results: Result[], kind: Kind): string | null {
  const [a, b] = rank(results, kind);
  if (!a || a.failed) return null;
  if (b && !b.failed && a.time === b.time && a.moves === b.moves) return null;
  return a.id;
}

export type Series = { round: number; wins: Record<string, number>; names: Record<string, string>; final: boolean; history: (string | null)[] };
export const newSeries = (): Series => ({ round: 0, wins: {}, names: {}, final: false, history: [] });

export function applyRound(s: Series, results: Result[], kind: Kind): Series {
  const w = roundWinner(results, kind);
  const names = { ...s.names };
  for (const r of results) names[r.id] = r.name;
  const wins = { ...s.wins };
  for (const r of results) wins[r.id] = wins[r.id] ?? 0;
  if (w && !s.final) wins[w] = (wins[w] ?? 0) + 1;
  return { round: s.final ? s.round : s.round + 1, wins, names, final: s.final, history: [...s.history, w] };
}

export type Outcome = { state: "next" } | { state: "final" } | { state: "winner"; id: string } | { state: "draw" };

export function seriesOutcome(s: Series, totalRounds: number, hardFinal: boolean): Outcome {
  if (s.final) { const w = s.history.at(-1); return w ? { state: "winner", id: w } : { state: "draw" }; }
  const sorted = Object.entries(s.wins).sort((a, b) => b[1] - a[1]);
  const [lead, second] = sorted;
  const remaining = totalRounds - s.round;
  if (remaining > 0) {
    if (lead && lead[1] - (second?.[1] ?? 0) > remaining) return { state: "winner", id: lead[0] };
    return { state: "next" };
  }
  if (lead && lead[1] > (second?.[1] ?? 0)) return { state: "winner", id: lead[0] };
  return hardFinal ? { state: "final" } : { state: "draw" };
}

/** Hard tie-break round: at least 5×5, everyone gets the same puzzle and a tight clock. */
export function finalSettings<T extends { size: number; kind: Kind; limitSec: number; samePuzzle: boolean; stopAfter: number }>(s: T): T {
  const size = Math.max(5, s.size);
  return { ...s, size, kind: "speed", limitSec: size <= 5 ? 150 : size * 40, samePuzzle: true, stopAfter: 99 };
}
