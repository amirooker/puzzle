import { describe, expect, it } from "vitest";
import { getState, itemUnlocked, THEMES } from "@/lib/store";

describe("generated material skin unlocks", () => {
  for (const [id, wins] of [["cork", 20], ["terrazzo", 70], ["rosewood", 120], ["nacre", 200]] as const) {
    it(`${id} unlocks at ${wins} wins`, () => {
      const skin = THEMES.find((t) => t.id === id);
      expect(skin).toBeDefined();
      if (!skin) throw new Error(`Missing skin ${id}`);
      const stats = getState().stats;
      expect(itemUnlocked(skin, { ...stats, wins: wins - 1 }, false)).toBe(false);
      expect(itemUnlocked(skin, { ...stats, wins }, false)).toBe(true);
    });
  }
});