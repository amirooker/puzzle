import { describe, expect, it } from "vitest";
import { applyRound, newSeries, roundWinner, seriesOutcome, finalSettings, type Result } from "@/lib/series";

const r = (id: string, time: number, failed = false): Result => ({ id, name: id, time, moves: 10, failed });

describe("round series", () => {
  it("a 3-round match ends early at 2-0", () => {
    let s = applyRound(newSeries(), [r("a", 100), r("b", 200)], "time");
    expect(seriesOutcome(s, 3, true)).toEqual({ state: "next" });
    s = applyRound(s, [r("a", 100), r("b", 200)], "time");
    expect(seriesOutcome(s, 3, true)).toEqual({ state: "winner", id: "a" });
  });
  it("a level series goes to the hard final when enabled, otherwise is a draw", () => {
    let s = applyRound(newSeries(), [r("a", 100), r("b", 200)], "time");
    s = applyRound(s, [r("a", 300), r("b", 200)], "time");
    expect(seriesOutcome(s, 2, true)).toEqual({ state: "final" });
    expect(seriesOutcome(s, 2, false)).toEqual({ state: "draw" });
    const f = applyRound({ ...s, final: true }, [r("a", 0, true), r("b", 900)], "speed");
    expect(seriesOutcome(f, 2, true)).toEqual({ state: "winner", id: "b" });
  });
  it("nobody finishing is a drawn round", () => {
    expect(roundWinner([r("a", 0, true), r("b", 0, true)], "time")).toBeNull();
    expect(seriesOutcome(applyRound(newSeries(), [r("a", 0, true), r("b", 0, true)], "time"), 1, false)).toEqual({ state: "draw" });
  });
  it("hard final is at least 5x5 on a clock", () => {
    const f = finalSettings({ size: 3, kind: "time" as const, limitSec: 60, samePuzzle: false, stopAfter: 1 });
    expect(f.size).toBe(5);
    expect(f.kind).toBe("speed");
  });
});
