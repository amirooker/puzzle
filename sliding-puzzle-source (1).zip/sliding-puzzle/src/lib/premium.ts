/**
 * Premium (purchasable) texture skins. Each one has its own palette that is
 * applied as CSS variables on <html>, and its own slide + victory sound (see sound.ts).
 */
export type PremiumPalette = {
  bg: string; card: string; fg: string; muted: string; border: string;
  primary: string; primaryFg: string;
  /** Number colour on the small plate in the middle of each tile */
  plate: string; plateFg: string;
  /** Thin decorative line around tiles and the board */
  line: string;
  /** Colour wash over the room background texture */
  wash: string;
};
/** How the number is drawn: carved into the tile, raised 3D, or on a small plate. */
export type NumStyle = "engraved" | "embossed" | "plate";
/** special: a truly 3D "ویژه" skin (bought with points AND gated by a very hard challenge). */
export type PremiumSkin = { id: string; name: string; price: number; num: NumStyle; pal: PremiumPalette; special?: boolean };

export const PREMIUM_SKINS: PremiumSkin[] = [
  { id: "icon-wood", name: "چوب آیکون", price: 3_000, num: "engraved", pal: {
    bg: "oklch(0.3 0.05 50)", card: "oklch(0.36 0.06 50)", fg: "oklch(0.96 0.03 80)", muted: "oklch(0.82 0.04 75)", border: "oklch(0.5 0.07 55)",
    primary: "oklch(0.8 0.09 75)", primaryFg: "oklch(0.25 0.05 45)", plate: "transparent", plateFg: "oklch(0.36 0.07 45)", line: "oklch(0.55 0.07 50)", wash: "oklch(0.24 0.045 45 / .7)" } },
  { id: "leopard-weave", name: "پارچهٔ پلنگی", price: 3_500, num: "embossed", pal: {
    bg: "oklch(0.24 0.04 60)", card: "oklch(0.3 0.05 60)", fg: "oklch(0.97 0.025 85)", muted: "oklch(0.82 0.04 80)", border: "oklch(0.5 0.08 70)",
    primary: "oklch(0.82 0.12 78)", primaryFg: "oklch(0.22 0.04 55)", plate: "oklch(0.98 0.02 85 / .82)", plateFg: "oklch(0.25 0.05 50)", line: "oklch(0.85 0.1 80)", wash: "oklch(0.18 0.03 55 / .82)" } },
  { id: "zebra-silk", name: "ابریشم گورخری", price: 3_800, num: "embossed", pal: {
    bg: "oklch(0.18 0 0)", card: "oklch(0.24 0 0)", fg: "oklch(0.97 0.01 85)", muted: "oklch(0.78 0.01 85)", border: "oklch(0.45 0.01 85)",
    primary: "oklch(0.92 0.03 85)", primaryFg: "oklch(0.18 0 0)", plate: "oklch(0.98 0.015 85 / .85)", plateFg: "oklch(0.15 0 0)", line: "oklch(0.9 0.04 85)", wash: "oklch(0.12 0 0 / .84)" } },
  { id: "pink-embroidery", name: "گلدوزی صورتی", price: 2_600, num: "engraved", pal: {
    bg: "oklch(0.92 0.04 350)", card: "oklch(0.97 0.02 350)", fg: "oklch(0.32 0.08 350)", muted: "oklch(0.5 0.07 350)", border: "oklch(0.82 0.08 350)",
    primary: "oklch(0.62 0.16 355)", primaryFg: "oklch(0.99 0.01 350)", plate: "oklch(1 0.01 350 / .85)", plateFg: "oklch(0.45 0.15 355)", line: "oklch(0.98 0.02 350)", wash: "oklch(0.95 0.035 350 / .8)" } },
  { id: "rose-marble", name: "مرمر صورتی", price: 4_200, num: "engraved", pal: {
    bg: "oklch(0.9 0.035 15)", card: "oklch(0.96 0.02 15)", fg: "oklch(0.32 0.06 20)", muted: "oklch(0.5 0.05 20)", border: "oklch(0.8 0.05 40)",
    primary: "oklch(0.7 0.11 60)", primaryFg: "oklch(0.25 0.05 30)", plate: "oklch(1 0.01 20 / .78)", plateFg: "oklch(0.45 0.09 40)", line: "oklch(0.8 0.11 75)", wash: "oklch(0.95 0.025 15 / .75)" } },
  { id: "persian-mosaic", name: "موزاییک پارسی", price: 3_200, num: "embossed", pal: {
    bg: "oklch(0.22 0.06 225)", card: "oklch(0.28 0.07 225)", fg: "oklch(0.96 0.035 85)", muted: "oklch(0.8 0.05 90)", border: "oklch(0.55 0.11 70)",
    primary: "oklch(0.8 0.13 78)", primaryFg: "oklch(0.22 0.06 225)", plate: "oklch(0.98 0.03 85 / .85)", plateFg: "oklch(0.3 0.09 230)", line: "oklch(0.82 0.13 78)", wash: "oklch(0.16 0.06 225 / .86)" } },
  { id: "minakari", name: "میناکاری", price: 4_600, num: "embossed", pal: {
    bg: "oklch(0.26 0.07 220)", card: "oklch(0.32 0.08 215)", fg: "oklch(0.97 0.02 200)", muted: "oklch(0.83 0.05 200)", border: "oklch(0.6 0.1 80)",
    primary: "oklch(0.84 0.12 82)", primaryFg: "oklch(0.24 0.07 230)", plate: "oklch(0.99 0.01 200 / .86)", plateFg: "oklch(0.32 0.12 255)", line: "oklch(0.84 0.12 82)", wash: "oklch(0.2 0.07 225 / .82)" } },
  { id: "khatam", name: "خاتم‌کاری", price: 5_000, num: "embossed", pal: {
    bg: "oklch(0.2 0.04 35)", card: "oklch(0.27 0.05 35)", fg: "oklch(0.96 0.03 85)", muted: "oklch(0.8 0.04 80)", border: "oklch(0.55 0.09 75)",
    primary: "oklch(0.8 0.11 80)", primaryFg: "oklch(0.2 0.04 35)", plate: "oklch(0.97 0.03 85 / .9)", plateFg: "oklch(0.8 0.11 80)", line: "oklch(0.8 0.11 80)", wash: "oklch(0.15 0.035 35 / .86)" } },
  { id: "iranian-brocade", name: "قالیچهٔ نگارین", price: 4_800, num: "embossed", pal: {
    bg: "oklch(0.2 0.06 155)", card: "oklch(0.27 0.07 155)", fg: "oklch(0.97 0.025 85)", muted: "oklch(0.83 0.045 100)", border: "oklch(0.56 0.12 75)",
    primary: "oklch(0.78 0.13 78)", primaryFg: "oklch(0.2 0.06 155)", plate: "oklch(0.98 0.02 85 / .88)", plateFg: "oklch(0.35 0.12 25)", line: "oklch(0.8 0.12 78)", wash: "oklch(0.16 0.055 155 / .86)" } },
  { id: "iran-flag-weave", name: "پرچم بافت ایران", price: 5_200, num: "embossed", pal: {
    bg: "oklch(0.2 0.06 155)", card: "oklch(0.27 0.065 155)", fg: "oklch(0.97 0.02 90)", muted: "oklch(0.81 0.05 130)", border: "oklch(0.5 0.11 30)",
    primary: "oklch(0.67 0.18 30)", primaryFg: "oklch(0.98 0.02 90)", plate: "oklch(0.99 0.01 90 / .88)", plateFg: "oklch(0.42 0.14 150)", line: "oklch(0.97 0.01 90)", wash: "oklch(0.14 0.05 155 / .88)" } },
  { id: "emerald-velvet", name: "مخمل زمردی", price: 5_600, num: "engraved", pal: {
    bg: "oklch(0.2 0.06 155)", card: "oklch(0.26 0.07 155)", fg: "oklch(0.96 0.04 90)", muted: "oklch(0.8 0.06 100)", border: "oklch(0.55 0.1 85)",
    primary: "oklch(0.82 0.12 85)", primaryFg: "oklch(0.2 0.06 155)", plate: "oklch(0.97 0.04 90 / .88)", plateFg: "oklch(0.82 0.12 85)", line: "oklch(0.82 0.12 85)", wash: "oklch(0.14 0.05 155 / .85)" } },
  { id: "peacock", name: "پر طاووس", price: 6_200, num: "embossed", pal: {
    bg: "oklch(0.18 0.05 190)", card: "oklch(0.24 0.06 190)", fg: "oklch(0.97 0.03 150)", muted: "oklch(0.8 0.06 170)", border: "oklch(0.55 0.12 160)",
    primary: "oklch(0.82 0.14 95)", primaryFg: "oklch(0.18 0.05 200)", plate: "oklch(0.98 0.02 150 / .86)", plateFg: "oklch(0.32 0.12 250)", line: "oklch(0.85 0.13 95)", wash: "oklch(0.13 0.05 200 / .86)" } },
  { id: "lapis", name: "لاجورد", price: 6_800, num: "engraved", pal: {
    bg: "oklch(0.2 0.1 265)", card: "oklch(0.27 0.11 265)", fg: "oklch(0.97 0.02 260)", muted: "oklch(0.82 0.05 260)", border: "oklch(0.6 0.1 85)",
    primary: "oklch(0.84 0.13 85)", primaryFg: "oklch(0.2 0.1 265)", plate: "oklch(0.98 0.02 85 / .88)", plateFg: "oklch(0.84 0.13 85)", line: "oklch(0.84 0.13 85)", wash: "oklch(0.14 0.09 265 / .85)" } },
  { id: "white-gold-marble", name: "مرمر سفید طلایی", price: 7_500, num: "engraved", pal: {
    bg: "oklch(0.95 0.01 85)", card: "oklch(0.99 0.005 85)", fg: "oklch(0.28 0.03 70)", muted: "oklch(0.5 0.03 70)", border: "oklch(0.8 0.07 80)",
    primary: "oklch(0.72 0.13 80)", primaryFg: "oklch(0.2 0.03 70)", plate: "oklch(1 0 0 / .7)", plateFg: "oklch(0.5 0.12 75)", line: "oklch(0.76 0.13 80)", wash: "oklch(0.97 0.01 85 / .7)" } },
  { id: "obsidian-prism", name: "الماس سیاه", price: 8_000, num: "embossed", pal: {
    bg: "oklch(0.12 0 0)", card: "oklch(0.18 0 0)", fg: "oklch(0.97 0 0)", muted: "oklch(0.75 0 0)", border: "oklch(0.4 0 0)",
    primary: "oklch(0.95 0 0)", primaryFg: "oklch(0.12 0 0)", plate: "oklch(0.1 0 0 / .62)", plateFg: "oklch(0.98 0 0)", line: "oklch(0.88 0 0 / .85)", wash: "oklch(0.08 0 0 / .78)" } },
  { id: "black-gold-marble", name: "مرمر طلایی", price: 10_000, num: "plate", pal: {
    bg: "oklch(0.13 0.01 80)", card: "oklch(0.19 0.015 80)", fg: "oklch(0.95 0.06 88)", muted: "oklch(0.78 0.06 85)", border: "oklch(0.55 0.11 82)",
    primary: "oklch(0.83 0.14 85)", primaryFg: "oklch(0.14 0.01 80)", plate: "oklch(0.1 0.01 80 / .66)", plateFg: "oklch(0.88 0.14 88)", line: "oklch(0.82 0.14 85)", wash: "oklch(0.09 0.01 80 / .8)" } },
  /* CSS-only luxury skins: their texture is drawn by gradients in styles.css (--material-image-<id>). */
  { id: "imperial-jade", name: "یشم امپراتوری", price: 12_000, num: "embossed", pal: {
    bg: "oklch(0.2 0.06 160)", card: "oklch(0.27 0.07 160)", fg: "oklch(0.97 0.03 95)", muted: "oklch(0.82 0.05 120)", border: "oklch(0.6 0.11 85)",
    primary: "oklch(0.84 0.13 88)", primaryFg: "oklch(0.2 0.06 160)", plate: "transparent", plateFg: "oklch(0.95 0.06 95)", line: "oklch(0.86 0.13 88)", wash: "oklch(0.14 0.05 160 / .82)" } },
  { id: "sapphire", name: "یاقوت کبود", price: 15_000, num: "embossed", pal: {
    bg: "oklch(0.17 0.08 262)", card: "oklch(0.24 0.1 262)", fg: "oklch(0.97 0.02 250)", muted: "oklch(0.82 0.05 250)", border: "oklch(0.62 0.08 230)",
    primary: "oklch(0.88 0.06 230)", primaryFg: "oklch(0.18 0.08 262)", plate: "transparent", plateFg: "oklch(0.97 0.02 230)", line: "oklch(0.9 0.05 220)", wash: "oklch(0.11 0.07 262 / .8)" } },
  { id: "royal-gold", name: "طلای ناب سلطنتی", price: 20_000, num: "engraved", pal: {
    bg: "oklch(0.16 0.03 70)", card: "oklch(0.22 0.04 70)", fg: "oklch(0.96 0.07 90)", muted: "oklch(0.8 0.07 85)", border: "oklch(0.62 0.12 82)",
    primary: "oklch(0.84 0.15 86)", primaryFg: "oklch(0.18 0.03 70)", plate: "transparent", plateFg: "oklch(0.36 0.08 65)", line: "oklch(0.88 0.14 90)", wash: "oklch(0.1 0.02 70 / .78)" } },
  { id: "rainbow-opal", name: "اوپال رنگین‌کمانی", price: 30_000, num: "embossed", pal: {
    bg: "oklch(0.18 0.04 280)", card: "oklch(0.25 0.05 280)", fg: "oklch(0.98 0.01 280)", muted: "oklch(0.84 0.04 280)", border: "oklch(0.7 0.08 200)",
    primary: "oklch(0.9 0.08 200)", primaryFg: "oklch(0.2 0.05 280)", plate: "transparent", plateFg: "oklch(0.99 0.01 280)", line: "oklch(0.97 0.02 280)", wash: "oklch(0.12 0.04 280 / .78)" } },
  /* ===== Special (ویژه) skins: real 3D spheres / gems drawn in styles.css, each with its own sound ===== */
  { id: "dragon-hearts", name: "قلب اژدها", price: 40000, num: "embossed", special: true, pal: { bg: "oklch(0.14 0.05 30)", card: "oklch(0.2 0.07 30)", fg: "oklch(0.97 0.05 70)", muted: "oklch(0.82 0.08 60)", border: "oklch(0.55 0.18 35)", primary: "oklch(0.75 0.19 50)", primaryFg: "oklch(0.15 0.05 30)", plate: "transparent", plateFg: "oklch(0.99 0.08 90)", line: "oklch(0.8 0.18 60)", wash: "oklch(0.08 0.04 30 / .72)" } },
  { id: "magic-orbs", name: "گوی‌های جادویی", price: 45000, num: "embossed", special: true, pal: { bg: "oklch(0.13 0.05 285)", card: "oklch(0.19 0.07 285)", fg: "oklch(0.97 0.03 290)", muted: "oklch(0.8 0.07 290)", border: "oklch(0.5 0.15 300)", primary: "oklch(0.78 0.16 320)", primaryFg: "oklch(0.15 0.05 285)", plate: "transparent", plateFg: "oklch(0.99 0.02 300)", line: "oklch(0.8 0.16 320)", wash: "oklch(0.08 0.04 285 / .8)" } },
  { id: "geode", name: "ژئود کریستالی", price: 50000, num: "embossed", special: true, pal: { bg: "oklch(0.15 0.03 200)", card: "oklch(0.21 0.04 200)", fg: "oklch(0.97 0.02 200)", muted: "oklch(0.82 0.05 200)", border: "oklch(0.55 0.1 190)", primary: "oklch(0.85 0.12 190)", primaryFg: "oklch(0.15 0.03 200)", plate: "transparent", plateFg: "oklch(0.99 0.02 200)", line: "oklch(0.85 0.12 190)", wash: "oklch(0.09 0.03 200 / .8)" } },
  { id: "planets", name: "منظومهٔ سیاره‌ها", price: 55000, num: "embossed", special: true, pal: { bg: "oklch(0.1 0.03 265)", card: "oklch(0.16 0.04 265)", fg: "oklch(0.97 0.02 250)", muted: "oklch(0.8 0.04 250)", border: "oklch(0.45 0.08 260)", primary: "oklch(0.82 0.13 70)", primaryFg: "oklch(0.12 0.03 265)", plate: "transparent", plateFg: "oklch(0.99 0.01 250)", line: "oklch(0.82 0.13 70)", wash: "oklch(0.06 0.02 265 / .82)" } },
  { id: "mercury", name: "جیوهٔ مذاب", price: 60000, num: "embossed", special: true, pal: { bg: "oklch(0.16 0.005 250)", card: "oklch(0.23 0.006 250)", fg: "oklch(0.98 0.003 250)", muted: "oklch(0.8 0.005 250)", border: "oklch(0.6 0.01 250)", primary: "oklch(0.92 0.01 250)", primaryFg: "oklch(0.16 0.005 250)", plate: "transparent", plateFg: "oklch(0.2 0.01 250)", line: "oklch(0.9 0.01 250)", wash: "oklch(0.1 0.005 250 / .8)" } },
  { id: "void-portal", name: "دروازهٔ خلأ", price: 75000, num: "embossed", special: true, pal: { bg: "oklch(0.08 0.03 300)", card: "oklch(0.14 0.05 300)", fg: "oklch(0.97 0.03 180)", muted: "oklch(0.8 0.08 180)", border: "oklch(0.45 0.18 300)", primary: "oklch(0.82 0.15 180)", primaryFg: "oklch(0.08 0.03 300)", plate: "transparent", plateFg: "oklch(0.98 0.05 180)", line: "oklch(0.82 0.15 180)", wash: "oklch(0.04 0.02 300 / .85)" } },
  { id: "soap-bubbles", name: "حباب‌های رنگین", price: 80000, num: "embossed", special: true, pal: { bg: "oklch(0.18 0.05 240)", card: "oklch(0.24 0.06 240)", fg: "oklch(0.97 0.02 220)", muted: "oklch(0.8 0.02 220)", border: "oklch(0.6 0.1 220)", primary: "oklch(0.85 0.12 200)", primaryFg: "oklch(0.15 0.05 240)", plate: "transparent", plateFg: "oklch(0.97 0.02 220)", line: "oklch(0.9 0.08 200)", wash: "oklch(0.1 0.04 240 / .8)" } },
  { id: "gold-orbs", name: "گوی‌های طلای مذاب", price: 90000, num: "embossed", special: true, pal: { bg: "oklch(0.12 0.02 70)", card: "oklch(0.18 0.03 70)", fg: "oklch(0.97 0.06 90)", muted: "oklch(0.8 0.06 90)", border: "oklch(0.6 0.12 80)", primary: "oklch(0.85 0.15 85)", primaryFg: "oklch(0.14 0.02 70)", plate: "transparent", plateFg: "oklch(0.97 0.06 90)", line: "oklch(0.85 0.15 85)", wash: "oklch(0.07 0.02 70 / .82)" } },
  { id: "holo-foil", name: "کارت هولوگرامی", price: 100000, num: "embossed", special: true, pal: { bg: "oklch(0.14 0.02 280)", card: "oklch(0.2 0.03 280)", fg: "oklch(0.97 0.02 280)", muted: "oklch(0.8 0.02 280)", border: "oklch(0.6 0.1 280)", primary: "oklch(0.88 0.1 200)", primaryFg: "oklch(0.14 0.02 280)", plate: "transparent", plateFg: "oklch(0.97 0.02 280)", line: "oklch(0.9 0.1 200)", wash: "oklch(0.08 0.02 280 / .82)" } },
  { id: "ember-cubes", name: "مکعب‌های آتشین", price: 120000, num: "embossed", special: true, pal: { bg: "oklch(0.1 0.03 30)", card: "oklch(0.16 0.05 30)", fg: "oklch(0.97 0.06 70)", muted: "oklch(0.8 0.06 70)", border: "oklch(0.55 0.18 40)", primary: "oklch(0.78 0.19 55)", primaryFg: "oklch(0.12 0.03 30)", plate: "transparent", plateFg: "oklch(0.97 0.06 70)", line: "oklch(0.8 0.19 55)", wash: "oklch(0.06 0.03 30 / .85)" } },
  { id: "billiard-royal", name: "بیلیارد سلطنتی", price: 48_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.17 0.07 155)", card: "oklch(0.23 0.08 155)", fg: "oklch(0.97 0.02 90)", muted: "oklch(0.82 0.04 125)", border: "oklch(0.52 0.11 85)",
    primary: "oklch(0.84 0.14 85)", primaryFg: "oklch(0.18 0.05 155)", plate: "transparent", plateFg: "oklch(0.18 0.02 80)", line: "oklch(0.84 0.14 85)", wash: "oklch(0.09 0.05 155 / .82)" } },
  { id: "crystal-heart", name: "قلب بلورین", price: 62_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.15 0.07 350)", card: "oklch(0.22 0.09 350)", fg: "oklch(0.98 0.03 350)", muted: "oklch(0.82 0.07 350)", border: "oklch(0.58 0.18 350)",
    primary: "oklch(0.78 0.2 350)", primaryFg: "oklch(0.16 0.06 350)", plate: "transparent", plateFg: "oklch(0.99 0.02 350)", line: "oklch(0.84 0.16 350)", wash: "oklch(0.08 0.05 350 / .82)" } },
  { id: "star-cascade", name: "باران ستاره‌ها", price: 70_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.11 0.04 265)", card: "oklch(0.18 0.06 265)", fg: "oklch(0.98 0.03 90)", muted: "oklch(0.83 0.05 250)", border: "oklch(0.54 0.13 265)",
    primary: "oklch(0.86 0.15 90)", primaryFg: "oklch(0.13 0.04 265)", plate: "transparent", plateFg: "oklch(0.99 0.03 90)", line: "oklch(0.88 0.17 90)", wash: "oklch(0.06 0.03 265 / .86)" } },
  { id: "solar-medallion", name: "مدال خورشیدی", price: 78_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.16 0.05 72)", card: "oklch(0.23 0.07 72)", fg: "oklch(0.98 0.04 90)", muted: "oklch(0.84 0.08 80)", border: "oklch(0.62 0.14 80)",
    primary: "oklch(0.88 0.16 85)", primaryFg: "oklch(0.18 0.04 60)", plate: "transparent", plateFg: "oklch(0.22 0.04 60)", line: "oklch(0.9 0.17 90)", wash: "oklch(0.09 0.03 65 / .82)" } },
  { id: "moon-pearl", name: "هلال مرواریدی", price: 85_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.13 0.04 250)", card: "oklch(0.2 0.05 250)", fg: "oklch(0.98 0.02 230)", muted: "oklch(0.82 0.04 235)", border: "oklch(0.55 0.1 235)",
    primary: "oklch(0.9 0.05 220)", primaryFg: "oklch(0.16 0.04 250)", plate: "transparent", plateFg: "oklch(0.2 0.02 240)", line: "oklch(0.92 0.04 220)", wash: "oklch(0.07 0.03 250 / .86)" } },
  { id: "rainbow-orbit", name: "مدار رنگین", price: 92_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.13 0.05 285)", card: "oklch(0.2 0.06 285)", fg: "oklch(0.98 0.02 280)", muted: "oklch(0.82 0.05 280)", border: "oklch(0.55 0.13 300)",
    primary: "oklch(0.84 0.14 195)", primaryFg: "oklch(0.14 0.04 285)", plate: "transparent", plateFg: "oklch(0.99 0.02 280)", line: "oklch(0.87 0.13 195)", wash: "oklch(0.07 0.04 285 / .85)" } },
  { id: "sapphire-shard", name: "کریستال لاجوردی", price: 100_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.12 0.06 255)", card: "oklch(0.19 0.08 255)", fg: "oklch(0.97 0.03 230)", muted: "oklch(0.81 0.07 235)", border: "oklch(0.52 0.18 255)",
    primary: "oklch(0.78 0.17 250)", primaryFg: "oklch(0.12 0.05 255)", plate: "transparent", plateFg: "oklch(0.99 0.02 230)", line: "oklch(0.86 0.16 245)", wash: "oklch(0.06 0.04 255 / .88)" } },
  { id: "lotus-ember", name: "نیلوفر آتشین", price: 108_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.13 0.06 25)", card: "oklch(0.2 0.08 25)", fg: "oklch(0.98 0.05 70)", muted: "oklch(0.82 0.08 50)", border: "oklch(0.58 0.17 35)",
    primary: "oklch(0.8 0.18 50)", primaryFg: "oklch(0.14 0.05 25)", plate: "transparent", plateFg: "oklch(0.99 0.04 80)", line: "oklch(0.87 0.18 60)", wash: "oklch(0.07 0.04 25 / .86)" } },
  { id: "prism-rainbow", name: "منشور رنگین‌کمانی", price: 115_000, num: "embossed", special: true, pal: {
    bg: "oklch(0.15 0.04 285)", card: "oklch(0.22 0.05 285)", fg: "oklch(0.98 0.02 285)", muted: "oklch(0.82 0.04 285)", border: "oklch(0.58 0.12 310)",
    primary: "oklch(0.88 0.12 195)", primaryFg: "oklch(0.16 0.04 285)", plate: "transparent", plateFg: "oklch(0.99 0.02 285)", line: "oklch(0.9 0.12 195)", wash: "oklch(0.08 0.03 285 / .86)" } },
  /* Luxury picture skins (images in assets/lux), sorted cheapest -> most exclusive. */
  { id: "lux-tictactoe", name: "دوز طلایی", price: 250_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 80)", card: "oklch(0.2 0.04 80)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 80)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 80 / .8)" } },
  { id: "lux-checkers", name: "دامهٔ چرمی", price: 340_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 20)", card: "oklch(0.2 0.04 20)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 20)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 20 / .8)" } },
  { id: "lux-dominoes", name: "دومینوی اونیکس", price: 430_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 80)", card: "oklch(0.2 0.04 80)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 80)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 80 / .8)" } },
  { id: "lux-letters", name: "حروف آبنوس", price: 520_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 75)", card: "oklch(0.2 0.04 75)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 75)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 75 / .8)" } },
  { id: "lux-ludo", name: "منچ جواهرنشان", price: 610_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 85)", card: "oklch(0.2 0.04 85)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 85)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 85 / .8)" } },
  { id: "lux-darts", name: "دارت زمردی", price: 700_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 150)", card: "oklch(0.2 0.04 150)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 150)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 150 / .8)" } },
  { id: "lux-go", name: "گو کایا", price: 790_000, num: "plate", special: true, pal: { bg: "oklch(0.9 0.03 85)", card: "oklch(0.96 0.02 85)", fg: "oklch(0.28 0.05 85)", muted: "oklch(0.48 0.05 85)", border: "oklch(0.75 0.09 80)", primary: "oklch(0.68 0.13 80)", primaryFg: "oklch(0.2 0.03 70)", plate: "oklch(1 0 0 / .78)", plateFg: "oklch(0.3 0.06 70)", line: "oklch(0.75 0.13 80)", wash: "oklch(0.95 0.02 85 / .78)" } },
  { id: "lux-snooker", name: "اسنوکر سلطنتی", price: 880_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 260)", card: "oklch(0.2 0.04 260)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 260)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 260 / .8)" } },
  { id: "lux-backgammon", name: "تخته‌نرد خاتم", price: 970_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 55)", card: "oklch(0.2 0.04 55)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 55)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 55 / .8)" } },
  { id: "lux-mahjong", name: "ماهجونگ یشمی", price: 1_060_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 25)", card: "oklch(0.2 0.04 25)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 25)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 25 / .8)" } },
  { id: "lux-poker", name: "ژتون پوکر", price: 1_150_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 150)", card: "oklch(0.2 0.04 150)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 150)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 150 / .8)" } },
  { id: "lux-cards", name: "ورق طلاکوب", price: 1_240_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 85)", card: "oklch(0.2 0.04 85)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 85)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 85 / .8)" } },
  { id: "lux-dice", name: "تاس الماس‌نشان", price: 1_330_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 25)", card: "oklch(0.2 0.04 25)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 25)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 25 / .8)" } },
  { id: "lux-roulette", name: "رولت طلایی", price: 1_420_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 40)", card: "oklch(0.2 0.04 40)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 40)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 40 / .8)" } },
  { id: "lux-carpet", name: "قالی ابریشم زربفت", price: 1_510_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 25)", card: "oklch(0.2 0.04 25)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 25)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 25 / .8)" } },
  { id: "lux-pearls", name: "مروارید دریای جنوب", price: 1_600_000, num: "plate", special: true, pal: { bg: "oklch(0.9 0.03 80)", card: "oklch(0.96 0.02 80)", fg: "oklch(0.28 0.05 80)", muted: "oklch(0.48 0.05 80)", border: "oklch(0.75 0.09 80)", primary: "oklch(0.68 0.13 80)", primaryFg: "oklch(0.2 0.03 70)", plate: "oklch(1 0 0 / .78)", plateFg: "oklch(0.3 0.06 70)", line: "oklch(0.75 0.13 80)", wash: "oklch(0.95 0.02 80 / .78)" } },
  { id: "lux-cube", name: "مکعب جواهر", price: 1_690_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 260)", card: "oklch(0.2 0.04 260)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 260)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 260 / .8)" } },
  { id: "lux-watch", name: "ساعت کوک سوئیسی", price: 1_780_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 85)", card: "oklch(0.2 0.04 85)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 85)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 85 / .8)" } },
  { id: "lux-eggs", name: "تخم‌مرغ فابرژه", price: 1_870_000, num: "plate", special: true, pal: { bg: "oklch(0.9 0.03 150)", card: "oklch(0.96 0.02 150)", fg: "oklch(0.28 0.05 150)", muted: "oklch(0.48 0.05 150)", border: "oklch(0.75 0.09 80)", primary: "oklch(0.68 0.13 80)", primaryFg: "oklch(0.2 0.03 70)", plate: "oklch(1 0 0 / .78)", plateFg: "oklch(0.3 0.06 70)", line: "oklch(0.75 0.13 80)", wash: "oklch(0.95 0.02 150 / .78)" } },
  { id: "lux-pharaoh", name: "گنج فرعون", price: 1_960_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 265)", card: "oklch(0.2 0.04 265)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 265)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 265 / .8)" } },
  { id: "lux-crown", name: "جواهرات سلطنتی", price: 2_050_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 310)", card: "oklch(0.2 0.04 310)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 310)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 310 / .8)" } },
  { id: "lux-phoenix", name: "پر ققنوس", price: 2_140_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 45)", card: "oklch(0.2 0.04 45)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 45)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 45 / .8)" } },
  { id: "lux-cosmic-gold", name: "کهکشان طلا", price: 2_230_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 300)", card: "oklch(0.2 0.04 300)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 300)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 300 / .8)" } },
  { id: "lux-hoard", name: "گنج اژدها", price: 2_320_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 30)", card: "oklch(0.2 0.04 30)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 30)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 30 / .8)" } },
  { id: "lux-chess", name: "شطرنج کریستال", price: 3_500_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 85)", card: "oklch(0.2 0.04 85)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 85)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 85 / .8)" } },
  { id: "lux-diamonds", name: "الماس خالص", price: 5_000_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.03 250)", card: "oklch(0.2 0.04 250)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 250)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.02 250 / .8)" } },
  { id: "lux-emerald-flow", name: "مرمر زمرد و طلا", price: 4_000_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.04 155)", card: "oklch(0.2 0.05 155)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 155)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.03 155 / .8)" } },
  { id: "lux-rose-silk", name: "ابریشم رزگلد", price: 4_200_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.04 350)", card: "oklch(0.2 0.05 350)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 350)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.03 350 / .8)" } },
  { id: "lux-sapphire-frost", name: "بلور یاقوت کبود", price: 4_500_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.04 260)", card: "oklch(0.2 0.05 260)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 260)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.03 260 / .8)" } },
  { id: "lux-ruby-inferno", name: "دوزخ یاقوت", price: 6_000_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.04 25)", card: "oklch(0.2 0.05 25)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 25)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.03 25 / .8)" } },
  { id: "lux-opal-dream", name: "رؤیای اوپال", price: 8_000_000, num: "plate", special: true, pal: { bg: "oklch(0.13 0.04 300)", card: "oklch(0.2 0.05 300)", fg: "oklch(0.97 0.04 90)", muted: "oklch(0.82 0.05 85)", border: "oklch(0.6 0.12 82)", primary: "oklch(0.84 0.14 86)", primaryFg: "oklch(0.15 0.03 300)", plate: "oklch(0.08 0.01 80 / .66)", plateFg: "oklch(0.92 0.13 88)", line: "oklch(0.84 0.14 86)", wash: "oklch(0.07 0.03 300 / .8)" } },
];
/** Skins without an image file: their texture lives in styles.css. */
export const CSS_PREMIUM_IDS = new Set(["imperial-jade", "sapphire", "royal-gold", "rainbow-opal", "magic-orbs", "geode", "planets", "mercury", "void-portal", "soap-bubbles", "gold-orbs", "holo-foil", "ember-cubes", "crystal-heart", "star-cascade", "solar-medallion", "moon-pearl", "rainbow-orbit", "sapphire-shard", "lotus-ember", "prism-rainbow"]);
export const PREMIUM_IDS = new Set(PREMIUM_SKINS.map((s) => s.id));


/**
 * Special-section skins draw a symbol that matches the skin inside each tile
 * (instead of a random slice of the background picture). Symbols cycle per tile.
 * Dragon hearts keeps its own hand-made tiles.
 */

export const SKIN_MOTIFS: Record<string, string[]> = { "lux-tictactoe": ["X", "O"] };
const MOTIF_VARS = Array.from({ length: 8 }, (_, i) => `--motif-${i}`);
function applyMotif(root: HTMLElement, id: string) {
  const list = SKIN_MOTIFS[id];
  if (!list) { delete root.dataset["motif"]; MOTIF_VARS.forEach((v) => root.style.removeProperty(v)); return; }
  root.dataset["motif"] = "1";
  MOTIF_VARS.forEach((v, i) => root.style.setProperty(v, JSON.stringify(list[i % list.length])));
}

/** Apply (or clear) the premium palette on <html>. */
export function applyPremiumPalette(themeId: string) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const skin = PREMIUM_SKINS.find((s) => s.id === themeId);
  applyMotif(root, skin ? skin.id : "");
  const keys: [keyof PremiumPalette, string][] = [
    ["bg", "--background"], ["card", "--card"], ["card", "--secondary"], ["fg", "--foreground"], ["muted", "--muted-foreground"],
    ["border", "--border"], ["primary", "--primary"], ["primaryFg", "--primary-foreground"], ["plate", "--plate"], ["plateFg", "--plate-fg"],
    ["line", "--line"], ["wash", "--room-wash"], ["card", "--board"], ["plateFg", "--tile-foreground"], ["border", "--tile-edge"],
  ];
  if (!skin) {
    delete root.dataset["premium"];
    for (const [, cssVar] of keys) root.style.removeProperty(cssVar);
    root.style.removeProperty("--material-image");
    delete root.dataset["num"];
    delete root.dataset["skin"];
    delete root.dataset["special"];
    return;
  }
  root.dataset["premium"] = "1";
  root.dataset["num"] = skin.num;
  root.dataset["skin"] = skin.id;
  if (skin.special) root.dataset["special"] = "1"; else delete root.dataset["special"];
  for (const [key, cssVar] of keys) root.style.setProperty(cssVar, skin.pal[key]);
  root.style.setProperty("--material-image", `var(--material-image-${skin.id})`);
}
