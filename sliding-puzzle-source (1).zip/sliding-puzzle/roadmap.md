# Roadmap
- [x] Ribbon + text appear together
- [x] Remove multiplayer ribbons
- [x] Disable text selection/copy
- [x] Deliver ZIP + APK
