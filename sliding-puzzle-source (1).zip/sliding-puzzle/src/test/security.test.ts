import { describe, expect, it, beforeEach } from "vitest";
import { tryAdminCode, signState, MAX_CODE_TRIES } from "@/lib/store";

describe("secret code protection", () => {
  beforeEach(() => localStorage.clear());
  it("locks for a while after 5 wrong attempts within one minute", () => {
    const t = 1_000_000;
    for (let i = 0; i < MAX_CODE_TRIES; i++) expect(tryAdminCode("wrong", t + i).ok).toBe(false);
    expect(tryAdminCode("Amirooker5", t + 10).locked).toBeGreaterThan(0);
    expect(tryAdminCode("Amirooker5", t + 61_000).ok).toBe(true);
  });
  it("save signature changes when coins are edited", () => {
    const base = { admin: false, purchased: [], claimed: [], stats: { points: 100, unlocked: [] } };
    expect(signState(base)).not.toBe(signState({ ...base, stats: { points: 99999, unlocked: [] } }));
  });
});
