import { act, fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
vi.mock("@/lib/puzzle", async (orig) => {
  const m = await orig<typeof import("@/lib/puzzle")>();
  return { ...m, shuffle: (n: number) => { const b = m.solved(n).slice(); const e = b.indexOf(0); [b[e], b[e - 1]] = [b[e - 1]!, b[e]!]; return b; } };
});
import { Game } from "@/routes/index";
import { getState, setState } from "@/lib/store";

describe("picture skin win", () => {
  it("records the win and stops the clock", async () => {
    setState((s) => ({ ...s, theme: "garden-art", sound: false }));
    const before = getState().stats.wins;
    render(<Game n={3} back={() => {}} />);
    const tile = screen.getByRole("button", { name: "کاشی 8" });
    fireEvent.click(tile);
    await act(async () => { await new Promise((r) => setTimeout(r, 50)); });
    expect(getState().stats.wins).toBe(before + 1);
  });
});

describe("skin sounds", () => {
  it("never throw for any skin", async () => {
    const { playSlide, playWin } = await import("@/lib/sound");
    const { THEMES } = await import("@/lib/store");
    for (const t of THEMES) for (let v = 1; v < 10; v++) { expect(() => playSlide(t.id, v)).not.toThrow(); expect(() => playWin(t.id)).not.toThrow(); }
  });
});
