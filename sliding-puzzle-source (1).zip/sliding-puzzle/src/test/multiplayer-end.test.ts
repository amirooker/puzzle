import { describe, expect, it } from "vitest";
import { endChoices, matchOver, stopChoice, UNTIL_LAST } from "@/components/Multiplayer";

describe("multiplayer ending choice", () => {
  it("offers first winner, each place, and until the last player", () => {
    expect(endChoices(4).map((c) => c.value)).toEqual([1, 2, 3, UNTIL_LAST]);
    expect(endChoices(2).map((c) => c.value)).toEqual([1, UNTIL_LAST]);
  });
  it("only one ending is selected at a time", () => {
    for (const players of [2, 3, 5]) for (const stop of [1, 2, 3, 4, UNTIL_LAST]) {
      const selected = endChoices(players).filter((c) => c.value === stopChoice(stop, players));
      expect(selected).toHaveLength(1);
    }
  });
  it("ends with the first winner when chosen", () => {
    expect(matchOver(1, 1, 4, 1)).toBe(true);
    expect(matchOver(1, 1, 4, UNTIL_LAST)).toBe(false);
    expect(matchOver(2, 4, 4, UNTIL_LAST)).toBe(true);
  });
});
