import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useGame } from "@/lib/store";
import { toDigits } from "@/lib/digits";
import type { Board } from "@/lib/puzzle";

/** Per-tile data used by object skins (ball colour, stripe, scrabble points). */
export const tileAttrs = (v: number) => ({ "data-c": (v - 1) % 8, "data-s": Math.floor((v - 1) / 8) % 2, "data-pt": ((v * 7) % 9) + 1 });

function Num({ v }: { v: number }) {
  const d = useGame((s) => s.digits);
  return <span className={`tile-num ${d === "fa" ? "num-fa" : "num-en"}`}>{toDigits(v, d)}</span>;
}

/** Room kept free under/around the tiles so their 3D edge and drop shadow are never cut off. */
const EDGE = 6;
/** Finger travel (px) below which a touch counts as a plain tap. */
const TAP_SLOP = 8;
/** Share of one cell the finger must drag before the move is committed. */
const COMMIT = 0.3;

type Drag = {
  pointerId: number; index: number; values: number[];
  axis: "x" | "y"; sign: 1 | -1; startX: number; startY: number; max: number; moved: number;
};

/**
 * The sliding board. Tiles follow the finger when dragged toward the empty
 * cell (like a real wooden puzzle) and a short tap still slides them at once.
 * Tiles are rendered in a fixed (value) order so their DOM position — and any
 * per-tile texture offset — never changes while they move.
 */
export function PuzzleBoard({ n, board, goal, onTap, art, showNums = true, children }: {
  n: number; board: Board; goal: Board; onTap: (index: number) => void; art?: string | undefined; showNums?: boolean; children?: ReactNode;
}) {
  const viewRef = useRef<HTMLDivElement>(null);
  const [vw, setVw] = useState(340);
  useEffect(() => {
    const el = viewRef.current; if (!el) return;
    const ro = new ResizeObserver(() => setVw(el.clientWidth || 340));
    ro.observe(el); setVw(el.clientWidth || 340);
    return () => ro.disconnect();
  }, []);
  const gap = n <= 5 ? 6 : 4;
  const usable = vw - EDGE;
  const cell = Math.max(8, (usable - gap * (n - 1)) / n);
  const offset = EDGE / 2;
  const pos = useMemo(() => { const map: number[] = []; board.forEach((v, i) => { map[v] = i; }); return map; }, [board]);
  const posRef = useRef(pos); posRef.current = pos;
  const boardRef = useRef(board); boardRef.current = board;
  const tapRef = useRef(onTap); tapRef.current = onTap;
  const drag = useRef<Drag | null>(null);
  const [dragView, setDragView] = useState<{ values: number[]; axis: "x" | "y"; px: number } | null>(null);
  const values = useMemo(() => Array.from({ length: n * n - 1 }, (_, i) => i + 1), [n]);
  const complete = !!art && board.every((v, i) => v === goal[i]);

  const begin = (event: React.PointerEvent<HTMLButtonElement>, v: number) => {
    if (event.button !== 0 || drag.current) return;
    event.preventDefault();
    const b = boardRef.current, index = posRef.current[v]!, empty = b.indexOf(0);
    const r = Math.floor(index / n), c = index % n, er = Math.floor(empty / n), ec = empty % n;
    if (r !== er && c !== ec) { tapRef.current(index); return; } // lets strict mode count the mistake
    const axis = r === er ? "x" : "y";
    const sign = (axis === "x" ? ec - c : er - r) > 0 ? 1 : -1;
    const step = axis === "x" ? sign : sign * n;
    const chain: number[] = [];
    for (let k = index; k !== empty; k += step) chain.push(b[k]!);
    event.currentTarget.setPointerCapture(event.pointerId);
    drag.current = { pointerId: event.pointerId, index, values: chain, axis, sign, startX: event.clientX, startY: event.clientY, max: cell + gap, moved: 0 };
  };
  const move = (event: React.PointerEvent<HTMLButtonElement>) => {
    const d = drag.current; if (!d || d.pointerId !== event.pointerId) return;
    const raw = (d.axis === "x" ? event.clientX - d.startX : event.clientY - d.startY) * d.sign;
    d.moved = Math.max(0, Math.min(d.max, raw));
    if (Math.abs(raw) > TAP_SLOP || dragView) setDragView({ values: d.values, axis: d.axis, px: d.moved * d.sign });
  };
  const end = (event: React.PointerEvent<HTMLButtonElement>, cancelled = false) => {
    const d = drag.current; if (!d || d.pointerId !== event.pointerId) return;
    drag.current = null;
    const raw = (d.axis === "x" ? event.clientX - d.startX : event.clientY - d.startY) * d.sign;
    const isTap = Math.abs(event.clientX - d.startX) < TAP_SLOP && Math.abs(event.clientY - d.startY) < TAP_SLOP;
    setDragView(null);
    if (!cancelled && (isTap || raw >= d.max * COMMIT)) tapRef.current(d.index);
  };

  return (
    <div className={`board-frame relative aspect-square w-full rounded-2xl p-2 ${complete ? "art-complete" : ""}`} dir="ltr" data-board-size={n}>
      <div ref={viewRef} className="board-area size-full">
        {values.map((v) => {
          const index = pos[v]; if (index == null) return null;
          const row = Math.floor(index / n), col = index % n;
          const targetIndex = goal.indexOf(v), tr = Math.floor(targetIndex / n), tc = targetIndex % n;
          const correct = index === targetIndex;
          const dragging = dragView?.values.includes(v) ?? false;
          const dx = dragging && dragView!.axis === "x" ? dragView!.px : 0;
          const dy = dragging && dragView!.axis === "y" ? dragView!.px : 0;
          const pictureStyle = art ? {
            ["--img" as string]: `url(${art})`,
            ["--bs" as string]: `${n * 100}% ${n * 100}%`,
            ["--pos" as string]: `${(tc / (n - 1)) * 100}% ${(tr / (n - 1)) * 100}%`,
          } : {
            ["--tbs" as string]: `auto, ${n * 100}% ${n * 100}%`,
            ["--tpos" as string]: `0 0, ${(tc / (n - 1)) * 100}% ${(tr / (n - 1)) * 100}%`,
          };
          return (
            <button key={v} type="button" {...tileAttrs(v)} aria-label={`کاشی ${v}`}
              onPointerDown={(event) => begin(event, v)}
              onPointerMove={move}
              onPointerUp={(event) => end(event)}
              onPointerCancel={(event) => end(event, true)}
              onClick={(event) => { if (event.detail === 0) tapRef.current(pos[v]!); }}
              className={`tile puzzle-tile absolute left-0 top-0 grid place-items-center font-bold ${correct ? "correct" : ""} ${dragging ? "is-dragging" : ""} ${art ? "photo" : ""} ${art && !showNums ? "hide-num" : ""}`}
              style={{ width: cell, height: cell, fontSize: Math.max(10, cell * 0.42), transform: `translate(${offset + col * (cell + gap) + dx}px, ${row * (cell + gap) + dy}px)`, ...pictureStyle }}>
              {!art && <i className="tile-motif" aria-hidden="true" />}
              <Num v={v} />
            </button>
          );
        })}
      </div>
      {complete && <img src={art} alt="تصویر کامل پازل" className="art-reveal pointer-events-none absolute inset-2 size-[calc(100%-1rem)] rounded-xl object-cover" />}
      {children}
    </div>
  );
}
