import { describe, it, expect } from "vitest";
import { shuffle, dailyShuffle, isSolvable, slide, solved, isSolved, reverseGoal, descendingGoal, spiralGoal, isGoal, sameBoard } from "@/lib/puzzle";
import { toDigits } from "@/lib/digits";
import { checkAdminCode } from "@/lib/store";

describe("puzzle", () => {
  it("generates solvable boards for every size 3..12", () => {
    for (let n = 3; n <= 12; n++) {
      const b = shuffle(n);
      expect(isSolvable(b, n)).toBe(true);
      expect(isSolved(b)).toBe(false);
    }
  });
  it("slides a tile into the empty cell", () => {
    const b = solved(3);
    expect(slide(b, 3, 7)).toEqual([1, 2, 3, 4, 5, 6, 7, 0, 8]);
    expect(slide(b, 3, 0)).toBeNull();
  });
  it("creates solvable reverse targets at every supported size", () => {
    const random = () => {
      let seed = 1234567;
      return () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
    };
    for (let n = 3; n <= 12; n++) {
      for (const board of [descendingGoal(n), spiralGoal(n), reverseGoal(n, "hard", random()), reverseGoal(n, "pro", random())]) {
        expect(isSolvable(board, n)).toBe(true);
        expect(isGoal(board, board)).toBe(true);
      }
      expect(descendingGoal(n).filter(Boolean)).toEqual(Array.from({ length: n * n - 1 }, (_, i) => n * n - 1 - i));
    }
  });
  it("does not mistake the regular solved board for a reverse goal", () => {
    expect(isGoal(solved(3), reverseGoal(3, "easy"))).toBe(false);
  });
  it("uses a stable daily puzzle for the same date and size", () => {
    const date = new Date(2026, 9, 30);
    expect(sameBoard(dailyShuffle(4, date), dailyShuffle(4, date))).toBe(true);
    expect(isSolvable(dailyShuffle(4, date), 4)).toBe(true);
  });
});

describe("digits", () => {
  it("converts to Persian digits", () => expect(toDigits(1405, "fa")).toBe("۱۴۰۵"));
  it("keeps English digits", () => expect(toDigits(1405, "en")).toBe("1405"));
});

describe("admin code", () => {
  it("accepts only the exact code", () => {
    expect(checkAdminCode("Amirooker5")).toBe(true);
    expect(checkAdminCode("amirooker5")).toBe(false);
    expect(checkAdminCode("Amirooker")).toBe(false);
  });
});
